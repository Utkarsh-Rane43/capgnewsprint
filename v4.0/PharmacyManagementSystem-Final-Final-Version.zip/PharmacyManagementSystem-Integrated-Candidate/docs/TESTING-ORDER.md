# Swagger testing order

1. Start LocalDB and create the five empty databases with `docs/Create-Databases.sql`.
2. Run `Run-Local.bat`; each service creates its own tables from its EF Core model.
3. In Gateway Swagger (`http://localhost:5000/swagger`), register a Doctor and an Admin. Admin registration requires the configured invitation code.
4. Log in as Admin and authorize Swagger with the returned JWT. Create a Supplier, then a Drug (with initial quantity).
5. Check GET drugs, suppliers and inventory. Log in as Doctor and authorize Swagger with the Doctor JWT.
6. Place an order as Doctor. Log in as Admin and verify or reject it. Check stock reservation/release.
7. For a verified order, pay as Doctor using a unique idempotency key. Verify PaymentDB and order status.
8. Finalize pickup as Admin.
9. Generate and inspect daily/monthly sales reports as Admin.
10. Test SMTP separately using the Notification Service endpoint and a real mailbox.

Use `Build-Check.ps1` before starting services. Capture any failing HTTP status, response body and corresponding service console exception.
