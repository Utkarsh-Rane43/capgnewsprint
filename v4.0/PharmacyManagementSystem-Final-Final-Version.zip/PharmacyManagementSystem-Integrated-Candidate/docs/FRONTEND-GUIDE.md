# Integrated Pharmacy UI

The API Gateway serves the static web UI from `src/ApiGateway/wwwroot`. Start the local stack with `Run-Local.bat`, then open **http://localhost:5000/**. Swagger remains at **http://localhost:5000/swagger**.

The UI is a lightweight browser interface intended to exercise the existing APIs: registration/login, Admin supplier and medicine management, inventory, order review, reports, Doctor medicine browsing, order placement, payment and invoice download. It stores the JWT in browser localStorage; use only for local development.

## First use
1. Start SQL Server LocalDB and create the five databases using `docs/Create-Databases.sql` if they do not already exist.
2. Start services with `Run-Local.bat`.
3. Open http://localhost:5000/ and register an Admin using the development invitation code configured in `src/AuthService/appsettings.json`. Change it before sharing or deploying.
4. Sign in as Admin. Create a supplier first, then add a medicine and initial stock.
5. Register a Doctor in a second browser/private window, sign in, browse medicines and place an order.
6. Return to Admin and verify/reject the order. Doctor can pay after verification. Admin can generate daily reports.
7. Swagger is available at http://localhost:5000/swagger.

## UI limitations
This is an integrated development UI, not a production frontend. It uses simple prompts for quantity and a basic cart. It does not replace server-side authorization. Some existing API workflows and integrations remain subject to runtime verification; use Swagger and service logs to diagnose failures.
