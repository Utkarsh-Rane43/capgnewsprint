# Pharmacy Management System — Integrated Development Candidate

This package combines the existing six-service .NET backend reference with a browser UI served by the YARP gateway. It is intended as a local development/testing candidate.

## Quick start
1. Install .NET 10 SDK and SQL Server LocalDB.
2. Run `docs/Create-Databases.sql` once in SSMS to create the five empty databases (do not run if they already exist).
3. Review local connection strings and SMTP configuration.
4. Run `Build-Check.ps1` in PowerShell.
5. Run `Run-Local.bat`.
6. Open **http://localhost:5000/** for the UI or **http://localhost:5000/swagger** for Swagger.

The `POST /api/drugs` transaction fix is documented in `docs/DRUG-500-FIX.md`. See `docs/FRONTEND-GUIDE.md`, `docs/TESTING-ORDER.md`, `docs/SMTP-SETUP.md`, and `docs/PROJECT-REQUIREMENTS-BASELINE.md`.

## Verification status
The archive was inspected for ZIP integrity and source structure. It was not compiled or run in this environment because the .NET SDK is unavailable here. Do not treat the project as runtime-verified until `Build-Check.ps1` and end-to-end tests pass on your Windows machine. The integrated UI is a development interface; the backend remains the authoritative security boundary.
