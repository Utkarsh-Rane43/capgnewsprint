using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using System.Text;
namespace Pharmacy.Orders;
[ApiController, Route("api/invoices"), Authorize]
public class InvoiceController(OrderDb db) : ControllerBase
{
    [HttpGet("{orderId:int}")]
    public async Task<IActionResult> Get(int orderId)
    {
        var order=await db.Orders.AsNoTracking().Include(x=>x.Items).SingleOrDefaultAsync(x=>x.OrderId==orderId);
        if(order is null)return NotFound();
        var userId=int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier)??User.FindFirstValue("sub"),out var id)?id:0;
        if(!User.IsInRole("Admin")&&userId!=order.UserId)return Forbid();
        if(order.OrderStatus is not ("Paid" or "PickedUp"))return Conflict(new{message="Invoice is available only after successful payment."});
        var lines=new List<string>{$"PHARMACY MANAGEMENT SYSTEM",$"INVOICE: INV-{order.OrderId}",$"Order date: {order.OrderDate:yyyy-MM-dd HH:mm}",$"Order ID: {order.OrderId}","", "ITEMS"};
        foreach(var item in order.Items)lines.Add($"Drug ID {item.DrugId} | Qty {item.Quantity} | Unit {item.UnitPrice:0.00} | Subtotal {item.SubTotal:0.00}");
        lines.Add("");lines.Add($"TOTAL: {order.TotalAmount:0.00}");lines.Add("Payment status: Successful");
        var pdf=MinimalPdf.Create(lines);
        return File(pdf,"application/pdf",$"Invoice-{order.OrderId}.pdf");
    }
}
internal static class MinimalPdf
{
    public static byte[] Create(IEnumerable<string> lines)
    {
        var content=new StringBuilder("BT\n/F1 11 Tf\n50 790 Td\n14 TL\n");
        foreach(var line in lines){content.Append('(').Append(Escape(line)).Append(") Tj\nT*\n");}
        content.Append("ET");
        var stream=Encoding.ASCII.GetBytes(content.ToString());
        var objects=new List<byte[]>();
        objects.Add(Encoding.ASCII.GetBytes("<< /Type /Catalog /Pages 2 0 R >>"));
        objects.Add(Encoding.ASCII.GetBytes("<< /Type /Pages /Kids [3 0 R] /Count 1 >>"));
        objects.Add(Encoding.ASCII.GetBytes("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>"));
        objects.Add(Encoding.ASCII.GetBytes("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"));
        using var ms=new MemoryStream();using var writer=new StreamWriter(ms,Encoding.ASCII,leaveOpen:true);
        writer.Write("%PDF-1.4\n");writer.Flush();var offsets=new List<long>{0};
        for(int i=0;i<objects.Count;i++){offsets.Add(ms.Position);writer.Write($"{i+1} 0 obj\n");writer.Flush();ms.Write(objects[i]);writer.Write("\nendobj\n");writer.Flush();}
        offsets.Add(ms.Position);writer.Write("5 0 obj\n");writer.Write($"<< /Length {stream.Length} >>\nstream\n");writer.Flush();ms.Write(stream);writer.Write("\nendstream\nendobj\n");writer.Flush();
        var xref=ms.Position;writer.Write("xref\n0 6\n0000000000 65535 f \n");for(int i=1;i<offsets.Count;i++)writer.Write($"{offsets[i]:D10} 00000 n \n");writer.Write($"trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF");writer.Flush();return ms.ToArray();
    }
    private static string Escape(string s)=>s.Replace("\\","\\\\").Replace("(","\\(").Replace(")","\\)").Replace("\r"," ").Replace("\n"," ");
}
