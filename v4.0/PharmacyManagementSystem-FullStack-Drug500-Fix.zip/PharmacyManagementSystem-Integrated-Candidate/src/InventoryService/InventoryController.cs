using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
namespace Pharmacy.Inventory;
[ApiController, Route("api"), Authorize]
public class InventoryController(InventoryDb db, IConfiguration config) : ControllerBase
{
    [HttpPost("drugs"), Authorize(Roles="Admin")]
    public async Task<IActionResult> AddDrug(DrugRequest r)
    {
        if(string.IsNullOrWhiteSpace(r.DrugName)||string.IsNullOrWhiteSpace(r.Manufacturer)||r.Price<=0||r.ExpiryDate.Date<=DateTime.Today||r.InitialQuantity<0) return BadRequest(new{message="Provide valid drug details and a non-negative initial quantity."});
        if(!await db.Suppliers.AnyAsync(x=>x.SupplierId==r.SupplierId)) return BadRequest(new{message="Supplier does not exist."});
        // A new drug and its stock row should be saved together.
        // SQL Server retry support requires manual transactions to run
        // inside the execution strategy returned by EF Core.
        Drug? drug = null;
        var strategy = db.Database.CreateExecutionStrategy();

        await strategy.ExecuteAsync(async () =>
        {
            // Clear tracked entities before a retry so the operation starts cleanly.
            db.ChangeTracker.Clear();

            await using var transaction = await db.Database.BeginTransactionAsync();

            drug = new Drug
            {
                DrugName = r.DrugName.Trim(),
                Manufacturer = r.Manufacturer.Trim(),
                Price = r.Price,
                ExpiryDate = r.ExpiryDate.Date,
                SupplierId = r.SupplierId
            };

            db.Drugs.Add(drug);
            await db.SaveChangesAsync();

            var stock = new Stock
            {
                DrugId = drug.DrugId,
                AvailableQuantity = r.InitialQuantity,
                ReservedQuantity = 0
            };

            db.Inventory.Add(stock);
            await db.SaveChangesAsync();

            await transaction.CommitAsync();
        });

        return Created($"/api/drugs/{drug!.DrugId}", drug);
    }
    [HttpGet("drugs")] public async Task<IActionResult> Drugs()=>Ok(await db.Drugs.AsNoTracking().OrderBy(x=>x.DrugName).ToListAsync());
    [HttpGet("drugs/{id:int}")] public async Task<IActionResult> Drug(int id){var d=await db.Drugs.AsNoTracking().SingleOrDefaultAsync(x=>x.DrugId==id);return d is null?NotFound():Ok(d);}
    [HttpPut("drugs/{id:int}"),Authorize(Roles="Admin")] public async Task<IActionResult> UpdateDrug(int id,DrugRequest r){var d=await db.Drugs.FindAsync(id);if(d is null)return NotFound();if(string.IsNullOrWhiteSpace(r.DrugName)||string.IsNullOrWhiteSpace(r.Manufacturer)||r.Price<=0||r.ExpiryDate.Date<=DateTime.Today)return BadRequest(new{message="Invalid drug details."});if(!await db.Suppliers.AnyAsync(x=>x.SupplierId==r.SupplierId))return BadRequest(new{message="Supplier does not exist."});d.DrugName=r.DrugName.Trim();d.Manufacturer=r.Manufacturer.Trim();d.Price=r.Price;d.ExpiryDate=r.ExpiryDate.Date;d.SupplierId=r.SupplierId;await db.SaveChangesAsync();return Ok(d);}
    [HttpDelete("drugs/{id:int}"),Authorize(Roles="Admin")] public async Task<IActionResult> DeleteDrug(int id){var d=await db.Drugs.FindAsync(id);if(d is null)return NotFound();var stock=await db.Inventory.SingleOrDefaultAsync(x=>x.DrugId==id);if(stock is not null&&(stock.AvailableQuantity!=0||stock.ReservedQuantity!=0))return Conflict(new{message="Cannot delete a drug while stock exists."});if(stock is not null)db.Inventory.Remove(stock);db.Drugs.Remove(d);await db.SaveChangesAsync();return NoContent();}
    [HttpPost("suppliers"),Authorize(Roles="Admin")] public async Task<IActionResult> AddSupplier(SupplierRequest r){if(string.IsNullOrWhiteSpace(r.SupplierName))return BadRequest(new{message="Supplier name is required."});var s=new Supplier{SupplierName=r.SupplierName.Trim(),Email=r.Email??"",Phone=r.Phone??"",Address=r.Address??""};db.Suppliers.Add(s);await db.SaveChangesAsync();return Created($"/api/suppliers/{s.SupplierId}",s);}
    [HttpGet("suppliers")] public async Task<IActionResult> Suppliers()=>Ok(await db.Suppliers.AsNoTracking().ToListAsync());
    [HttpGet("suppliers/{id:int}")] public async Task<IActionResult> Supplier(int id){var s=await db.Suppliers.FindAsync(id);return s is null?NotFound():Ok(s);}
    [HttpPut("suppliers/{id:int}"),Authorize(Roles="Admin")] public async Task<IActionResult> UpdateSupplier(int id,SupplierRequest r){var s=await db.Suppliers.FindAsync(id);if(s is null)return NotFound();if(string.IsNullOrWhiteSpace(r.SupplierName))return BadRequest(new{message="Supplier name is required."});s.SupplierName=r.SupplierName.Trim();s.Email=r.Email??"";s.Phone=r.Phone??"";s.Address=r.Address??"";await db.SaveChangesAsync();return Ok(s);}
    [HttpGet("inventory")] public async Task<IActionResult> AllStock()=>Ok(await db.Inventory.Join(db.Drugs,i=>i.DrugId,d=>d.DrugId,(i,d)=>new{d.DrugId,d.DrugName,i.AvailableQuantity,i.ReservedQuantity}).ToListAsync());
    [HttpGet("inventory/{drugId:int}")] public async Task<IActionResult> Stock(int drugId){var s=await db.Inventory.SingleOrDefaultAsync(x=>x.DrugId==drugId);return s is null?NotFound():Ok(s);}
    [HttpPut("inventory/{drugId:int}"),Authorize(Roles="Admin")] public async Task<IActionResult> UpdateStock(int drugId,QuantityRequest r){if(r.Quantity<0)return BadRequest(new{message="Quantity cannot be negative."});var s=await db.Inventory.SingleOrDefaultAsync(x=>x.DrugId==drugId);if(s is null)return NotFound();if(r.Quantity<s.ReservedQuantity)return Conflict(new{message="Available quantity cannot be lower than reserved quantity."});s.AvailableQuantity=r.Quantity;await db.SaveChangesAsync();return Ok(s);}
    [AllowAnonymous,HttpPost("inventory/reserve")] public async Task<IActionResult> Reserve(StockRequest r)=>await ChangeReserved(r,"reserve");
    [AllowAnonymous,HttpPost("inventory/release")] public async Task<IActionResult> Release(StockRequest r)=>await ChangeReserved(r,"release");
    [AllowAnonymous,HttpPost("inventory/finalize-pickup")] public async Task<IActionResult> FinalizePickup(StockRequest r)=>await ChangeReserved(r,"finalize");
    private async Task<IActionResult> ChangeReserved(StockRequest r,string action){if(!Internal())return Unauthorized();if(r.Quantity<=0)return BadRequest(new{message="Quantity must be positive."});var s=await db.Inventory.SingleOrDefaultAsync(x=>x.DrugId==r.DrugId);if(s is null)return NotFound();if(action=="reserve"){if(s.AvailableQuantity<r.Quantity)return Conflict(new{message="Insufficient stock."});s.AvailableQuantity-=r.Quantity;s.ReservedQuantity+=r.Quantity;}else{if(s.ReservedQuantity<r.Quantity)return Conflict(new{message="Reserved quantity is insufficient."});s.ReservedQuantity-=r.Quantity;if(action=="release")s.AvailableQuantity+=r.Quantity;}await db.SaveChangesAsync();return Ok(new{success=true,s.DrugId,s.AvailableQuantity,s.ReservedQuantity});}
    private bool Internal()=>!string.IsNullOrWhiteSpace(config["Internal:ServiceKey"])&&Request.Headers["X-Internal-Key"]==config["Internal:ServiceKey"];
}
public record DrugRequest(string DrugName,string Manufacturer,decimal Price,DateTime ExpiryDate,int SupplierId,int InitialQuantity=0);
public record SupplierRequest(string SupplierName,string? Email,string? Phone,string? Address);
public record StockRequest(int DrugId,int Quantity);
public record QuantityRequest(int Quantity);
