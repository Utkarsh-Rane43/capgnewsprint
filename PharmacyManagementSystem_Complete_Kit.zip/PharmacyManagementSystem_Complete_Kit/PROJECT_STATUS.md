# Project Status

## Included in this kit
- .NET 10 solution and six backend projects (five microservices plus API Gateway).
- EF Core SQL Server package references and separate database connection strings.
- Entity models and beginner-oriented minimal API starter code.
- RabbitMQ event publisher/consumer starter and shared event contracts.
- QuestPDF invoice-generation starter.
- Angular standalone application starter and npm manifest.
- SQL database creation script, PowerShell setup/start scripts and documentation.
- Final agreed Admin/Doctor responsibilities and order pickup workflow.

## Not yet verified or complete
The package has not been freshly restored, built, or run end-to-end in the user's Windows environment. The user prefers to attempt the full setup first and report errors afterward; accordingly, individual endpoint tests are not included as a required step.

The following business-critical items still require implementation and verification:
1. Consistent JWT validation and Admin/Doctor authorization in every downstream service.
2. Store authenticated Doctor ID on each order and enforce ownership on order/payment/invoice APIs.
3. Doctor invoice list/download restricted to the Doctor's own orders; Admin can view all.
4. Complete order state transitions: PendingVerification, Verified, Rejected, PaymentFailed, Paid, Preparing, ReadyForPickup, PickedUp, Cancelled.
5. Doctor Confirm Pickup action and timestamp audit.
6. Safe stock reservation, commit and release/compensation for payment success/failure/cancellation.
7. Order-to-payment orchestration and idempotent payment processing.
8. Supplier edit/delete APIs and complete Admin/Doctor UI workflows.
9. Complete PDF invoice item/tax/seller/buyer details; verify GST rules with the business.
10. Durable RabbitMQ retry/dead-letter/outbox strategy and report reconciliation.
11. Production configuration: secret management, HTTPS, CORS, logging, migrations, backup and deployment hardening.

## Known package version note
`System.IdentityModel.Tokens.Jwt` is set to `8.19.2`, matching the version the user reported building successfully with in their earlier local work. Keep that version unless NuGet restore indicates a specific compatibility issue.
