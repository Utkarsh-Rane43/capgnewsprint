# Installation and Configuration Guide (Windows)

## Included
- .NET 10 solution containing five Web API services, shared event contracts and YARP API Gateway.
- EF Core SQL Server provider references in project files.
- Angular source starter and npm dependency manifest.
- SQL Server database creation script.
- PowerShell prerequisite, startup and frontend scripts.
- Architecture, role workflow and assessment documentation.

## Software you must install separately
The ZIP does not bundle operating-system installers or downloaded third-party package caches. Install these separately:
1. .NET 10 SDK (the environment previously reported .NET SDK 10.0.404).
2. SQL Server LocalDB and SQL Server Management Studio (SSMS).
3. Erlang/OTP and RabbitMQ Server (RabbitMQ Management UI is optional).
4. Node.js LTS and npm for Angular.

NuGet and npm dependencies are restored by the included commands and require internet access on first restore. Do not copy `bin`, `obj`, or `node_modules` folders between machines.

## Setup
1. Extract the ZIP to a writable folder, e.g. `C:\Projects\PharmacyManagementSystem`.
2. Open PowerShell in that folder.
3. Run `scripts\check-prerequisites.ps1`.
4. Open `database\create-databases.sql` in SSMS and execute it against `(localdb)\MSSQLLocalDB`.
5. Restore and build:
   ```powershell
   dotnet restore PharmacyManagementSystem.sln
   dotnet build PharmacyManagementSystem.sln
   ```
6. Start RabbitMQ Server. The default local configuration is `localhost`, username `guest`, password `guest`.
7. Run `scripts\start-all.ps1`. Each API opens in a separate PowerShell window.
8. In another PowerShell window:
   ```powershell
   cd frontend
   npm install
   npm start
   ```
9. Browse to `http://localhost:4200`. The Angular starter sends API requests to `http://localhost:5000` (YARP Gateway).

## Configuration
- SQL connection strings are in each service's `appsettings.json`.
- Inventory URL is configured in `src/OrderService/appsettings.json`.
- RabbitMQ settings are in PaymentService and SalesReportService `appsettings.json`.
- Payment simulator outcome is `PaymentSimulation:Outcome` in PaymentService: `Success` or `Failure`.
- Replace local development secrets before any shared deployment. Do not use the sample JWT key in production.

## LocalDB note
LocalDB is suitable for local development/training on one Windows machine. For a multi-user deployment, use SQL Server Express or full SQL Server and update all service connection strings.

## Stop services
Close the individual PowerShell windows opened by `start-all.ps1`. `scripts\stop-all.ps1` can stop processes started with the included helper, but avoid using it if other dotnet applications are running.

## First run
EF Core `EnsureCreatedAsync()` is used by the current service starter to create tables when a database is empty. If you change entity models after the database has already been created, `EnsureCreated` will not migrate an existing schema. For development, either create proper EF migrations or drop/recreate only the project databases after backing up anything you need.
