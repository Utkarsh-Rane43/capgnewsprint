using System.Net.Http.Json;
using Microsoft.EntityFrameworkCore;
using OrderService.Data;
using OrderService.Models;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<OrderDbContext>(options =>
{
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection"));
});

builder.Services.AddHttpClient("Inventory", client =>
{
    client.BaseAddress = new Uri(builder.Configuration["Services:InventoryUrl"]!);
});

builder.Services.AddOpenApi();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
}

using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<OrderDbContext>();
    await db.Database.EnsureCreatedAsync();
}

app.MapGet("/", () => "OrderService is running.");

app.MapPost("/api/orders", async (
    CreateOrderRequest request,
    OrderDbContext db,
    IHttpClientFactory httpClientFactory) =>
{
    if (request.Items == null || request.Items.Count == 0)
    {
        return Results.BadRequest("Please add at least one medicine.");
    }

    var inventoryClient = httpClientFactory.CreateClient("Inventory");

    var order = new CustomerOrder
    {
        DoctorName = request.DoctorName,
        CreatedAt = DateTime.UtcNow,
        Status = "Pending"
    };

    decimal subtotal = 0;
    decimal gstTotal = 0;

    foreach (var requestedItem in request.Items)
    {
        if (requestedItem.Quantity <= 0)
        {
            return Results.BadRequest("Quantity must be greater than zero.");
        }

        var drug = await inventoryClient.GetFromJsonAsync<DrugDetails>(
            $"/api/drugs/{requestedItem.DrugId}");

        if (drug == null || drug.StockQuantity < requestedItem.Quantity)
        {
            return Results.BadRequest($"Drug {requestedItem.DrugId} is not available in the required quantity.");
        }

        var itemSubtotal = drug.Price * requestedItem.Quantity;
        var itemGst = itemSubtotal * drug.GstRate / 100;

        subtotal += itemSubtotal;
        gstTotal += itemGst;

        order.Items.Add(new OrderItem
        {
            DrugId = drug.Id,
            DrugName = drug.Name,
            Quantity = requestedItem.Quantity,
            UnitPrice = drug.Price,
            GstRate = drug.GstRate,
            GstAmount = itemGst,
            LineTotal = itemSubtotal + itemGst
        });
    }

    order.Subtotal = subtotal;
    order.GstTotal = gstTotal;
    order.GrandTotal = subtotal + gstTotal;

    db.Orders.Add(order);
    await db.SaveChangesAsync();

    return Results.Created($"/api/orders/{order.Id}", order);
});

app.MapGet("/api/orders", async (OrderDbContext db) =>
{
    var orders = await db.Orders
        .Include(order => order.Items)
        .OrderByDescending(order => order.CreatedAt)
        .ToListAsync();

    return Results.Ok(orders);
});

app.MapGet("/api/orders/{id:int}", async (int id, OrderDbContext db) =>
{
    var order = await db.Orders
        .Include(item => item.Items)
        .FirstOrDefaultAsync(item => item.Id == id);

    if (order == null)
    {
        return Results.NotFound();
    }

    return Results.Ok(order);
});

app.MapPut("/api/orders/{id:int}/status", async (
    int id,
    UpdateOrderStatus request,
    OrderDbContext db) =>
{
    var order = await db.Orders.FirstOrDefaultAsync(item => item.Id == id);

    if (order == null)
    {
        return Results.NotFound();
    }

    order.Status = request.Status;
    await db.SaveChangesAsync();

    return Results.Ok(order);
});

app.Run();

public record CreateOrderRequest(string DoctorName, List<CreateOrderItem> Items);
public record CreateOrderItem(int DrugId, int Quantity);
public record UpdateOrderStatus(string Status);

public class DrugDetails
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public decimal Price { get; set; }
    public decimal GstRate { get; set; }
    public int StockQuantity { get; set; }
}
