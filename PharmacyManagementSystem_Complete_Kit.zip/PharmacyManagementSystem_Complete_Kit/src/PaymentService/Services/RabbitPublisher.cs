using System.Text;
using System.Text.Json;
using RabbitMQ.Client;

namespace PaymentService.Services;

public class RabbitPublisher
{
    private readonly IConfiguration _configuration;

    public RabbitPublisher(IConfiguration configuration)
    {
        _configuration = configuration;
    }

    public Task PublishAsync(string routingKey, object message)
    {
        var factory = new ConnectionFactory
        {
            HostName = _configuration["RabbitMQ:Host"] ?? "localhost",
            UserName = _configuration["RabbitMQ:User"] ?? "guest",
            Password = _configuration["RabbitMQ:Password"] ?? "guest"
        };

        using var connection = factory.CreateConnection();
        using var channel = connection.CreateModel();

        channel.ExchangeDeclare("pharmacy.events", ExchangeType.Topic, durable: true);

        var json = JsonSerializer.Serialize(message);
        var body = Encoding.UTF8.GetBytes(json);

        channel.BasicPublish(
            exchange: "pharmacy.events",
            routingKey: routingKey,
            basicProperties: null,
            body: body);

        return Task.CompletedTask;
    }
}
