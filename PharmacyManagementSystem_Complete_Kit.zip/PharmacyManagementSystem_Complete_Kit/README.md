# Pharmacy Management System — Complete Development Kit

This is the consolidated Windows development package for the Pharmacy Management System. It uses **C# / .NET 10 Web APIs, Entity Framework Core, LINQ, SQL Server LocalDB, RabbitMQ, YARP API Gateway and Angular**. It does not use Docker or MySQL.

## Agreed roles

- **Admin (Pharmacist):** supplier and medicine management, view all orders, verify/reject orders, prepare orders for pickup, view all invoices and payment details, and view/download/print sales reports.
- **Doctor:** register/login, browse medicines, place orders, pay through the simulator, view own order status, and view/download own invoices. Doctor confirms actual pickup after the Pharmacist marks the order Ready for Pickup.

See `docs/ROLE_AND_WORKFLOW.md` for the complete order lifecycle.

## Architecture and ports

| Component | Port | Database |
|---|---:|---|
| AuthService | 5001 | PharmacyAuthDB |
| InventoryService | 5002 | PharmacyInventoryDB |
| OrderService | 5003 | PharmacyOrderDB |
| PaymentService | 5004 | PharmacyPaymentDB |
| SalesReportService | 5005 | PharmacySalesReportDB |
| API Gateway | 5000 | — |
| Angular | 4200 | — |

## Quick start

1. Install .NET 10 SDK, SQL Server LocalDB + SSMS, RabbitMQ + Erlang/OTP, and Node.js LTS.
2. Extract this ZIP.
3. Run `scripts\check-prerequisites.ps1`.
4. Execute `database\create-databases.sql` in SSMS against `(localdb)\MSSQLLocalDB`.
5. From the root folder run:
   ```powershell
   dotnet restore PharmacyManagementSystem.sln
   dotnet build PharmacyManagementSystem.sln
   ```
6. Start RabbitMQ Server.
7. Run:
   ```powershell
   .\scripts\start-all.ps1
   ```
8. In a new PowerShell window run:
   ```powershell
   .\scripts\start-frontend.ps1
   ```
9. Open `http://localhost:4200`. Frontend API base URL is `http://localhost:5000`.

See `docs/INSTALLATION_GUIDE.md` for detailed instructions and configuration.

## Dependency packaging note

The ZIP includes source code, project files, NuGet package declarations, npm manifest, SQL scripts, PowerShell scripts and documentation. It does **not** bundle the .NET SDK, SQL Server/SSMS, RabbitMQ/Erlang installers, Node.js, `node_modules`, or NuGet caches. These are machine-specific third-party installers/packages and are restored/installed separately. The first `dotnet restore` and `npm install` require internet access.

## Important status and limitations

This is a development/assessment kit, not a certified production system. Some existing starter endpoints and the frontend are scaffolding. The agreed business specification is documented, but the complete role enforcement across all services, Doctor-specific invoice ownership, full pickup confirmation flow, stock reservation/compensation, and end-to-end order/payment orchestration must be completed and verified before calling the application complete. Review `docs/FEATURE_MATRIX.md`, `PROJECT_STATUS.md` and `docs/FINAL_ACCEPTANCE_CHECKLIST.md`.

The payment feature is a simulator only. It must not collect card numbers, CVV, UPI PIN, OTP or bank credentials. GST output is an educational calculation, not a tax-compliance guarantee.
