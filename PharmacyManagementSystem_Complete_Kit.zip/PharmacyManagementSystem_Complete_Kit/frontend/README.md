# Angular Frontend

The Angular standalone starter uses the YARP gateway at `http://localhost:5000`.

## Install and run
```powershell
npm install
npm start
```
Open `http://localhost:4200`.

## Planned screens
### Admin
- Overview dashboard
- Suppliers: add/view/edit/delete
- Medicines: add/view/edit/deactivate
- All orders: verify/reject, prepare, mark Ready for Pickup
- Payments: all payment details
- Invoices: all invoices and PDF download
- Sales reports: daily/weekly/monthly, download and print

### Doctor
- Overview
- Browse medicines
- Cart/place order
- Payment simulator
- My Orders and order status
- My Invoices and PDF download
- Confirm Pickup when status is Ready for Pickup

The current Angular component is a starter UI, not the completed role-based application. Do not rely on hiding a button for security; all authorization and ownership checks must be enforced by the backend.
