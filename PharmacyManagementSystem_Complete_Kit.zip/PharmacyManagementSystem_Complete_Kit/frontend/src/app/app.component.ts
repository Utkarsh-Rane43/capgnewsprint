import { CommonModule } from '@angular/common';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-root', standalone: true, imports: [CommonModule, FormsModule],
  template: `
  <div class="shell">
    <header><div><h1>Pharmacy Management</h1><p>Medicine, orders and sales workspace</p></div><div *ngIf="user"><span class="who">{{user.fullName}} · {{user.role}}</span><button class="secondary" (click)="logout()">Logout</button></div></header>
    <main *ngIf="!user" class="auth card">
      <h2>{{registerMode ? 'Create Doctor Account' : 'Sign in'}}</h2>
      <form (ngSubmit)="registerMode ? register() : login()">
        <label *ngIf="registerMode">Full name<input [(ngModel)]="auth.fullName" name="fullName" required></label>
        <label>Email<input type="email" [(ngModel)]="auth.email" name="email" required></label>
        <label>Password<input type="password" [(ngModel)]="auth.password" name="password" required></label>
        <button class="primary" type="submit">{{registerMode ? 'Register' : 'Login'}}</button>
      </form>
      <p><a (click)="registerMode = !registerMode">{{registerMode ? 'Already registered? Login' : 'New doctor? Register here'}}</a></p>
      <p class="hint">Admin accounts are created through the backend seed configuration, not public registration.</p>
    </main>
    <main *ngIf="user">
      <nav><button *ngFor="let tab of tabs" [class.active]="activeTab===tab" (click)="activeTab=tab; loadTab()">{{tab}}</button></nav>
      <p class="notice" *ngIf="message">{{message}}</p>
      <section *ngIf="activeTab==='Overview'" class="grid">
        <article class="card"><h3>Medicines</h3><p>Manage catalogue and stock levels.</p><button (click)="activeTab='Medicines';loadTab()">Open medicines</button></article>
        <article class="card"><h3>Orders</h3><p>Create orders and calculate GST.</p><button (click)="activeTab='Orders';loadTab()">Open orders</button></article>
        <article class="card"><h3>Payments</h3><p>Run the internal payment simulator.</p><button (click)="activeTab='Payments';loadTab()">Open payments</button></article>
        <article class="card" *ngIf="user.role==='Admin'"><h3>Reports</h3><p>View daily, weekly and monthly sales.</p><button (click)="activeTab='Reports';loadTab()">Open reports</button></article>
      </section>
      <section *ngIf="activeTab==='Medicines'" class="card">
        <h2>Medicine inventory</h2>
        <form class="form-grid" (ngSubmit)="addDrug()"><label>Name<input [(ngModel)]="drug.name" name="drugName" required></label><label>Description<input [(ngModel)]="drug.description" name="drugDescription"></label><label>Price (₹)<input type="number" min="0" step="0.01" [(ngModel)]="drug.price" name="drugPrice" required></label><label>GST %<input type="number" min="0" step="0.01" [(ngModel)]="drug.gstRate" name="drugGst"></label><label>Stock<input type="number" min="0" [(ngModel)]="drug.stockQuantity" name="drugStock"></label><button class="primary">Add medicine</button></form>
        <button class="secondary" (click)="loadDrugs()">Refresh</button><div class="table-wrap"><table><tr><th>ID</th><th>Name</th><th>Price</th><th>GST</th><th>Stock</th></tr><tr *ngFor="let d of drugs"><td>{{d.id}}</td><td>{{d.name}}</td><td>₹{{d.price}}</td><td>{{d.gstRate}}%</td><td>{{d.stockQuantity}}</td></tr></table></div>
      </section>
      <section *ngIf="activeTab==='Suppliers'" class="card"><h2>Suppliers</h2><form class="form-grid" (ngSubmit)="addSupplier()"><label>Name<input [(ngModel)]="supplier.name" name="supplierName" required></label><label>Phone<input [(ngModel)]="supplier.phone" name="supplierPhone"></label><label>Email<input type="email" [(ngModel)]="supplier.email" name="supplierEmail"></label><button class="primary">Add supplier</button></form><div class="table-wrap"><table><tr><th>ID</th><th>Name</th><th>Phone</th><th>Email</th></tr><tr *ngFor="let s of suppliers"><td>{{s.id}}</td><td>{{s.name}}</td><td>{{s.phone}}</td><td>{{s.email}}</td></tr></table></div></section>
      <section *ngIf="activeTab==='Orders'" class="card"><h2>Create order</h2><p class="hint">Enter a medicine ID from the inventory list. Add one item per order in this starter screen.</p><form class="form-grid" (ngSubmit)="createOrder()"><label>Doctor name<input [(ngModel)]="order.doctorName" name="doctorName" required></label><label>Medicine ID<input type="number" min="1" [(ngModel)]="order.drugId" name="drugId" required></label><label>Quantity<input type="number" min="1" [(ngModel)]="order.quantity" name="quantity" required></label><button class="primary">Create order</button></form><button class="secondary" (click)="loadOrders()">Refresh orders</button><div class="table-wrap"><table><tr><th>Order</th><th>Doctor</th><th>Created</th><th>Status</th><th>Total</th></tr><tr *ngFor="let o of orders"><td>{{o.id}}</td><td>{{o.doctorName}}</td><td>{{o.createdAt | date:'short'}}</td><td>{{o.status}}</td><td>₹{{o.grandTotal}}</td></tr></table></div></section>
      <section *ngIf="activeTab==='Payments'" class="card"><h2>Payment simulator</h2><p class="hint">This is a simulated outcome only. Do not enter card, UPI, OTP or bank credentials.</p><form class="form-grid" (ngSubmit)="simulatePayment()"><label>Order ID<input type="number" min="1" [(ngModel)]="payment.orderId" name="paymentOrder" required></label><label>Amount (₹)<input type="number" min="0.01" step="0.01" [(ngModel)]="payment.amount" name="paymentAmount" required></label><button class="primary">Simulate payment</button></form><button class="secondary" (click)="loadPayments()">Refresh payments</button><div class="table-wrap"><table><tr><th>ID</th><th>Order</th><th>Amount</th><th>Status</th><th>Paid at</th></tr><tr *ngFor="let p of payments"><td>{{p.id}}</td><td>{{p.orderId}}</td><td>₹{{p.amount}}</td><td>{{p.status}}</td><td>{{p.paidAt | date:'short'}}</td></tr></table></div></section>
      <section *ngIf="activeTab==='Reports' && user.role==='Admin'" class="card"><h2>Sales reports</h2><div class="actions"><button (click)="loadReport('daily')">Daily</button><button (click)="loadReport('weekly')">Weekly</button><button (click)="loadReport('monthly')">Monthly</button></div><pre *ngIf="report">{{report | json}}</pre></section>
    </main>
    <footer>Pharmacy Management System · Training/assessment application</footer>
  </div>`
})
export class AppComponent {
  private api = 'http://localhost:5000';
  user: any = JSON.parse(localStorage.getItem('pharmacyUser') || 'null');
  token = localStorage.getItem('pharmacyToken') || '';
  registerMode = false; activeTab = 'Overview'; message = ''; report: any = null;
  tabs = ['Overview','Medicines','Suppliers','Orders','Payments','Reports'];
  auth: any = { fullName: '', email: '', password: '' };
  drug: any = { name: '', description: '', price: 0, gstRate: 5, stockQuantity: 0, isActive: true };
  supplier: any = { name: '', phone: '', email: '' };
  order: any = { doctorName: '', drugId: 1, quantity: 1 };
  payment: any = { orderId: 1, amount: 1 };
  drugs: any[] = []; suppliers: any[] = []; orders: any[] = []; payments: any[] = [];
  constructor(private http: HttpClient) { if (this.user) this.activeTab = 'Overview'; }
  headers() { return new HttpHeaders({ Authorization: `Bearer ${this.token}` }); }
  login() { this.http.post<any>(`${this.api}/api/auth/login`, { email: this.auth.email, password: this.auth.password }).subscribe({ next: r => { this.token=r.token; this.user=r; localStorage.setItem('pharmacyToken',r.token); localStorage.setItem('pharmacyUser',JSON.stringify(r)); this.message='Signed in successfully.'; }, error: e => this.showError(e) }); }
  register() { this.http.post(`${this.api}/api/auth/register`, this.auth).subscribe({ next: () => { this.message='Doctor registered. Please sign in.'; this.registerMode=false; }, error: e => this.showError(e) }); }
  logout() { localStorage.removeItem('pharmacyToken'); localStorage.removeItem('pharmacyUser'); this.token=''; this.user=null; this.message=''; }
  loadTab() { this.message=''; if(this.activeTab==='Medicines')this.loadDrugs(); if(this.activeTab==='Suppliers')this.loadSuppliers(); if(this.activeTab==='Orders')this.loadOrders(); if(this.activeTab==='Payments')this.loadPayments(); }
  loadDrugs() { this.http.get<any[]>(`${this.api}/api/drugs`).subscribe({next:r=>this.drugs=r,error:e=>this.showError(e)}); }
  addDrug() { this.http.post(`${this.api}/api/drugs`,this.drug).subscribe({next:()=>{this.message='Medicine added.';this.drug={name:'',description:'',price:0,gstRate:5,stockQuantity:0,isActive:true};this.loadDrugs();},error:e=>this.showError(e)}); }
  loadSuppliers() { this.http.get<any[]>(`${this.api}/api/suppliers`).subscribe({next:r=>this.suppliers=r,error:e=>this.showError(e)}); }
  addSupplier() { this.http.post(`${this.api}/api/suppliers`,this.supplier).subscribe({next:()=>{this.message='Supplier added.';this.supplier={name:'',phone:'',email:''};this.loadSuppliers();},error:e=>this.showError(e)}); }
  createOrder() { const body={doctorName:this.order.doctorName,items:[{drugId:Number(this.order.drugId),quantity:Number(this.order.quantity)}]}; this.http.post<any>(`${this.api}/api/orders`,body).subscribe({next:r=>{this.message=`Order #${r.id} created. Total ₹${r.grandTotal}`;this.order={doctorName:this.user.fullName,drugId:1,quantity:1};this.loadOrders();},error:e=>this.showError(e)}); }
  loadOrders() { this.http.get<any[]>(`${this.api}/api/orders`).subscribe({next:r=>this.orders=r,error:e=>this.showError(e)}); }
  simulatePayment() { this.http.post<any>(`${this.api}/api/payments/simulate`,this.payment).subscribe({next:r=>{this.message=`Payment ${r.payment.status}. Invoice ${r.invoice.invoiceNumber} created.`;this.loadPayments();},error:e=>this.showError(e)}); }
  loadPayments() { this.http.get<any[]>(`${this.api}/api/payments`).subscribe({next:r=>this.payments=r,error:e=>this.showError(e)}); }
  loadReport(period:string) { this.http.get<any>(`${this.api}/api/reports/${period}`).subscribe({next:r=>this.report=r,error:e=>this.showError(e)}); }
  private showError(e:any) { this.message=e?.error?.message || e?.error || 'Request failed. Check that the API services and database are running.'; }
}
