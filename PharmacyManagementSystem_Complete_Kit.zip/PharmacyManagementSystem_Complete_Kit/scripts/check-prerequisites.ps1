\
$ErrorActionPreference = "Continue"
Write-Host "Checking Pharmacy Management System prerequisites..." -ForegroundColor Cyan

function Check-Command($name, $label) {
    $cmd = Get-Command $name -ErrorAction SilentlyContinue
    if ($cmd) { Write-Host "[FOUND] $label : $($cmd.Source)" -ForegroundColor Green }
    else { Write-Host "[MISSING] $label : command '$name' was not found." -ForegroundColor Yellow }
}

Check-Command "dotnet" ".NET SDK"
Check-Command "node" "Node.js"
Check-Command "npm" "npm"
Check-Command "sqlcmd" "SQL command-line utility (optional)"
Check-Command "rabbitmqctl" "RabbitMQ CLI (optional; may not be on PATH)"

Write-Host "`n.NET SDKs:" -ForegroundColor Cyan
dotnet --list-sdks
Write-Host "`nNode version:" -ForegroundColor Cyan
node --version
Write-Host "`nnpm version:" -ForegroundColor Cyan
npm --version

Write-Host "`nAlso confirm SQL Server LocalDB and RabbitMQ Server are installed and running." -ForegroundColor Yellow
