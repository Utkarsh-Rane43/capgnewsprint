\
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$projects = @(
    @{ Name = "AuthService"; Path = "src/AuthService" },
    @{ Name = "InventoryService"; Path = "src/InventoryService" },
    @{ Name = "OrderService"; Path = "src/OrderService" },
    @{ Name = "PaymentService"; Path = "src/PaymentService" },
    @{ Name = "SalesReportService"; Path = "src/SalesReportService" },
    @{ Name = "ApiGateway"; Path = "src/ApiGateway" }
)
foreach ($project in $projects) {
    $projectPath = Join-Path $root $project.Path
    Start-Process powershell -ArgumentList @("-NoExit", "-Command", "Set-Location '$projectPath'; dotnet run")
    Start-Sleep -Milliseconds 500
}
Write-Host "Started the six backend projects in separate PowerShell windows." -ForegroundColor Green
Write-Host "After APIs and RabbitMQ are ready, run: cd frontend; npm install; npm start" -ForegroundColor Cyan
