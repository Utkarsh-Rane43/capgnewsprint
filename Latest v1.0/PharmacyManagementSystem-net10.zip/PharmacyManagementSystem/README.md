# Pharmacy Management System – Microservices POC

Implementation based on the supplied 29-page LLD. .NET 10 / C# / ASP.NET Core Web API, EF Core, SQL Server, YARP, JWT, REST/JSON, SMTP and Swagger.

## Services and ports
| Component | Port | Database |
|---|---:|---|
| YARP API Gateway | 5000 | — |
| Auth Service | 5001 | UserDB |
| Inventory Service | 5002 | InventoryDB |
| Order Service | 5003 | OrderDB |
| Payment Service | 5004 | PaymentDB |
| Sales Report Service | 5005 | ReportDB |
| Notification Service | 5006 | SMTP; no DB |

## Prerequisites
- .NET 10 SDK (latest 10.0 servicing release; SDK 10.0.100 or later in the 10.0 feature band)
- Docker Desktop (or SQL Server 2022)
- Optional SMTP account for email delivery

## Target framework and package versions
All projects target `net10.0`. Entity Framework Core SQL Server, JWT Bearer, and Microsoft.Extensions.Http use the 10.0.15 servicing package line. YARP 2.2.0 and Swashbuckle 6.9.2 are retained as compatible packages; update them independently after validating any API or configuration changes.

## Run locally
1. Start SQL Server: `docker compose up -d`.
2. Open `PharmacyManagementSystem.sln` in Visual Studio 2022, or restore/build with `dotnet restore` and `dotnet build`.
3. Run each service project (launch profiles set ports 5001–5006). Run ApiGateway on port 5000.
4. EF Core `EnsureCreated` creates the five databases/tables on first service startup. For production, replace this with reviewed EF migrations.
5. Swagger: `http://localhost:5001/swagger` through `http://localhost:5006/swagger`; gateway health at `http://localhost:5000/health`.

## First Admin account
Public registration deliberately assigns the `Doctor` role, as required by the LLD. Create the first Admin directly in UserDB after registering a Doctor: update that user's `Role` to `Admin` using a secure database administration session. Never expose public Admin registration.

## Authentication
Login at `POST /api/auth/login`. Copy `data.token` and use `Authorization: Bearer <token>` in Swagger. Default development JWT settings are in each service's `appsettings.json`; change the key consistently in all services before any shared deployment and store secrets outside source control.

## Main workflow
1. Register Doctor; Admin provisions Admin role out-of-band.
2. Admin creates supplier, then medicine with initial stock.
3. Doctor logs in and places an order. Order Service reads medicine/stock from Inventory Service and calls reserve for each line. If a later reservation fails, it releases earlier reservations.
4. Admin verifies or rejects. Rejection releases reserved quantities.
5. Doctor pays a verified order. `simulateFailure=true` tests failed payment; `idempotencyKey` prevents duplicate records.
6. Payment success notifies Order Service, which moves the order to Paid. Admin finalizes pickup with `POST /api/orders/{id}/finalize-pickup`, which calls Inventory Service.
7. Doctor/Admin retrieves invoice (invoice endpoint requires paid order).
7. Admin can add report summary through `POST /api/reports/ingest` and view daily/monthly summaries.

## API examples
### Register Doctor
`POST http://localhost:5000/api/auth/register`
```json
{"fullName":"Rahul Sharma","email":"rahul@example.com","password":"SecurePass@123","phone":"9876543210"}
```
### Login
`POST /api/auth/login`
```json
{"email":"rahul@example.com","password":"SecurePass@123"}
```
### Create supplier (Admin token)
`POST /api/suppliers`
```json
{"supplierName":"ABC Pharma","email":"supplier@example.com","phone":"9876543210","address":"Pune"}
```
### Add drug (Admin token)
`POST /api/drugs`
```json
{"drugName":"Paracetamol","manufacturer":"ABC Pharmaceuticals","price":25.50,"expiryDate":"2027-12-31","supplierId":1,"initialQuantity":100,"description":"Fever and pain relief"}
```
### Place order (Doctor token)
`POST /api/orders`
```json
{"items":[{"drugId":1,"quantity":2}]}
```
### Verify order (Admin token)
`PUT /api/orders/1/verify`
### Pay (Doctor token)
`POST /api/payments`
```json
{"orderId":1,"paymentMethod":"UPI","idempotencyKey":"ORDER-1-PAYMENT-01","simulateFailure":false}
```

## Important implementation notes / limitations
- This is a runnable POC starter, not a production-certified pharmacy or financial system. Review authorization, audit logging, secrets, rate limiting, HTTPS, backups, migrations, monitoring, concurrency and privacy before production.
- The LLD describes 24 NUnit cases. This ZIP includes the complete service source and a manual Swagger test plan in `docs/TESTING.md`; an NUnit test project with password-hashing tests is included. The full 24 scenarios are documented as a Swagger execution checklist in `docs/TESTING.md`; execute them and record actual results before submission. No tests have been run in this environment. The project targets .NET 10 as requested; verify restore/build/test on a machine with the .NET 10 SDK.
- Payment simulation is local only; no bank/payment gateway is contacted.
- ReportDB stores summary rows. Populate it using the secured ingest endpoint after aggregating successful sales; automated event-driven aggregation is not part of the LLD POC.
- Notification SMTP requires valid environment/configuration settings. Email failure returns a service-unavailable response rather than silently reporting success.
- For multi-service consistency this POC compensates earlier stock reservations if a later reservation fails. Production-grade workflows should use a durable Saga/outbox and idempotent inventory commands.
- EF Core EnsureCreated is used to bootstrap local databases quickly. Use migrations for schema evolution.

## Environment overrides
Use ASP.NET Core configuration environment variables, e.g. `ConnectionStrings__Default`, `Jwt__Key`, `Smtp__Host`, `Smtp__Username`, `Smtp__Password`. Keep real credentials out of Git.
