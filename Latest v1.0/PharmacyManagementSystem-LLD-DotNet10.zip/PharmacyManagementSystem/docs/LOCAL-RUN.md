# Local run instructions (.NET 10)

1. Install the .NET 10 SDK and SQL Server locally. No Docker or deployment platform is required.
2. Run `docs/Create-Databases.sql` in SSMS.
3. Check the local SQL Server connection strings in each database-backed service's `appsettings.json`.
4. From the solution folder, run `dotnet restore` and `dotnet build`.
5. Run `Run-Local.bat` to start the six local service processes and YARP gateway.
6. Open **http://localhost:5000/swagger**. This is the single client-facing Swagger entry point and lists all six services.

Ports 5001-5006 are local service listener ports used internally by YARP. You do not need to open their Swagger pages directly. All client API calls should go through `http://localhost:5000`.
