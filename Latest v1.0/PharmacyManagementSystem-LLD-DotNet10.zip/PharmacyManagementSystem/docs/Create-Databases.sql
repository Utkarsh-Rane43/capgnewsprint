-- Run this script in SQL Server Management Studio (SSMS) using your local SQL Server instance.
-- The services create their own tables automatically on first startup (EF Core EnsureCreated).
IF DB_ID(N'UserDB') IS NULL CREATE DATABASE UserDB;
GO
IF DB_ID(N'InventoryDB') IS NULL CREATE DATABASE InventoryDB;
GO
IF DB_ID(N'OrderDB') IS NULL CREATE DATABASE OrderDB;
GO
IF DB_ID(N'PaymentDB') IS NULL CREATE DATABASE PaymentDB;
GO
IF DB_ID(N'ReportDB') IS NULL CREATE DATABASE ReportDB;
GO
