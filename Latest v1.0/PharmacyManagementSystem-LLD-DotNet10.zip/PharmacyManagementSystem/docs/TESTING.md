# Swagger test checklist mapped to LLD UT01–UT24

Use the Swagger page for each service and set bearer JWT tokens. Expected results below are the LLD's expected HTTP outcomes; actual results must be filled after execution.

| ID | Scenario | Expected |
|---|---|---|
| UT01 | Register valid Doctor | 201 Created |
| UT02 | Register duplicate email | 409 Conflict |
| UT03 | Login valid credentials | 200 OK + JWT |
| UT04 | Login incorrect password | 401 Unauthorized |
| UT05 | Add medicine valid details | 201 Created |
| UT06 | Add medicine negative price | 400 Bad Request |
| UT07 | Check available stock | 200 OK |
| UT08 | Reserve available stock | 200 OK |
| UT09 | Reserve unavailable stock | 409 Conflict |
| UT10 | Release reserved stock | 200 OK |
| UT11 | Place order valid items | 201 Created |
| UT12 | Place order empty items | 400 Bad Request |
| UT13 | Verify pending order | 200 OK |
| UT14 | Reject pending order and release stock | 200 OK |
| UT15 | Verify already rejected order | 409 Conflict |
| UT16 | Process valid payment | 200 OK |
| UT17 | Simulate failed payment | 200 OK with PaymentStatus=Failed |
| UT18 | Repeat idempotency key | 200 OK; same payment returned |
| UT19 | Retrieve invoice for paid order | 200 OK |
| UT20 | Generate/view sales report | 200 OK |
| UT21 | Protected API without token | 401 Unauthorized |
| UT22 | Doctor accesses Admin API | 403 Forbidden |
| UT23 | Send email with valid SMTP | 200 OK |
| UT24 | SMTP failure | 503 Service Unavailable (operationally safer than LLD's generic 500) |

## Manual execution order
1. UT01 then UT02, UT03 and UT04.
2. Promote one test account to Admin directly in UserDB; log in again to get Admin JWT.
3. UT05–UT10; create a supplier before adding medicine.
4. Log in as Doctor; UT11–UT15.
5. Verify an order before UT16–UT18; use a fresh idempotency key for each distinct payment test.
6. Retrieve invoice after successful payment (note: payment success callback changes order to Paid).
7. Configure SMTP and execute UT23–UT24.

## Known gap to resolve before claiming full LLD conformance
The payment callback and Admin pickup orchestration are implemented for this POC. They use a development-only internal shared key; replace it with managed service authentication before deployment. The multi-service pickup flow is not a distributed transaction and needs durable retry/reconciliation for production.
