# Pharmacy Management System (Local Development)

A straightforward local implementation of the supplied 29-page LLD. It uses **.NET 10**, C#, ASP.NET Core Web API, EF Core, SQL Server, LINQ, YARP, JWT, REST/JSON, SMTP, Swagger and NUnit.

This project is intended to run on a developer's Windows machine. **No Docker, cloud account, Kubernetes, hosting, or deployment setup is required.**

## Solution structure

| Project | Port | Database / purpose |
|---|---:|---|
| ApiGateway (YARP) | 5000 | Single entry point for API requests |
| AuthService | 5001 | UserDB |
| InventoryService | 5002 | InventoryDB |
| OrderService | 5003 | OrderDB |
| PaymentService | 5004 | PaymentDB |
| SalesReportService | 5005 | ReportDB |
| NotificationService | 5006 | SMTP; no database, as specified in the LLD |

Each service is a small ASP.NET Core Web API project with its own controllers and database context. Services run as separate local processes to preserve the microservices design in the LLD.

## What you need

1. Windows 10/11.
2. .NET 10 SDK.
3. SQL Server (Developer, Express, or another local SQL Server instance).
4. SQL Server Management Studio (SSMS) is recommended for viewing the databases.
5. Visual Studio 2022 or VS Code (optional; command-line `dotnet` commands also work).

## First-time setup

### 1. Configure SQL Server

The default connection string uses Windows Authentication and assumes the SQL Server instance is `localhost`. If your instance is named differently, update `ConnectionStrings:Default` in the five database-backed services' `appsettings.json` files.

Common examples:

- Default instance: `Server=localhost;Database=UserDB;Trusted_Connection=True;TrustServerCertificate=True;Encrypt=False`
- SQL Express: `Server=localhost\SQLEXPRESS;Database=UserDB;Trusted_Connection=True;TrustServerCertificate=True;Encrypt=False`
- LocalDB: `Server=(localdb)\MSSQLLocalDB;Database=UserDB;Trusted_Connection=True;TrustServerCertificate=True;Encrypt=False`

### 2. Create the databases

Open SSMS, connect to your local SQL Server, open `docs/Create-Databases.sql`, and execute it. It creates the five empty databases. Each service creates its own tables automatically the first time it starts using EF Core `EnsureCreated()`.

### 3. Restore and build

Open a terminal in the folder containing `PharmacyManagementSystem.sln` and run:

```powershell
dotnet restore
dotnet build
```

### 4. Run the application

**Easy option:** double-click `Run-Local.bat`. It opens a separate terminal window for each service and the YARP gateway.

**Visual Studio option:** open `PharmacyManagementSystem.sln`, set the six service projects and `ApiGateway` as multiple startup projects, and start the solution.

**Manual option:** open separate terminals and run `dotnet run --project src/AuthService` (repeat for each project). Run the gateway after the services have started.

**Use only the gateway URL:** `http://localhost:5000/swagger`. The gateway Swagger UI lists all six service APIs (Auth, Inventory, Orders, Payments, Reports, Notifications). OpenAPI JSON documents are proxied through YARP, so API exploration and requests can be performed through the same gateway port. The service ports 5001–5006 are internal local process ports used by YARP; they are not the client entry point.

## First Admin account

Public registration creates a Doctor account, as required by the LLD. To create the first Admin for a local demonstration, register a Doctor, then use SSMS to update that user's `Role` value to `Admin` in `UserDB.dbo.Users`. Do not expose public Admin registration.

## Basic workflow

1. Register a Doctor using `POST /api/auth/register`.
2. Log in using `POST /api/auth/login`; copy the JWT token from the response.
3. In Swagger, click **Authorize** and enter `Bearer YOUR_TOKEN` where supported.
4. Log in as Admin (after provisioning the Admin role) to add suppliers, medicines, and stock.
5. Log in as Doctor to browse medicines and place an order.
6. Admin verifies or rejects the order. Rejection releases reserved stock.
7. Doctor submits a simulated payment. The payment service does not contact a real bank or payment gateway.
8. Finalize pickup after the medicine is collected; this deducts reserved stock.
9. Retrieve invoice information and view sales reports.

## SMTP

Email is optional for local testing. To send real email, configure the `Smtp` values in `src/NotificationService/appsettings.json` with your SMTP provider's host, port, sender, username, and password. Do not commit real credentials. If SMTP is not configured, email sending will not work; the rest of the application can still be tested.

## Testing

The solution includes an NUnit test project. Run:

```powershell
dotnet test
```

The 24 LLD test scenarios are also listed in `docs/TESTING.md` for execution through Swagger. Record the actual HTTP response/status for each scenario.

## Notes

- This is a local proof-of-concept for project demonstration, not a production-ready pharmacy or payment platform.
- The six services and YARP gateway are retained because they are explicitly specified in the LLD; they run locally and do not require deployment.
- Five service-owned SQL Server databases are retained. Relationships across service databases use IDs and APIs, not cross-database foreign keys.
- EF Core `EnsureCreated()` creates tables for a fresh local database. It is convenient for this POC; migrations are preferable for future schema changes.
- Payment is simulated. No actual money is charged.
- No Docker or deployment tools are used.


## Single-port Swagger through YARP

Start all six local service processes and then the gateway. Browse to `http://localhost:5000/swagger`. The Swagger dropdown contains one OpenAPI document per microservice. The gateway proxies each document at `/swagger/{service}/swagger.json` to that service's `/swagger/v1/swagger.json`. All API paths are also routed through port 5000. The backend services still listen on separate localhost ports because they are separate applications, but users should use the gateway only.

## LLD feature coverage

The implementation is organized around the LLD's 16 functional requirements: Doctor registration; Admin/Doctor login; JWT; Admin user management; medicine CRUD/deactivation; supplier CRUD/view; inventory view/update; reservation; Doctor order placement; Admin verification/rejection; simulated payment; payment records; invoice retrieval for successful payments; sales summaries; SMTP notifications; and Doctor order history. The eight LLD entities are `User`, `Drug`, `Supplier`, `Inventory` (stock), `Order`, `OrderItem`, `Payment`, and `SalesReport`, distributed over the five LLD databases. Cross-service IDs are logical references; no cross-database foreign keys are created.
