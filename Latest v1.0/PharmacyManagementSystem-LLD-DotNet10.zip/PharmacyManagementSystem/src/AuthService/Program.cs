using Microsoft.EntityFrameworkCore; using Microsoft.AspNetCore.Authentication.JwtBearer; using Microsoft.IdentityModel.Tokens; using System.Text; using Pharmacy.Auth;
var builder=WebApplication.CreateBuilder(args); builder.Services.AddControllers(); builder.Services.AddEndpointsApiExplorer(); builder.Services.AddSwaggerGen();
builder.Services.AddDbContext<AuthDb>(o=>o.UseSqlServer(builder.Configuration.GetConnectionString("Default")));
var key=builder.Configuration["Jwt:Key"]!; builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(o=>{o.TokenValidationParameters=new(){ValidateIssuer=true,ValidateAudience=true,ValidateLifetime=true,ValidateIssuerSigningKey=true,ValidIssuer=builder.Configuration["Jwt:Issuer"],ValidAudience=builder.Configuration["Jwt:Audience"],IssuerSigningKey=new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key))};});
builder.Services.AddAuthorization(); builder.Services.AddScoped<AuthService>();
var app=builder.Build(); using(var scope=app.Services.CreateScope()){try{scope.ServiceProvider.GetRequiredService<AuthDb>().Database.EnsureCreated();}catch(Exception e){app.Logger.LogError(e,"Database initialization failed");}}
app.UseSwagger(); app.UseSwaggerUI(); app.UseAuthentication(); app.UseAuthorization(); app.MapControllers(); app.MapGet("/health",()=>Results.Ok(new{service="AuthService",status="Healthy"})); app.Run();
