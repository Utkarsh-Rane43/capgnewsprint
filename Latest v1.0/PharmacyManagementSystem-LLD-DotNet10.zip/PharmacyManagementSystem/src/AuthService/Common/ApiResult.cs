namespace Pharmacy.Common;
public record ApiResult<T>(bool Success,string Message,T? Data=null,object? Errors=null);
