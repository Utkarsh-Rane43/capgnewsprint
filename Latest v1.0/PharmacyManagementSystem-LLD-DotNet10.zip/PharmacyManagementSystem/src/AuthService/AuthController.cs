using Microsoft.AspNetCore.Mvc;using Microsoft.AspNetCore.Authorization;using Microsoft.EntityFrameworkCore; namespace Pharmacy.Auth;
[ApiController][Route("api")]
public class AuthController(AuthService service,AuthDb db):ControllerBase{
 [HttpPost("auth/register")] public async Task<IActionResult> Register(RegisterRequest r){try{var u=await service.Register(r.FullName,r.Email,r.Password,r.Phone??"");return StatusCode(201,new{success=true,message="User registered successfully",data=new{u.UserId,u.FullName,u.Email,u.Role}});}catch(InvalidOperationException e){return Conflict(new{success=false,message=e.Message});}catch(ArgumentException e){return BadRequest(new{success=false,message=e.Message});}}
 [HttpPost("auth/login")] public async Task<IActionResult> Login(LoginRequest r){try{var (u,t)=await service.Login(r.Email,r.Password);return Ok(new{success=true,message="Login successful",data=new{u.UserId,u.Email,u.Role,token=t,expiresIn=3600}});}catch(UnauthorizedAccessException e){return Unauthorized(new{success=false,message=e.Message});}}
 [Authorize(Roles="Admin")][HttpGet("users")] public async Task<IActionResult> Users()=>Ok(await db.Users.Select(u=>new{u.UserId,u.FullName,u.Email,u.Role,u.IsActive}).ToListAsync());
 [Authorize][HttpGet("users/{id:int}")] public async Task<IActionResult> User(int id){var u=await db.Users.FindAsync(id);return u==null?NotFound():Ok(new{u.UserId,u.FullName,u.Email,u.Role,u.IsActive});}
 [Authorize(Roles="Admin")][HttpPut("users/{id:int}")] public async Task<IActionResult> Update(int id,UpdateUserRequest r){var u=await db.Users.FindAsync(id);if(u==null)return NotFound();u.FullName=r.FullName;u.IsActive=r.IsActive;await db.SaveChangesAsync();return NoContent();}
}
public record RegisterRequest(string FullName,string Email,string Password,string? Phone);public record LoginRequest(string Email,string Password);public record UpdateUserRequest(string FullName,bool IsActive);
