using Pharmacy.Notify;
var b=WebApplication.CreateBuilder(args);b.Services.AddControllers();b.Services.AddEndpointsApiExplorer();b.Services.AddSwaggerGen();b.Services.AddScoped<EmailSender>();var app=b.Build();app.UseSwagger();app.UseSwaggerUI();app.MapControllers();app.MapGet("/health",()=>Results.Ok(new{service="NotificationService",status="Healthy"}));app.Run();
