@echo off
setlocal
cd /d "%~dp0"
echo Starting Pharmacy Management System services...
echo Make sure SQL Server is running and the .NET 10 SDK is installed.
start "Auth Service - 5001" cmd /k "dotnet run --project src\AuthService"
start "Inventory Service - 5002" cmd /k "dotnet run --project src\InventoryService"
start "Order Service - 5003" cmd /k "dotnet run --project src\OrderService"
start "Payment Service - 5004" cmd /k "dotnet run --project src\PaymentService"
start "Sales Report Service - 5005" cmd /k "dotnet run --project src\SalesReportService"
start "Notification Service - 5006" cmd /k "dotnet run --project src\NotificationService"
timeout /t 5 /nobreak >nul
start "YARP API Gateway - 5000" cmd /k "dotnet run --project src\ApiGateway"
echo.
echo Services are starting. Gateway: http://localhost:5000
echo Swagger (single entry point): http://localhost:5000/swagger
echo Use the gateway for all API calls. Service ports 5001-5006 are internal local ports.
echo Close each service window to stop that service.
