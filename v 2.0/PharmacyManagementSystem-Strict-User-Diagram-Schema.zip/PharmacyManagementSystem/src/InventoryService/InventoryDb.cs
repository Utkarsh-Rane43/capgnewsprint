using Microsoft.EntityFrameworkCore;
namespace Pharmacy.Inventory;
public class InventoryDb(DbContextOptions<InventoryDb> options) : DbContext(options)
{
    public DbSet<Drug> Drugs => Set<Drug>();
    public DbSet<Supplier> Suppliers => Set<Supplier>();
    public DbSet<Stock> Inventory => Set<Stock>();
    protected override void OnModelCreating(ModelBuilder b)
    {
        var d=b.Entity<Drug>(); d.ToTable("Drugs"); d.HasKey(x=>x.DrugId);
        d.Property(x=>x.DrugName).HasMaxLength(100).IsRequired(); d.Property(x=>x.Manufacturer).HasMaxLength(100).IsRequired();
        d.Property(x=>x.Price).HasPrecision(10,2); d.Property(x=>x.ExpiryDate).HasColumnType("date"); d.Ignore(x=>x.Description); d.Ignore(x=>x.IsActive);
        var s=b.Entity<Supplier>(); s.ToTable("Suppliers"); s.HasKey(x=>x.SupplierId);
        s.Property(x=>x.SupplierName).HasMaxLength(100).IsRequired(); s.Property(x=>x.Email).HasMaxLength(150); s.Property(x=>x.Phone).HasMaxLength(20); s.Property(x=>x.Address).HasMaxLength(255); s.Ignore(x=>x.ContactPerson);
        var i=b.Entity<Stock>(); i.ToTable("Inventory"); i.HasKey(x=>x.InventoryId); i.HasIndex(x=>x.DrugId).IsUnique(); i.Ignore(x=>x.RowVersion);
        d.HasOne<Supplier>().WithMany().HasForeignKey(x=>x.SupplierId).OnDelete(DeleteBehavior.Restrict);
        i.HasOne<Drug>().WithMany().HasForeignKey(x=>x.DrugId).OnDelete(DeleteBehavior.Restrict);
    }
}
public class Drug { public int DrugId {get;set;} public string DrugName {get;set;}=""; public string Description {get;set;}=""; public string Manufacturer {get;set;}=""; public decimal Price {get;set;} public DateTime ExpiryDate {get;set;} public int SupplierId {get;set;} public bool IsActive {get;set;}=true; }
public class Supplier { public int SupplierId {get;set;} public string SupplierName {get;set;}=""; public string ContactPerson {get;set;}=""; public string Email {get;set;}=""; public string Phone {get;set;}=""; public string Address {get;set;}=""; }
public class Stock { public int InventoryId {get;set;} public int DrugId {get;set;} public int AvailableQuantity {get;set;} public int ReservedQuantity {get;set;} public byte[] RowVersion {get;set;}=[]; }
