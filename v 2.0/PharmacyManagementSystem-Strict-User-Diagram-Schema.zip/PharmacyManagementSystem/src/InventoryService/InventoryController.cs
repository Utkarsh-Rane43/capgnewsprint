using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
namespace Pharmacy.Inventory;
[ApiController]
[Route("api")]
[Authorize]
public class InventoryController(InventoryDb db, IConfiguration config) : ControllerBase
{
    [HttpPost("drugs"), Authorize(Roles = "Admin")]
    public async Task<IActionResult> AddDrug(DrugRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.DrugName) || request.Price <= 0 || request.ExpiryDate.Date <= DateTime.Today || request.InitialQuantity < 0)
            return BadRequest(new { success = false, message = "Medicine name, positive price, future expiry date and non-negative initial quantity are required." });
        if (!await db.Suppliers.AnyAsync(x => x.SupplierId == request.SupplierId)) return BadRequest(new { message = "Supplier does not exist." });
        var drug = new Drug { DrugName = request.DrugName.Trim(), Description = request.Description ?? "", Manufacturer = request.Manufacturer ?? "", Price = request.Price, ExpiryDate = request.ExpiryDate, SupplierId = request.SupplierId };
        var strategy = db.Database.CreateExecutionStrategy();
        await strategy.ExecuteAsync(async () =>
        {
            await using var tx = await db.Database.BeginTransactionAsync();
            db.Drugs.Add(drug); await db.SaveChangesAsync();
            db.Inventory.Add(new Stock { DrugId = drug.DrugId, AvailableQuantity = request.InitialQuantity, ReservedQuantity = 0 });
            await db.SaveChangesAsync();
            await tx.CommitAsync();
        });
        return Created($"/api/drugs/{drug.DrugId}", new { drug.DrugId, drug.DrugName, drug.Description, drug.Manufacturer, drug.Price, drug.ExpiryDate, drug.SupplierId, drug.IsActive, request.InitialQuantity });
    }
    [HttpGet("drugs")]
    public async Task<IActionResult> Drugs() => Ok(await db.Drugs.Where(x => x.IsActive).ToListAsync());
    [HttpGet("drugs/{id:int}")]
    public async Task<IActionResult> Drug(int id) { var drug = await db.Drugs.FindAsync(id); return drug is null ? NotFound() : Ok(drug); }
    [HttpPut("drugs/{id:int}"), Authorize(Roles = "Admin")]
    public async Task<IActionResult> UpdateDrug(int id, DrugRequest request)
    {
        var drug = await db.Drugs.FindAsync(id); if (drug is null) return NotFound();
        if (string.IsNullOrWhiteSpace(request.DrugName) || request.Price <= 0 || request.ExpiryDate.Date <= DateTime.Today) return BadRequest(new { message = "Invalid medicine details." });
        if (!await db.Suppliers.AnyAsync(x => x.SupplierId == request.SupplierId)) return BadRequest(new { message = "Supplier does not exist." });
        drug.DrugName = request.DrugName.Trim(); drug.Description = request.Description ?? ""; drug.Manufacturer = request.Manufacturer ?? ""; drug.Price = request.Price; drug.ExpiryDate = request.ExpiryDate; drug.SupplierId = request.SupplierId;
        await db.SaveChangesAsync(); return Ok(drug);
    }
    [HttpDelete("drugs/{id:int}"), Authorize(Roles = "Admin")]
    public async Task<IActionResult> Deactivate(int id) { var drug = await db.Drugs.FindAsync(id); if (drug is null) return NotFound(); drug.IsActive = false; await db.SaveChangesAsync(); return NoContent(); }

    [HttpPost("suppliers"), Authorize(Roles = "Admin")]
    public async Task<IActionResult> AddSupplier(SupplierRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.SupplierName)) return BadRequest(new { message = "Supplier name is required." });
        var supplier = new Supplier { SupplierName = request.SupplierName.Trim(), ContactPerson = request.ContactPerson ?? "", Email = request.Email ?? "", Phone = request.Phone ?? "", Address = request.Address ?? "" };
        db.Suppliers.Add(supplier); await db.SaveChangesAsync(); return Created($"/api/suppliers/{supplier.SupplierId}", supplier);
    }
    [HttpGet("suppliers")] public async Task<IActionResult> Suppliers() => Ok(await db.Suppliers.ToListAsync());
    [HttpGet("suppliers/{id:int}")] public async Task<IActionResult> Supplier(int id) { var supplier = await db.Suppliers.FindAsync(id); return supplier is null ? NotFound() : Ok(supplier); }
    [HttpPut("suppliers/{id:int}"), Authorize(Roles = "Admin")]
    public async Task<IActionResult> UpdateSupplier(int id, SupplierRequest request)
    {
        var supplier = await db.Suppliers.FindAsync(id); if (supplier is null) return NotFound();
        if (string.IsNullOrWhiteSpace(request.SupplierName)) return BadRequest(new { message = "Supplier name is required." });
        supplier.SupplierName = request.SupplierName.Trim(); supplier.ContactPerson = request.ContactPerson ?? ""; supplier.Email = request.Email ?? ""; supplier.Phone = request.Phone ?? ""; supplier.Address = request.Address ?? "";
        await db.SaveChangesAsync(); return Ok(supplier);
    }

    [HttpGet("inventory")] public async Task<IActionResult> AllStock() => Ok(await db.Inventory.Join(db.Drugs, i => i.DrugId, d => d.DrugId, (i, d) => new { d.DrugId, d.DrugName, i.AvailableQuantity, i.ReservedQuantity, PhysicalStock = i.AvailableQuantity + i.ReservedQuantity }).ToListAsync());
    [HttpGet("inventory/{drugId:int}")] public async Task<IActionResult> Stock(int drugId) { var stock = await db.Inventory.SingleOrDefaultAsync(x => x.DrugId == drugId); return stock is null ? NotFound() : Ok(stock); }
    [HttpPut("inventory/{drugId:int}"), Authorize(Roles = "Admin")]
    public async Task<IActionResult> UpdateStock(int drugId, QuantityRequest request)
    {
        if (request.Quantity < 0) return BadRequest(new { message = "Quantity cannot be negative." });
        var stock = await db.Inventory.SingleOrDefaultAsync(x => x.DrugId == drugId); if (stock is null) return NotFound();
        stock.AvailableQuantity = request.Quantity; await SaveStockAsync(); return Ok(stock);
    }

    [AllowAnonymous, HttpPost("inventory/reserve")]
    public async Task<IActionResult> Reserve(StockRequest request)
    {
        if (!IsInternalRequest() && !User.IsInRole("Admin")) return Unauthorized();
        if (request.Quantity <= 0) return BadRequest(new { message = "Quantity must be greater than zero." });
        var stock = await db.Inventory.SingleOrDefaultAsync(x => x.DrugId == request.DrugId); if (stock is null) return NotFound();
        if (stock.AvailableQuantity < request.Quantity) return Conflict(new { message = "Insufficient stock." });
        stock.AvailableQuantity -= request.Quantity; stock.ReservedQuantity += request.Quantity;
        try { await SaveStockAsync(); } catch (DbUpdateConcurrencyException) { return Conflict(new { message = "Stock changed concurrently. Retry the order." }); }
        return Ok(new { success = true, message = "Stock reserved", stock.AvailableQuantity, stock.ReservedQuantity });
    }
    [AllowAnonymous, HttpPost("inventory/release")]
    public async Task<IActionResult> Release(StockRequest request)
    {
        if (!IsInternalRequest() && !User.IsInRole("Admin")) return Unauthorized();
        var stock = await db.Inventory.SingleOrDefaultAsync(x => x.DrugId == request.DrugId); if (stock is null) return NotFound();
        if (request.Quantity <= 0 || stock.ReservedQuantity < request.Quantity) return Conflict(new { message = "Invalid release quantity." });
        stock.ReservedQuantity -= request.Quantity; stock.AvailableQuantity += request.Quantity;
        try { await SaveStockAsync(); } catch (DbUpdateConcurrencyException) { return Conflict(new { message = "Stock changed concurrently. Retry the operation." }); }
        return Ok(new { success = true, message = "Reserved stock released", stock.AvailableQuantity, stock.ReservedQuantity });
    }
    [AllowAnonymous, HttpPost("inventory/finalize-pickup")]
    public async Task<IActionResult> FinalizePickup(StockRequest request)
    {
        if (!IsInternalRequest() && !User.IsInRole("Admin")) return Unauthorized();
        var stock = await db.Inventory.SingleOrDefaultAsync(x => x.DrugId == request.DrugId); if (stock is null) return NotFound();
        if (request.Quantity <= 0 || stock.ReservedQuantity < request.Quantity) return Conflict(new { message = "Insufficient reserved stock." });
        stock.ReservedQuantity -= request.Quantity;
        try { await SaveStockAsync(); } catch (DbUpdateConcurrencyException) { return Conflict(new { message = "Stock changed concurrently. Retry the operation." }); }
        return Ok(new { success = true, message = "Pickup finalized", stock.AvailableQuantity, stock.ReservedQuantity });
    }
    private bool IsInternalRequest() => !string.IsNullOrWhiteSpace(config["Internal:ServiceKey"]) && Request.Headers["X-Internal-Key"] == config["Internal:ServiceKey"];
    private async Task SaveStockAsync() => await db.SaveChangesAsync();
}
public record DrugRequest(string DrugName, string? Manufacturer, decimal Price, DateTime ExpiryDate, int SupplierId, int InitialQuantity = 0, string? Description = null);
public record SupplierRequest(string SupplierName, string? ContactPerson, string? Email, string? Phone, string? Address);
public record StockRequest(int DrugId, int Quantity);
public record QuantityRequest(int Quantity);
