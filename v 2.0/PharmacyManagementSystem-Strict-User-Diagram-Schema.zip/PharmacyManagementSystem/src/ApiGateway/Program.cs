var builder = WebApplication.CreateBuilder(args);
builder.Services.AddReverseProxy().LoadFromConfig(builder.Configuration.GetSection("ReverseProxy"));
var app = builder.Build();
app.MapGet("/health", () => Results.Ok(new { service = "ApiGateway", status = "Healthy" }));
app.MapGet("/", () => Results.Redirect("/swagger"));
app.UseSwaggerUI(options =>
{
    options.RoutePrefix = "swagger";
    options.DocumentTitle = "Pharmacy Management System API";
    options.SwaggerEndpoint("/swagger/auth/swagger.json", "Auth Service");
    options.SwaggerEndpoint("/swagger/inventory/swagger.json", "Inventory Service");
    options.SwaggerEndpoint("/swagger/orders/swagger.json", "Order Service");
    options.SwaggerEndpoint("/swagger/payments/swagger.json", "Payment Service");
    options.SwaggerEndpoint("/swagger/reports/swagger.json", "Sales Report Service");
    options.SwaggerEndpoint("/swagger/notifications/swagger.json", "Notification Service");
});
app.MapReverseProxy();
app.Run();
