using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using System.Net.Http.Json;
namespace Pharmacy.Orders;
[ApiController, Route("api/orders"), Authorize]
public class OrderController(OrderDb db, IHttpClientFactory clients, IConfiguration config) : ControllerBase
{
    [HttpPost, Authorize(Roles = "Doctor")]
    public async Task<IActionResult> Place(PlaceOrderRequest request)
    {
        if (request.Items is null || request.Items.Count == 0 || request.Items.Any(x => x.Quantity <= 0)) return BadRequest(new { message = "Order must contain at least one item with a positive quantity." });
        var userId = GetUserId(); if (userId <= 0) return Unauthorized();
        var inventory = clients.CreateClient("Inventory"); ForwardUserToken(inventory);
        var items = new List<OrderItem>(); decimal total = 0;
        foreach (var requested in request.Items)
        {
            var drugResponse = await inventory.GetAsync($"/api/drugs/{requested.DrugId}");
            if (!drugResponse.IsSuccessStatusCode) return BadRequest(new { message = $"Medicine {requested.DrugId} was not found or is unavailable." });
            var drug = await drugResponse.Content.ReadFromJsonAsync<DrugDto>();
            if (drug is null || !drug.IsActive || drug.ExpiryDate.Date <= DateTime.UtcNow.Date) return BadRequest(new { message = "Medicine is inactive, expired or invalid." });
            var stockResponse = await inventory.GetAsync($"/api/inventory/{requested.DrugId}");
            if (!stockResponse.IsSuccessStatusCode) return Conflict(new { message = $"Stock for medicine {requested.DrugId} is unavailable." });
            var stock = await stockResponse.Content.ReadFromJsonAsync<StockDto>();
            if (stock is null || stock.AvailableQuantity < requested.Quantity) return Conflict(new { message = $"Insufficient stock for medicine {requested.DrugId}." });
            var lineTotal = drug.Price * requested.Quantity;
            items.Add(new OrderItem { DrugId = requested.DrugId, Quantity = requested.Quantity, UnitPrice = drug.Price, SubTotal = lineTotal });
            total += lineTotal;
        }
        var reserved = new List<OrderItem>();
        foreach (var item in items)
        {
            var response = await PostInternalInventoryAsync(inventory, "reserve", item.DrugId, item.Quantity);
            if (!response.IsSuccessStatusCode)
            {
                foreach (var previous in reserved) await PostInternalInventoryAsync(inventory, "release", previous.DrugId, previous.Quantity);
                return Conflict(new { message = "Stock reservation failed. No order was created; completed reservations were released." });
            }
            reserved.Add(item);
        }
        var order = new Order { UserId = userId, TotalAmount = total, Items = items };
        db.Orders.Add(order);
        try { await db.SaveChangesAsync(); }
        catch
        {
            foreach (var item in reserved) await PostInternalInventoryAsync(inventory, "release", item.DrugId, item.Quantity);
            throw;
        }
        await TryNotifyAsync(userId, $"Order {order.OrderId} placed", $"Your order {order.OrderId} is awaiting Admin verification.");
        return StatusCode(201, new { success = true, message = "Order placed successfully", data = new { order.OrderId, order.TotalAmount, order.OrderStatus, order.PaymentStatus } });
    }
    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        IQueryable<Order> query = db.Orders.Include(x => x.Items);
        if (!User.IsInRole("Admin")) query = query.Where(x => x.UserId == GetUserId());
        return Ok(await query.OrderByDescending(x => x.OrderDate).ToListAsync());
    }
    [HttpGet("my-orders"), Authorize(Roles = "Doctor")]
    public async Task<IActionResult> Mine() => Ok(await db.Orders.Include(x => x.Items).Where(x => x.UserId == GetUserId()).OrderByDescending(x => x.OrderDate).ToListAsync());
    [HttpGet("{id:int}")]
    public async Task<IActionResult> Get(int id)
    {
        var order = await db.Orders.Include(x => x.Items).SingleOrDefaultAsync(x => x.OrderId == id);
        if (order is null) return NotFound();
        if (!User.IsInRole("Admin") && order.UserId != GetUserId()) return Forbid();
        return Ok(order);
    }
    [HttpPut("{id:int}/verify"), Authorize(Roles = "Admin")]
    public async Task<IActionResult> Verify(int id)
    {
        var order = await db.Orders.Include(x => x.Items).SingleOrDefaultAsync(x => x.OrderId == id);
        if (order is null) return NotFound();
        if (order.OrderStatus != "PendingVerification") return Conflict(new { message = "Only pending orders can be verified." });
        order.OrderStatus = "Verified"; await db.SaveChangesAsync();
        await TryNotifyAsync(order.UserId, $"Order {id} verified", $"Your order {id} has been verified. You can now make payment.");
        return Ok(new { success = true, message = "Order verified", data = order });
    }
    [HttpPut("{id:int}/reject"), Authorize(Roles = "Admin")]
    public async Task<IActionResult> Reject(int id)
    {
        var order = await db.Orders.Include(x => x.Items).SingleOrDefaultAsync(x => x.OrderId == id);
        if (order is null) return NotFound();
        if (order.OrderStatus != "PendingVerification") return Conflict(new { message = "Only pending orders can be rejected." });
        var inventory = clients.CreateClient("Inventory");
        foreach (var item in order.Items)
        {
            var response = await PostInternalInventoryAsync(inventory, "release", item.DrugId, item.Quantity);
            if (!response.IsSuccessStatusCode) return StatusCode(502, new { message = "Could not release reserved stock. Order remains pending; retry after Inventory Service is available." });
        }
        order.OrderStatus = "Rejected"; await db.SaveChangesAsync();
        await TryNotifyAsync(order.UserId, $"Order {id} rejected", $"Your order {id} was rejected by the Admin.");
        return Ok(new { success = true, message = "Order rejected and reserved stock released", data = order });
    }
    [AllowAnonymous, HttpPost("/internal/orders/{id:int}/payment-status")]
    public async Task<IActionResult> PaymentStatus(int id, PaymentStatusRequest request)
    {
        if (!IsInternalRequest()) return Unauthorized();
        if (request.Status is not ("Success" or "Failed")) return BadRequest(new { message = "Payment status must be Success or Failed." });
        var order = await db.Orders.FindAsync(id); if (order is null) return NotFound();
        if (request.Status == "Success" && order.PaymentStatus == "Success" && (order.OrderStatus is "Paid" or "PickedUp"))
            return Ok(new { success = true, order.OrderId, order.OrderStatus, order.PaymentStatus });
        if (request.Status == "Success" && order.OrderStatus != "Verified") return Conflict(new { message = "Only verified orders can be marked paid." });
        order.PaymentStatus = request.Status;
        if (request.Status == "Success") order.OrderStatus = "Paid";
        await db.SaveChangesAsync(); return Ok(new { success = true, order.OrderId, order.OrderStatus, order.PaymentStatus });
    }
    [HttpPost("{id:int}/finalize-pickup"), Authorize(Roles = "Admin")]
    public async Task<IActionResult> FinalizePickup(int id)
    {
        var order = await db.Orders.Include(x => x.Items).SingleOrDefaultAsync(x => x.OrderId == id);
        if (order is null) return NotFound();
        if (order.OrderStatus != "Paid") return Conflict(new { message = "Only paid orders can be picked up." });
        var inventory = clients.CreateClient("Inventory");
        foreach (var item in order.Items)
        {
            var response = await PostInternalInventoryAsync(inventory, "finalize-pickup", item.DrugId, item.Quantity);
            if (!response.IsSuccessStatusCode) return StatusCode(502, new { message = "Inventory finalization failed. Do not retry blindly; reconcile reserved quantities before retrying." });
        }
        order.OrderStatus = "PickedUp"; await db.SaveChangesAsync();
        return Ok(new { success = true, message = "Pickup finalized", data = order });
    }
    [AllowAnonymous, HttpGet("/internal/orders/sales-summary")]
    public async Task<IActionResult> SalesSummary([FromQuery] DateTime from, [FromQuery] DateTime to)
    {
        if (!IsInternalRequest()) return Unauthorized();
        if (to < from) return BadRequest(new { message = "The 'to' date must be on or after the 'from' date." });
        var start = from.Date; var end = to.Date.AddDays(1);
        var summary = await db.Orders.Where(x => (x.OrderStatus == "Paid" || x.OrderStatus == "PickedUp") && x.OrderDate >= start && x.OrderDate < end)
            .GroupBy(_ => 1).Select(g => new { TotalOrders = g.Count(), TotalSales = g.Sum(x => x.TotalAmount) })
            .SingleOrDefaultAsync();
        return Ok(new { totalOrders = summary?.TotalOrders ?? 0, totalSales = summary?.TotalSales ?? 0m });
    }
    private int GetUserId() => int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier) ?? User.FindFirstValue("sub"), out var id) ? id : 0;
    private void ForwardUserToken(HttpClient client)
    {
        var token = Request.Headers.Authorization.ToString();
        if (!string.IsNullOrWhiteSpace(token)) client.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", token);
    }
    private async Task<HttpResponseMessage> PostInternalInventoryAsync(HttpClient client, string action, int drugId, int quantity)
    {
        using var request = new HttpRequestMessage(HttpMethod.Post, $"/api/inventory/{action}") { Content = JsonContent.Create(new { drugId, quantity }) };
        request.Headers.Add("X-Internal-Key", config["Internal:ServiceKey"] ?? "");
        return await client.SendAsync(request);
    }
    private bool IsInternalRequest() => !string.IsNullOrWhiteSpace(config["Internal:ServiceKey"]) && Request.Headers["X-Internal-Key"] == config["Internal:ServiceKey"];
    private async Task TryNotifyAsync(int userId, string subject, string body)
    {
        try
        {
            var auth = clients.CreateClient("Auth");
            ForwardUserToken(auth);
            var userResponse = await auth.GetAsync($"/api/users/{userId}");
            if (!userResponse.IsSuccessStatusCode) return;
            var user = await userResponse.Content.ReadFromJsonAsync<AuthUserDto>();
            if (user is null || string.IsNullOrWhiteSpace(user.Email)) return;
            await clients.CreateClient("Notify").PostAsJsonAsync("/api/notifications/email", new { to = user.Email, subject, body });
        }
        catch { /* Notification is best-effort; order processing must remain available. */ }
    }
}
public record PlaceOrderRequest(List<PlaceOrderItem> Items);
public record PlaceOrderItem(int DrugId, int Quantity);
public record DrugDto(int DrugId, string DrugName, string Description, string Manufacturer, decimal Price, DateTime ExpiryDate, int SupplierId, bool IsActive);
public record StockDto(int InventoryId, int DrugId, int AvailableQuantity, int ReservedQuantity);
public record PaymentStatusRequest(string Status);
public record AuthUserDto(int UserId, string FullName, string Email, string Role, bool IsActive);
