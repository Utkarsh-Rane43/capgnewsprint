using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
namespace Pharmacy.Orders;
[ApiController, Route("api/invoices"), Authorize]
public class InvoiceController(OrderDb db) : ControllerBase
{
    [HttpGet("{orderId:int}")]
    public async Task<IActionResult> Get(int orderId)
    {
        var order = await db.Orders.Include(x => x.Items).SingleOrDefaultAsync(x => x.OrderId == orderId);
        if (order is null) return NotFound();
        var userId = int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier) ?? User.FindFirstValue("sub"), out var id) ? id : 0;
        if (!User.IsInRole("Admin") && userId != order.UserId) return Forbid();
        if (order.PaymentStatus != "Success" || order.OrderStatus is not ("Paid" or "PickedUp")) return Conflict(new { message = "Invoice is available only after successful payment." });
        return Ok(new { success = true, data = new { invoiceNumber = $"INV-{order.OrderId}", order.OrderId, order.OrderDate, order.TotalAmount, order.PaymentStatus, items = order.Items } });
    }
}
