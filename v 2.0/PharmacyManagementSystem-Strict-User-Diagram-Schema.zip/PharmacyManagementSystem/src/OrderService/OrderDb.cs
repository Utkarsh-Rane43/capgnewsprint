using Microsoft.EntityFrameworkCore;
namespace Pharmacy.Orders;
public class OrderDb(DbContextOptions<OrderDb> options) : DbContext(options)
{
 public DbSet<Order> Orders=>Set<Order>(); public DbSet<OrderItem> OrderItems=>Set<OrderItem>();
 protected override void OnModelCreating(ModelBuilder b){ var o=b.Entity<Order>(); o.ToTable("Orders"); o.HasKey(x=>x.OrderId); o.Property(x=>x.TotalAmount).HasPrecision(10,2); o.Property(x=>x.OrderDate).HasColumnType("datetime"); o.Property(x=>x.OrderStatus).HasMaxLength(20); o.Ignore(x=>x.PaymentStatus); var i=b.Entity<OrderItem>(); i.ToTable("OrderItems"); i.HasKey(x=>x.OrderItemId); i.Property(x=>x.UnitPrice).HasPrecision(10,2); i.Property(x=>x.SubTotal).HasPrecision(10,2); o.HasMany(x=>x.Items).WithOne().HasForeignKey(x=>x.OrderId).OnDelete(DeleteBehavior.Cascade); }
}
public class Order { public int OrderId{get;set;} public int UserId{get;set;} public DateTime OrderDate{get;set;}=DateTime.UtcNow; public decimal TotalAmount{get;set;} public string OrderStatus{get;set;}="PendingVerification"; public string PaymentStatus{get;set;}="Pending"; public List<OrderItem> Items{get;set;}=[]; }
public class OrderItem { public int OrderItemId{get;set;} public int OrderId{get;set;} public int DrugId{get;set;} public int Quantity{get;set;} public decimal UnitPrice{get;set;} public decimal SubTotal{get;set;} }
