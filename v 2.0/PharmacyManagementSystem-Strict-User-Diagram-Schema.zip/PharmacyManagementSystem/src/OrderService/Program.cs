using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using Pharmacy.Orders;

var b = WebApplication.CreateBuilder(args);
b.Services.AddControllers(); b.Services.AddEndpointsApiExplorer();
b.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo
    {
        Title = "Pharmacy Order Service",
        Version = "v1"
    });
    options.AddSecurityDefinition("Bearer", new Microsoft.OpenApi.Models.OpenApiSecurityScheme
    {
        Name = "Authorization",
        Type = Microsoft.OpenApi.Models.SecuritySchemeType.Http,
        Scheme = "bearer",
        BearerFormat = "JWT",
        In = Microsoft.OpenApi.Models.ParameterLocation.Header,
        Description = "Paste the JWT access token. Swagger sends it as Authorization: Bearer <token>."
    });
    options.AddSecurityRequirement(new Microsoft.OpenApi.Models.OpenApiSecurityRequirement
    {
        {
            new Microsoft.OpenApi.Models.OpenApiSecurityScheme
            {
                Reference = new Microsoft.OpenApi.Models.OpenApiReference
                {
                    Type = Microsoft.OpenApi.Models.ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            Array.Empty<string>()
        }
    });
});
b.Services.AddDbContext<OrderDb>(options => options.UseSqlServer(
    b.Configuration.GetConnectionString("Default"),
    sql => sql.EnableRetryOnFailure(3, TimeSpan.FromSeconds(5), null)));
b.Services.AddHttpClient("Inventory", c => c.BaseAddress = new Uri(b.Configuration["Services:Inventory"] ?? "http://localhost:5002"));
b.Services.AddHttpClient("Auth", c => c.BaseAddress = new Uri(b.Configuration["Services:Auth"] ?? "http://localhost:5001"));
b.Services.AddHttpClient("Notify", c => c.BaseAddress = new Uri(b.Configuration["Services:Notification"] ?? "http://localhost:5006"));
var jwtKey = b.Configuration["Jwt:Key"] ?? throw new InvalidOperationException("Jwt:Key is missing.");
b.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(options => options.TokenValidationParameters = new TokenValidationParameters
{
    ValidateIssuer = true, ValidateAudience = true, ValidateLifetime = true, ValidateIssuerSigningKey = true,
    ValidIssuer = b.Configuration["Jwt:Issuer"], ValidAudience = b.Configuration["Jwt:Audience"],
    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey)),
    NameClaimType = System.Security.Claims.ClaimTypes.NameIdentifier,
    RoleClaimType = System.Security.Claims.ClaimTypes.Role
});
b.Services.AddAuthorization();
var app = b.Build();
using (var scope = app.Services.CreateScope()) scope.ServiceProvider.GetRequiredService<OrderDb>().Database.EnsureCreated();
app.UseSwagger(); app.UseSwaggerUI(); app.UseAuthentication(); app.UseAuthorization();
app.MapControllers(); app.MapGet("/health", () => Results.Ok(new { service = "OrderService", status = "Healthy" })); app.Run();
