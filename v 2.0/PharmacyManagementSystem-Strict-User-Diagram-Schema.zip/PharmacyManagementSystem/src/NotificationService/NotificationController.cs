using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;
namespace Pharmacy.Notify;
[ApiController, Route("api/notifications")]
public class NotificationController(EmailSender sender, ILogger<NotificationController> logger) : ControllerBase
{
    [HttpPost("email")]
    public async Task<IActionResult> Send(EmailRequest request)
    {
        if (!new EmailAddressAttribute().IsValid(request.To)) return BadRequest(new { success = false, message = "A valid recipient email is required." });
        try { await sender.Send(request.To, request.Subject, request.Body); return Ok(new { success = true, message = "Email sent" }); }
        catch (Exception ex) { logger.LogError(ex, "Email delivery failed"); return StatusCode(503, new { success = false, message = "Email delivery failed. Check SMTP configuration and service logs." }); }
    }
}
public record EmailRequest(string To, string Subject, string Body);
