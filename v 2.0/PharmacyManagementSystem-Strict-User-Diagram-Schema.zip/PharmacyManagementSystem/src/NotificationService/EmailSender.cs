using System.Net;
using System.Net.Mail;
namespace Pharmacy.Notify;
public class EmailSender(IConfiguration config)
{
    public async Task Send(string to, string subject, string body)
    {
        var host = config["Smtp:Host"];
        var from = config["Smtp:From"];
        if (string.IsNullOrWhiteSpace(host) || string.IsNullOrWhiteSpace(from)) throw new InvalidOperationException("SMTP is not configured. Set Smtp:Host and Smtp:From.");
        using var message = new MailMessage(from, to, subject, body);
        using var client = new SmtpClient(host, int.TryParse(config["Smtp:Port"], out var port) ? port : 587)
        {
            EnableSsl = bool.TryParse(config["Smtp:EnableSsl"], out var ssl) ? ssl : true,
            Credentials = new NetworkCredential(config["Smtp:Username"], config["Smtp:Password"])
        };
        await client.SendMailAsync(message);
    }
}
