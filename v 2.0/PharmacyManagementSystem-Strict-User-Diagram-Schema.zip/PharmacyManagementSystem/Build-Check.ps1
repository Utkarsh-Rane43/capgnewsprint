$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
Write-Host 'Checking .NET SDK...' -ForegroundColor Cyan
dotnet --version
Write-Host 'Restoring packages...' -ForegroundColor Cyan
dotnet restore .\PharmacyManagementSystem.sln
if ($LASTEXITCODE -ne 0) { throw 'dotnet restore failed.' }
Write-Host 'Building solution...' -ForegroundColor Cyan
dotnet build .\PharmacyManagementSystem.sln --no-restore
if ($LASTEXITCODE -ne 0) { throw 'dotnet build failed.' }
Write-Host 'Running automated tests...' -ForegroundColor Cyan
dotnet test .\PharmacyManagementSystem.sln --no-build
if ($LASTEXITCODE -ne 0) { throw 'dotnet test failed.' }
Write-Host 'Build and automated tests completed successfully.' -ForegroundColor Green
