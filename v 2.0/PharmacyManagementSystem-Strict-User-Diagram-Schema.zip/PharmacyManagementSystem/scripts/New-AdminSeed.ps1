param(
 [string]$Email = 'admin@pharmacy.local',
 [string]$FullName = 'System Administrator',
 [string]$OutputFile = '.\Create-FirstAdmin.sql'
)
$ErrorActionPreference = 'Stop'
$secure = Read-Host 'Enter a strong initial Admin password (minimum 12 characters)' -AsSecureString
$bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
try { $password = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr) }
finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
if ($password.Length -lt 12) { throw 'Password must be at least 12 characters.' }
$salt = New-Object byte[] 16
[Security.Cryptography.RandomNumberGenerator]::Fill($salt)
$hash = [Security.Cryptography.Rfc2898DeriveBytes]::Pbkdf2($password, $salt, 120000, [Security.Cryptography.HashAlgorithmName]::SHA256, 32)
$stored = [Convert]::ToBase64String($salt) + ':' + [Convert]::ToBase64String($hash)
function Q([string]$s) { return $s.Replace("'", "''") }
$sql = @"
USE UserDB;
IF EXISTS (SELECT 1 FROM dbo.Users WHERE Email = '$(Q $Email)')
    THROW 51000, 'Admin email already exists. Do not overwrite an existing account.', 1;
INSERT dbo.Users (FullName, Email, PasswordHash, Role, IsActive)
VALUES ('$(Q $FullName)', '$(Q $Email)', '$(Q $stored)', 'Admin', 1);
PRINT 'First Admin account created. Delete this generated SQL file after execution.';
"@
Set-Content -LiteralPath $OutputFile -Value $sql -Encoding UTF8
$password = $null; $secure.Dispose()
Write-Host "Created $OutputFile. Open it in SSMS, execute it against your LocalDB instance, then delete the SQL file." -ForegroundColor Green
