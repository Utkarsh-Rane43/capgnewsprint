/* Run in SSMS after Strict-LLD-Schema.sql. Shows all columns and PK/FK/index metadata. */
DECLARE @dbs TABLE(DbName SYSNAME);
INSERT @dbs VALUES ('UserDB'),('InventoryDB'),('OrderDB'),('PaymentDB'),('ReportDB');
DECLARE @sql NVARCHAR(MAX)=N'';
SELECT @sql = @sql + N'SELECT N''' + DbName + N''' AS DatabaseName, TABLE_NAME, COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH, NUMERIC_PRECISION, NUMERIC_SCALE, IS_NULLABLE FROM ' + QUOTENAME(DbName) + N'.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=''dbo'' UNION ALL '
FROM @dbs;
SET @sql = LEFT(@sql,LEN(@sql)-10) + N' ORDER BY DatabaseName,TABLE_NAME,ORDINAL_POSITION;';
EXEC sp_executesql @sql;
GO
SELECT DB_NAME() AS CurrentDatabase, fk.name AS ForeignKeyName,
       OBJECT_NAME(fk.parent_object_id) AS TableName,
       OBJECT_NAME(fk.referenced_object_id) AS ReferencedTable
FROM sys.foreign_keys fk ORDER BY TableName;
GO
