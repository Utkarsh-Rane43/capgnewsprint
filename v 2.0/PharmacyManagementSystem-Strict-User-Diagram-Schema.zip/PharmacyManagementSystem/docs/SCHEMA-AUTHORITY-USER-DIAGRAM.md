# Strict database schema authority

The uploaded user-provided database diagram is the sole authority for persisted columns. EF Core `OnModelCreating` explicitly maps the eight tables and ignores compatibility-only properties where old API/controller code still refers to them. These ignored properties must never become database columns.

## Exact databases, tables and columns

- UserDB.Users: UserId INT PK, FullName VARCHAR(100), Email VARCHAR(150), PasswordHash VARCHAR(255), Role VARCHAR(20), IsActive BOOLEAN/BIT.
- InventoryDB.Suppliers: SupplierId INT PK, SupplierName VARCHAR(100), Email VARCHAR(150), Phone VARCHAR(20), Address VARCHAR(255).
- InventoryDB.Drugs: DrugId INT PK, DrugName VARCHAR(100), Manufacturer VARCHAR(100), Price DECIMAL(10,2), ExpiryDate DATE, SupplierId INT.
- InventoryDB.Inventory: InventoryId INT PK, DrugId INT, AvailableQuantity INT, ReservedQuantity INT.
- OrderDB.Orders: OrderId INT PK, UserId INT, OrderDate DATETIME, TotalAmount DECIMAL(10,2), OrderStatus VARCHAR(20).
- OrderDB.OrderItems: OrderItemId INT PK, OrderId INT, DrugId INT, Quantity INT, UnitPrice DECIMAL(10,2), SubTotal DECIMAL(10,2).
- PaymentDB.Payments: PaymentId INT PK, OrderId INT, Amount DECIMAL(10,2), PaymentStatus VARCHAR(20), TransactionReference VARCHAR(100).
- ReportDB.SalesReports: ReportId INT PK, ReportDate DATE, TotalOrders INT, TotalSales DECIMAL(10,2).

No cross-database foreign keys. Only within-service relationships are configured. PaymentMethod and IdempotencyKey are request-only; idempotency is represented by a deterministic value in TransactionReference. Compatibility properties such as User.Phone, Drug.Description, Drug.IsActive, Supplier.ContactPerson, Inventory.RowVersion, Order.PaymentStatus, Payment.PaymentMethod, Payment.IdempotencyKey, Payment.CreatedAt and SalesReport.GeneratedAt are ignored by EF and are not persisted.

## Important verification note

This source package has been schema-aligned by inspection, but it has NOT been compiled or runtime-tested in this environment because the .NET SDK is unavailable here. Run the included build check on the Windows machine before relying on it. `EnsureCreated()` is used by the services, so it creates tables only when a database is empty; it does not update an existing schema. If an earlier attempt already created incorrect tables, use a disposable/new database or back up and deliberately recreate it after reviewing the consequences.
