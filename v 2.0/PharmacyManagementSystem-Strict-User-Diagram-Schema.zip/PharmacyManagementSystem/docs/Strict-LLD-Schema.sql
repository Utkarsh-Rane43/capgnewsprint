/* Pharmacy Management System - strict physical schema from uploaded database diagram.
   SQL Server / LocalDB. Run once in SSMS. No cross-database foreign keys.
   Notification Service has no database. */
IF DB_ID(N'UserDB') IS NULL CREATE DATABASE UserDB;
IF DB_ID(N'InventoryDB') IS NULL CREATE DATABASE InventoryDB;
IF DB_ID(N'OrderDB') IS NULL CREATE DATABASE OrderDB;
IF DB_ID(N'PaymentDB') IS NULL CREATE DATABASE PaymentDB;
IF DB_ID(N'ReportDB') IS NULL CREATE DATABASE ReportDB;
GO
USE UserDB;
IF OBJECT_ID(N'dbo.Users',N'U') IS NULL
CREATE TABLE dbo.Users(
 UserId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Users PRIMARY KEY,
 FullName VARCHAR(100) NOT NULL,
 Email VARCHAR(150) NOT NULL,
 PasswordHash VARCHAR(255) NOT NULL,
 Role VARCHAR(20) NOT NULL,
 IsActive BIT NOT NULL
);
CREATE UNIQUE INDEX UX_Users_Email ON dbo.Users(Email);
GO
USE InventoryDB;
IF OBJECT_ID(N'dbo.Suppliers',N'U') IS NULL
CREATE TABLE dbo.Suppliers(
 SupplierId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Suppliers PRIMARY KEY,
 SupplierName VARCHAR(100) NOT NULL,
 Email VARCHAR(150) NULL,
 Phone VARCHAR(20) NULL,
 Address VARCHAR(255) NULL
);
IF OBJECT_ID(N'dbo.Drugs',N'U') IS NULL
CREATE TABLE dbo.Drugs(
 DrugId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Drugs PRIMARY KEY,
 DrugName VARCHAR(100) NOT NULL,
 Manufacturer VARCHAR(100) NOT NULL,
 Price DECIMAL(10,2) NOT NULL,
 ExpiryDate DATE NOT NULL,
 SupplierId INT NOT NULL,
 CONSTRAINT FK_Drugs_Suppliers FOREIGN KEY(SupplierId) REFERENCES dbo.Suppliers(SupplierId)
);
IF OBJECT_ID(N'dbo.Inventory',N'U') IS NULL
CREATE TABLE dbo.Inventory(
 InventoryId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Inventory PRIMARY KEY,
 DrugId INT NOT NULL,
 AvailableQuantity INT NOT NULL,
 ReservedQuantity INT NOT NULL,
 CONSTRAINT FK_Inventory_Drugs FOREIGN KEY(DrugId) REFERENCES dbo.Drugs(DrugId),
 CONSTRAINT UQ_Inventory_DrugId UNIQUE(DrugId),
 CONSTRAINT CK_Inventory_Available CHECK(AvailableQuantity>=0),
 CONSTRAINT CK_Inventory_Reserved CHECK(ReservedQuantity>=0)
);
GO
USE OrderDB;
IF OBJECT_ID(N'dbo.Orders',N'U') IS NULL
CREATE TABLE dbo.Orders(
 OrderId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Orders PRIMARY KEY,
 UserId INT NOT NULL,
 OrderDate DATETIME NOT NULL,
 TotalAmount DECIMAL(10,2) NOT NULL,
 OrderStatus VARCHAR(20) NOT NULL
);
IF OBJECT_ID(N'dbo.OrderItems',N'U') IS NULL
CREATE TABLE dbo.OrderItems(
 OrderItemId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_OrderItems PRIMARY KEY,
 OrderId INT NOT NULL,
 DrugId INT NOT NULL,
 Quantity INT NOT NULL,
 UnitPrice DECIMAL(10,2) NOT NULL,
 SubTotal DECIMAL(10,2) NOT NULL,
 CONSTRAINT FK_OrderItems_Orders FOREIGN KEY(OrderId) REFERENCES dbo.Orders(OrderId) ON DELETE CASCADE
);
GO
USE PaymentDB;
IF OBJECT_ID(N'dbo.Payments',N'U') IS NULL
CREATE TABLE dbo.Payments(
 PaymentId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Payments PRIMARY KEY,
 OrderId INT NOT NULL,
 Amount DECIMAL(10,2) NOT NULL,
 PaymentStatus VARCHAR(20) NOT NULL,
 TransactionReference VARCHAR(100) NOT NULL
);
/* Unique reference is the idempotency enforcement mechanism; no extra column. */
CREATE UNIQUE INDEX UX_Payments_TransactionReference ON dbo.Payments(TransactionReference);
GO
USE ReportDB;
IF OBJECT_ID(N'dbo.SalesReports',N'U') IS NULL
CREATE TABLE dbo.SalesReports(
 ReportId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_SalesReports PRIMARY KEY,
 ReportDate DATE NOT NULL,
 TotalOrders INT NOT NULL,
 TotalSales DECIMAL(10,2) NOT NULL
);
CREATE UNIQUE INDEX UX_SalesReports_ReportDate ON dbo.SalesReports(ReportDate);
GO
PRINT 'Strict LLD database schema created/checked. Existing tables are not altered by this script.';
