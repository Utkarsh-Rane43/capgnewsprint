# Swagger test checklist mapped to LLD UT01–UT24

Use `http://localhost:5000/swagger`. Log in, copy the JWT, click **Authorize**, and paste the token. Public registration and login do not require a token.

| ID | Scenario | Expected |
|---|---|---|
| UT01 | Register valid Doctor | 201 Created |
| UT02 | Register duplicate email | 409 Conflict |
| UT03 | Login valid credentials | 200 OK + JWT |
| UT04 | Login incorrect password | 401 Unauthorized |
| UT05 | Add medicine with valid details | 201 Created |
| UT06 | Add medicine with negative price | 400 Bad Request |
| UT07 | Check available stock | 200 OK |
| UT08 | Place order with available stock | 201 Created; stock reserved |
| UT09 | Reserve insufficient stock | 409 Conflict |
| UT10 | Release reserved stock | internal Order Service workflow; verify rejection restores stock |
| UT11 | Place valid order | 201 Created |
| UT12 | Place empty order | 400 Bad Request |
| UT13 | Verify pending order | 200 OK |
| UT14 | Reject pending order | 200 OK; reserved stock released |
| UT15 | Verify rejected order | 409 Conflict |
| UT16 | Process successful simulated payment | 200 OK; PaymentStatus=Success |
| UT17 | Simulate failed payment (`simulateFailure=true`) | 200 OK; PaymentStatus=Failed |
| UT18 | Repeat same idempotency key | same payment returned; no duplicate row |
| UT19 | Retrieve invoice for paid order | 200 OK |
| UT20 | Generate daily report with `POST /api/reports/generate/daily`, then view it | 200 OK |
| UT21 | Protected API without token | 401 Unauthorized |
| UT22 | Doctor accesses Admin API | 403 Forbidden |
| UT23 | Send email with valid SMTP | 200 OK |
| UT24 | SMTP unavailable or invalid | 503 Service Unavailable |

## Suggested execution sequence

1. UT01–UT04. Register two users: one Doctor and one local Admin. Promote the Admin user using the documented SQL statement and log in again.
2. As Admin, add a supplier, add medicine with initial quantity, then inspect InventoryDB.
3. As Doctor, place an order. Verify that AvailableQuantity decreases and ReservedQuantity increases.
4. As Admin, verify the order. As Doctor, process simulated payment. Try both success and failure with different order IDs or idempotency keys.
5. As Admin, reject another pending order and confirm reserved stock is released.
6. Retrieve invoice as the order owner and test access as a different Doctor.
7. Configure SMTP only if testing email delivery.

Note: stock reserve/release/finalize endpoints accept either an Admin JWT for manual Swagger testing or the development service key for internal Order Service calls.
