# Local run instructions

1. Install .NET 10 SDK and SQL Server LocalDB.
2. Connect SSMS to `(localdb)\\MSSQLLocalDB` and execute `Create-Databases.sql`.
3. The five `appsettings.json` files already target LocalDB. Change them only if using another SQL Server instance.
4. Run `Build-Check.ps1` or `dotnet restore`, `dotnet build`, `dotnet test` from the solution directory.
5. Run `Run-Local.bat`.
6. Open `http://localhost:5000/swagger` and use the Swagger Authorize button with the JWT returned by login.

Service ports 5001–5006 are internal local process ports. All external requests use gateway port 5000.

Database tables are created by EF Core on each service's first startup when its database is empty. Initialization exceptions are no longer silently swallowed: a service fails at startup and prints the actual database error.
