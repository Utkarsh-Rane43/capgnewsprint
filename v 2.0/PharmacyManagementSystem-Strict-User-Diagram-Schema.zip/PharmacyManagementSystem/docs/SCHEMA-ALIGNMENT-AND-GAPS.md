# Strict LLD schema contract and implementation notes

## Authority
The uploaded database diagram is the physical schema authority. It contains five SQL Server databases and eight tables. Notification Service has no database.

## Exact tables and columns

- `UserDB.dbo.Users`: `UserId INT PK`, `FullName VARCHAR(100)`, `Email VARCHAR(150)`, `PasswordHash VARCHAR(255)`, `Role VARCHAR(20)`, `IsActive BIT`. No Phone column.
- `InventoryDB.dbo.Suppliers`: `SupplierId INT PK`, `SupplierName VARCHAR(100)`, `Email VARCHAR(150)`, `Phone VARCHAR(20)`, `Address VARCHAR(255)`.
- `InventoryDB.dbo.Drugs`: `DrugId INT PK`, `DrugName VARCHAR(100)`, `Manufacturer VARCHAR(100)`, `Price DECIMAL(10,2)`, `ExpiryDate DATE`, `SupplierId INT`.
- `InventoryDB.dbo.Inventory`: `InventoryId INT PK`, `DrugId INT`, `AvailableQuantity INT`, `ReservedQuantity INT`.
- `OrderDB.dbo.Orders`: `OrderId INT PK`, `UserId INT`, `OrderDate DATETIME`, `TotalAmount DECIMAL(10,2)`, `OrderStatus VARCHAR(20)`.
- `OrderDB.dbo.OrderItems`: `OrderItemId INT PK`, `OrderId INT`, `DrugId INT`, `Quantity INT`, `UnitPrice DECIMAL(10,2)`, `SubTotal DECIMAL(10,2)`.
- `PaymentDB.dbo.Payments`: `PaymentId INT PK`, `OrderId INT`, `Amount DECIMAL(10,2)`, `PaymentStatus VARCHAR(20)`, `TransactionReference VARCHAR(100)`.
- `ReportDB.dbo.SalesReports`: `ReportId INT PK`, `ReportDate DATE`, `TotalOrders INT`, `TotalSales DECIMAL(10,2)`.

Cross-service references (`Orders.UserId`, `OrderItems.DrugId`, `Payments.OrderId`) are logical references resolved through service APIs; do not create cross-database foreign keys.

## Payment method without a column
`paymentMethod` remains part of the POST request DTO only. The service validates the supported method and passes it to the simulated processor. It is intentionally not persisted because the strict diagram has no column for it. Consequently, historical payment method cannot be queried later.

## Idempotency without a column
The client sends `idempotencyKey` in the payment request. The Payment Service derives a deterministic opaque transaction reference from the key (for example, `IDEM-` plus a SHA-256 digest) and stores that value in the existing `TransactionReference` column. A unique index on that column enforces one payment record per key. On a repeated key, return the existing payment result. If the same key is reused for another order, return HTTP 409. A genuinely new retry uses a new key. Do not store the raw key or add a separate key column.

This scheme is appropriate for the simulated POC. It is not a substitute for gateway-side idempotency and settlement reconciliation in a real payment integration.

## Important LLD discrepancies
The LLD contains differences between sections 12/18 and the physical database diagram in section 9/14. Examples include User.Phone, Drug.Description, Supplier.ContactPerson, Order.PaymentStatus, Payment.PaymentMethod, and SalesReport.GeneratedAt. Under the selected strict-schema decision, these are not physical columns. Functional behavior that needs transient values must use DTOs/service logic or retrieve related data from its owning service.

## Current archive status — read before running
This archive is based on the previous source ZIP and includes the strict schema script and this reconciliation note. The previous source code still contains EF model properties and `EnsureCreated()` startup calls that do not fully match this strict schema. Therefore, **do not run this archive against an existing project database and do not treat it as the final verified implementation**. The source requires a coordinated model/controller refactor and a .NET 10 build/test pass before it can be called final. The SQL script is a reference schema for a fresh database only; it does not alter pre-existing tables.
