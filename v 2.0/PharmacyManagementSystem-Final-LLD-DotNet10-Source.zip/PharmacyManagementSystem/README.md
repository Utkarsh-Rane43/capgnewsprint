# Pharmacy Management System — .NET 10 Local POC

This solution implements the supplied Pharmacy Management System LLD using six ASP.NET Core Web API microservices and one YARP gateway. It is intended for local development on Windows; no Docker, cloud hosting, or deployment is required.

## Architecture and ports

| Component | Local port | Database |
|---|---:|---|
| YARP API Gateway | 5000 | — |
| Auth Service | 5001 | UserDB |
| Inventory Service | 5002 | InventoryDB |
| Order Service | 5003 | OrderDB |
| Payment Service | 5004 | PaymentDB |
| Sales Report Service | 5005 | ReportDB |
| Notification Service | 5006 | SMTP; no database |

Use **only** `http://localhost:5000/swagger` for client API calls. Ports 5001–5006 are internal local service listeners. The gateway proxies six OpenAPI documents and each JWT-protected service defines a Bearer security scheme for Swagger's Authorize control.

## Requirements

- Windows 10/11
- .NET 10 SDK
- SQL Server LocalDB (or change the five connection strings to your SQL Server instance)
- SSMS recommended

## Fresh setup

1. Install the .NET 10 SDK and SQL Server LocalDB.
2. Open SSMS and connect to `(localdb)\\MSSQLLocalDB`.
3. Run `docs/Create-Databases.sql` to create the five database containers.
4. The default `appsettings.json` connection strings already target `(localdb)\\MSSQLLocalDB`. If you use another SQL Server instance, change the `ConnectionStrings:Default` value in the five database-backed services.
5. Run `Build-Check.ps1` from PowerShell, or run `dotnet restore`, `dotnet build`, and `dotnet test` from this folder.
6. Run `Run-Local.bat`.
7. Open `http://localhost:5000/swagger`.

Each database-backed service uses EF Core `EnsureCreated()` on startup. It creates tables in a newly created or existing empty database. If a database already contains a partial/incompatible schema, back it up and recreate only that service's database before startup; do not delete UserDB if you need its registered users.

## Databases and tables (LLD)

- UserDB: Users
- InventoryDB: Drugs, Suppliers, Inventory
- OrderDB: Orders, OrderItems
- PaymentDB: Payments
- ReportDB: SalesReports
- Notification Service: SMTP configuration only; no database

Cross-service references (UserId, DrugId, OrderId) are logical identifiers and are not cross-database SQL foreign keys. OrderDB has a local one-to-many relationship from Orders to OrderItems. InventoryDB uses InventoryId as the Stock/Inventory primary key and enforces one stock row per DrugId.

## Roles and first Admin account

Public registration always creates a Doctor, as required by the LLD. For a local POC, register a user, then provision the first Admin using SSMS:

```sql
UPDATE UserDB.dbo.Users SET Role = 'Admin' WHERE Email = 'admin@example.com';
```

Log in again after changing the role so the new JWT contains the Admin role. Keep a separate Doctor account for Doctor workflow testing. Do not expose Admin registration publicly.

## Main workflow

1. Doctor registers and logs in; use the JWT in Swagger's **Authorize** dialog.
2. Admin creates suppliers, medicines, and stock.
3. Doctor browses medicines and submits an order. Inventory reserves stock; order status becomes `PendingVerification`.
4. Admin verifies or rejects. Rejection releases reserved stock.
5. Doctor pays for a verified order. Payment is simulated locally; `SimulateFailure=true` exercises a failed attempt. No bank, UPI, Razorpay, Stripe, or other external payment provider is contacted.
6. Successful simulated payment updates the order to `Paid`; invoice data is available to the order owner or Admin.
7. Admin finalizes pickup; reserved stock is deducted from physical stock.
8. Admin views saved sales summaries in ReportDB. Generate a daily summary from paid/picked-up orders using `POST /api/reports/generate/daily?date=2026-11-21`; the generated summary is stored in ReportDB. The `POST /api/reports` endpoint is also available for controlled manual summary entry.

## Internal service calls

Order-to-Inventory stock reservation/release/finalize and Payment-to-Order payment status updates use a local shared development key configured as `Internal:ServiceKey`. Admins can also call the stock reservation/release/finalize endpoints through Swagger for LLD test scenarios. Change the key before sharing a deployed environment.

## SMTP

Email is optional for local API testing. Configure `Smtp:Host`, `Smtp:Port`, `Smtp:EnableSsl`, `Smtp:From`, `Smtp:Username`, and `Smtp:Password` in NotificationService configuration or environment variables. No real SMTP credentials are included. A missing SMTP configuration returns 503 and is logged; email is not required for registration, orders, or payment.

## Testing

- `Build-Check.ps1` restores, builds, and runs the automated NUnit tests.
- `docs/TESTING.md` maps manual Swagger scenarios to LLD UT01–UT24.
- The included NUnit tests cover password hashing. The remaining LLD scenarios are manual API test cases and must be executed through Swagger.

## Important scope notes

This is a local proof-of-concept, not production financial or pharmacy software. The payment flow is simulated only. Multi-service stock operations are compensated on common failure paths but are not a distributed transaction; reconciliation is needed after process/network failures. Development JWT/internal keys are placeholders and must be replaced for any shared or deployed environment.
