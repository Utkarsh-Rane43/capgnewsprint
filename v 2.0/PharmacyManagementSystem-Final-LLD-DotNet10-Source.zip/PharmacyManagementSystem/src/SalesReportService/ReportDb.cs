using Microsoft.EntityFrameworkCore;
namespace Pharmacy.Reports;
public class ReportDb(DbContextOptions<ReportDb> options) : DbContext(options)
{
    public DbSet<SalesReport> SalesReports => Set<SalesReport>();
    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<SalesReport>().HasKey(x => x.ReportId);
        b.Entity<SalesReport>().Property(x => x.TotalSales).HasPrecision(12, 2);
        b.Entity<SalesReport>().HasIndex(x => x.ReportDate).IsUnique();
    }
}
public class SalesReport
{
    public int ReportId { get; set; }
    public DateTime ReportDate { get; set; }
    public int TotalOrders { get; set; }
    public decimal TotalSales { get; set; }
    public DateTime GeneratedAt { get; set; } = DateTime.UtcNow;
}
