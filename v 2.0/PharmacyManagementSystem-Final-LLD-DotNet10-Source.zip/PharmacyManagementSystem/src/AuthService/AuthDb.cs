using Microsoft.EntityFrameworkCore;
namespace Pharmacy.Auth;
public class AuthDb(DbContextOptions<AuthDb> options) : DbContext(options)
{
    public DbSet<User> Users => Set<User>();
    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<User>().HasKey(x => x.UserId);
        b.Entity<User>().Property(x => x.FullName).HasMaxLength(150).IsRequired();
        b.Entity<User>().Property(x => x.Email).HasMaxLength(150).IsRequired();
        b.Entity<User>().Property(x => x.Role).HasMaxLength(20).IsRequired();
        b.Entity<User>().HasIndex(x => x.Email).IsUnique();
    }
}
public class User
{
    public int UserId { get; set; }
    public string FullName { get; set; } = "";
    public string Email { get; set; } = "";
    public string PasswordHash { get; set; } = "";
    public string Role { get; set; } = "Doctor";
    public string Phone { get; set; } = "";
    public bool IsActive { get; set; } = true;
}
