using Microsoft.EntityFrameworkCore;
namespace Pharmacy.Payments;
public class PaymentDb(DbContextOptions<PaymentDb> options) : DbContext(options)
{
    public DbSet<Payment> Payments => Set<Payment>();
    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<Payment>().HasKey(x => x.PaymentId);
        b.Entity<Payment>().Property(x => x.Amount).HasPrecision(10, 2);
        b.Entity<Payment>().Property(x => x.IdempotencyKey).HasMaxLength(150).IsRequired();
        b.Entity<Payment>().HasIndex(x => x.IdempotencyKey).IsUnique();
    }
}
public class Payment
{
    public int PaymentId { get; set; }
    public int OrderId { get; set; }
    public decimal Amount { get; set; }
    public string PaymentMethod { get; set; } = "";
    public string PaymentStatus { get; set; } = "Pending";
    public string TransactionReference { get; set; } = "";
    public string IdempotencyKey { get; set; } = "";
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
