using Microsoft.EntityFrameworkCore;
namespace Pharmacy.Inventory;
public class InventoryDb(DbContextOptions<InventoryDb> options) : DbContext(options)
{
    public DbSet<Drug> Drugs => Set<Drug>();
    public DbSet<Supplier> Suppliers => Set<Supplier>();
    public DbSet<Stock> Inventory => Set<Stock>();
    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<Drug>().HasKey(x => x.DrugId);
        b.Entity<Supplier>().HasKey(x => x.SupplierId);
        b.Entity<Stock>().HasKey(x => x.InventoryId);
        b.Entity<Drug>().Property(x => x.DrugName).HasMaxLength(150).IsRequired();
        b.Entity<Drug>().Property(x => x.Price).HasPrecision(10, 2);
        b.Entity<Supplier>().Property(x => x.SupplierName).HasMaxLength(150).IsRequired();
        b.Entity<Stock>().HasIndex(x => x.DrugId).IsUnique();
        b.Entity<Stock>().Property(x => x.RowVersion).IsRowVersion();
    }
}
public class Drug
{
    public int DrugId { get; set; }
    public string DrugName { get; set; } = "";
    public string Description { get; set; } = "";
    public string Manufacturer { get; set; } = "";
    public decimal Price { get; set; }
    public DateTime ExpiryDate { get; set; }
    public int SupplierId { get; set; }
    public bool IsActive { get; set; } = true;
}
public class Supplier
{
    public int SupplierId { get; set; }
    public string SupplierName { get; set; } = "";
    public string ContactPerson { get; set; } = "";
    public string Email { get; set; } = "";
    public string Phone { get; set; } = "";
    public string Address { get; set; } = "";
}
public class Stock
{
    public int InventoryId { get; set; }
    public int DrugId { get; set; }
    public int AvailableQuantity { get; set; }
    public int ReservedQuantity { get; set; }
    public byte[] RowVersion { get; set; } = [];
}
