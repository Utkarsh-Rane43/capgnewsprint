$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$projects = @(
    @{ Name = "AuthService"; Path = "src/AuthService"; Port = 5001 },
    @{ Name = "InventoryService"; Path = "src/InventoryService"; Port = 5002 },
    @{ Name = "OrderService"; Path = "src/OrderService"; Port = 5003 },
    @{ Name = "PaymentService"; Path = "src/PaymentService"; Port = 5004 },
    @{ Name = "SalesReportService"; Path = "src/SalesReportService"; Port = 5005 },
    @{ Name = "ApiGateway"; Path = "src/ApiGateway"; Port = 5000 }
)
foreach ($project in $projects) {
    $projectPath = Join-Path $root $project.Path
    $command = "Set-Location '$projectPath'; dotnet run"
    Start-Process powershell -ArgumentList @("-NoExit", "-ExecutionPolicy", "Bypass", "-Command", $command)
    Start-Sleep -Milliseconds 700
}
Write-Host "Started all six backend applications." -ForegroundColor Green
Write-Host "Swagger pages: http://localhost:5001/swagger through http://localhost:5005/swagger" -ForegroundColor Cyan
Write-Host "API Gateway: http://localhost:5000" -ForegroundColor Cyan
Write-Host "RabbitMQ is disabled by default. Enable it in both service appsettings after installation." -ForegroundColor Yellow
