$ErrorActionPreference = "Continue"
Write-Host "Checking backend prerequisites..." -ForegroundColor Cyan

$dotnet = Get-Command dotnet -ErrorAction SilentlyContinue
if ($dotnet) {
    Write-Host "[FOUND] .NET SDK: $($dotnet.Source)" -ForegroundColor Green
    dotnet --list-sdks
} else {
    Write-Host "[MISSING] .NET 10 SDK. Install .NET SDK 10.0.404 or update global.json to your installed 10.0.x SDK." -ForegroundColor Red
}

Write-Host "`nSQL Server LocalDB:" -ForegroundColor Cyan
$sqllocaldb = Get-Command sqllocaldb -ErrorAction SilentlyContinue
if ($sqllocaldb) { sqllocaldb info } else { Write-Host "Check that SQL Server LocalDB is installed. The command may not be on PATH." -ForegroundColor Yellow }

Write-Host "`nRabbitMQ is optional and disabled by default." -ForegroundColor Cyan
Write-Host "NuGet restore requires internet access on first run." -ForegroundColor Cyan
