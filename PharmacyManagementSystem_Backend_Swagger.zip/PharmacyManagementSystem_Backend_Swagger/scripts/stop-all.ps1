\
Write-Host "Close the individual PowerShell windows started by start-all.ps1." -ForegroundColor Yellow
Write-Host "This script intentionally does not kill every dotnet process, because that could stop unrelated applications." -ForegroundColor Yellow
