IF DB_ID(N'PharmacyAuthDB') IS NULL CREATE DATABASE PharmacyAuthDB;
GO
IF DB_ID(N'PharmacyInventoryDB') IS NULL CREATE DATABASE PharmacyInventoryDB;
GO
IF DB_ID(N'PharmacyOrderDB') IS NULL CREATE DATABASE PharmacyOrderDB;
GO
IF DB_ID(N'PharmacyPaymentDB') IS NULL CREATE DATABASE PharmacyPaymentDB;
GO
IF DB_ID(N'PharmacySalesReportDB') IS NULL CREATE DATABASE PharmacySalesReportDB;
GO
