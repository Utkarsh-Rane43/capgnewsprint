# Project status — backend Swagger package

## What is included and implemented in this starter

- Five independently hosted .NET 10 microservices and one YARP gateway.
- SQL Server LocalDB connection strings and one database per service.
- EF Core DbContexts and startup table creation with `EnsureCreatedAsync`.
- Auth registration/login with password hashing, JWT issuance, and local Admin seeding.
- Inventory drug listing/detail/create/update, supplier listing/create, and stock reduction.
- Order creation with inventory lookup and GST calculation, order listing/detail, and status update.
- Payment simulation, invoice record creation, and PDF invoice download.
- Daily, weekly and monthly sales report endpoints.
- Swagger UI on all five microservices.
- Optional RabbitMQ publisher/consumer, disabled by default for local startup.

## Not yet complete / must not be represented as production-ready

- Full role-based authorization on every service and endpoint.
- Doctor ownership checks for order history and invoice access.
- Enforced Admin/Doctor workflow permissions and strict order state transitions.
- Atomic stock reservation, payment commit, cancellation and compensation.
- Complete supplier edit/delete operations and richer inventory audit trail.
- Reliable payment-to-report event delivery (outbox, retries, idempotency and dead-letter handling).
- Sales report population when RabbitMQ is disabled.
- Comprehensive validation, integration tests, concurrency tests and deployment hardening.
- Gateway-level Swagger aggregation. Each service has its own Swagger UI.

## Environment note

The package targets .NET 10 and SQL Server LocalDB for Windows development. First-time NuGet restore requires internet. This build environment did not have the .NET SDK installed, so the modified package could not be compiled here. The user should run `dotnet restore` and `dotnet build` after extraction.
