# Pharmacy Management System — Final Business Workflow

## Roles

### Admin (Pharmacist)
- Add, view, edit and delete suppliers.
- Add, view, edit and deactivate/delete medicines.
- View all orders and verify or reject orders.
- Prepare verified and paid orders.
- Move prepared orders to Ready for Pickup.
- View all payment details and invoices.
- View, download and print daily, weekly and monthly sales reports.

### Doctor
- Register and log in.
- Browse active medicines and available stock.
- Place orders.
- Pay for verified orders using the internal payment simulator.
- View own orders and their status.
- View/download invoices belonging to own successful payments.
- Confirm collection after the Pharmacist marks an order Ready for Pickup.
- Cancel an order before preparation starts, subject to the cancellation rule below.

## Order status lifecycle

1. `PendingVerification` — Doctor has placed the order.
2. `Verified` — Admin checked the order and stock; it is awaiting payment.
3. `Rejected` — Admin rejected the order; a reason should be recorded.
4. `PaymentFailed` — simulated payment failed; no paid invoice or sale is created.
5. `Paid` — payment succeeded and invoice was generated.
6. `Preparing` — Pharmacist is preparing the medicines.
7. `ReadyForPickup` — Pharmacist has packed the medicines and marked them ready.
8. `PickedUp` — Doctor confirmed actual collection; record the confirmation time.
9. `Cancelled` — order cancelled before preparation, or cancelled by Admin with a recorded reason.

## Pickup design decision

The Pharmacist does **not** mark an order as Picked Up. The Pharmacist moves a paid order through Preparing to ReadyForPickup. The Doctor sees a pickup notification and confirms collection with a Confirm Pickup action. This provides an auditable record of actual collection.

If a Doctor does not collect the order, it remains ReadyForPickup. Admin may contact the Doctor or cancel it according to the pharmacy's policy.

## Payment and invoice

- Payment is a training simulator only; it does not connect to a bank, UPI or card processor.
- No card number, CVV, UPI PIN, OTP or banking password is requested or stored.
- A successful payment creates a payment record and invoice.
- Both Admin and the owning Doctor can view/download the invoice.
- A Doctor must never be able to access another Doctor's invoice.
- Failed payments do not create a paid invoice and must not be counted as sales.

## Stock handling recommendation

Stock should be reserved when an order is verified, committed/deducted after successful payment, and released if payment fails or the order is cancelled. For multiple medicines, partial reservation must be compensated if any item cannot be reserved.

## Important implementation note

This document is the agreed business specification. The included source is a beginner-oriented development kit. Before a real deployment, complete and verify the authorization, ownership checks, stock reservation/compensation, order-to-payment orchestration, and Doctor invoice access described above. See `PROJECT_STATUS.md`.
