# Final Acceptance Checklist

Use this only after implementation is complete.

## Environment
- [ ] .NET restore/build succeeds on the target laptop.
- [ ] SQL Server LocalDB databases and tables are created.
- [ ] RabbitMQ starts and the event consumer reconnects safely.
- [ ] Swagger UI opens for all five microservices.
- [ ] All services start on the documented ports.

## Roles and access control
- [ ] Public registration always creates a Doctor.
- [ ] Admin is provisioned securely; there is no public Admin registration.
- [ ] Every downstream service validates JWT signatures, issuer, audience and expiry.
- [ ] Admin-only operations reject Doctor tokens.
- [ ] Doctor order and invoice queries are filtered to the authenticated Doctor ID.

## Inventory and orders
- [ ] Supplier create/view/edit/delete.
- [ ] Drug create/view/edit/deactivate.
- [ ] Insufficient stock is rejected.
- [ ] Multi-item stock reservation compensates on partial failure.
- [ ] Doctor can cancel only when allowed by the workflow.
- [ ] Admin can verify/reject orders with reason.
- [ ] Paid order can be prepared and marked ReadyForPickup.
- [ ] Doctor confirmation records PickedUp and timestamp.

## Payment, invoice and reports
- [ ] Payment success creates exactly one payment and invoice.
- [ ] Payment failure creates no paid invoice and no sale record.
- [ ] Doctor can download own invoice but not another Doctor's invoice.
- [ ] Admin can view all invoices and payment details.
- [ ] RabbitMQ event processing is idempotent.
- [ ] Daily, weekly and monthly reports match successful payments.
- [ ] Reports can be downloaded/printed.

## Security and operations
- [ ] Replace sample JWT and RabbitMQ credentials.
- [ ] Enable HTTPS and configure CORS for the real frontend origin.
- [ ] Do not collect/store payment credentials.
- [ ] Back up databases and configure logging.
- [ ] Use SQL Server Express/full SQL Server for multi-user deployment.
