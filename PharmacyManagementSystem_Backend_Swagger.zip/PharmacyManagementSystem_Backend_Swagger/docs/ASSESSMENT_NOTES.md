# Assessment explanation

## Why microservices?
The application is divided into services so that authentication, inventory, orders, payments and reporting have separate responsibilities and separate databases.

## Why an API Gateway?
The Frontend (out of current scope) calls one entry point, port 5000. YARP forwards the request to the correct service.

## Why Entity Framework Core and LINQ?
Entity Framework Core maps C# entity classes to database tables. LINQ is used to query and update data. We do not write SQL SELECT/INSERT/UPDATE statements in application code.

## Why RabbitMQ?
PaymentService publishes a `payment.succeeded` event. SalesReportService listens for that event and records the sale in its own database. This is asynchronous communication.

## Business flow at this starter stage
1. Doctor registers/logs in.
2. Inventory team adds medicines and suppliers.
3. Doctor creates an order. OrderService asks InventoryService for current drug details and calculates the amount.
4. PaymentService simulates a successful or failed payment.
5. On success it creates a basic PDF invoice and publishes a RabbitMQ event.
6. SalesReportService consumes the success event and stores the sale.
7. Daily, weekly and monthly reports query the reporting database using LINQ.

## Known limitations to explain honestly
- This starter checks stock before creating an order, but does not yet implement a transaction-safe reservation/commit/release workflow.
- OrderService and PaymentService are not yet joined by a complete saga workflow; call payment separately after creating an order.
- JWT is issued and used by AuthService's protected users endpoint, but downstream services and gateway still need JWT validation and role policies.
- RabbitMQ event publishing currently happens after saving the payment; an outbox/retry/dead-letter strategy is needed for reliable production delivery.
- The report consumer uses an order ID check to reduce duplicate sales, but a database unique constraint and robust poison-message handling should be added.
- The PDF is a basic assessment invoice. Verify GST rates, tax-inclusive/exclusive calculations, HSN, seller/buyer details and statutory invoice requirements before any real use.
- Add automated tests, validation, logging, monitoring, secrets management, HTTPS and Angular UI before calling the system production-ready.
