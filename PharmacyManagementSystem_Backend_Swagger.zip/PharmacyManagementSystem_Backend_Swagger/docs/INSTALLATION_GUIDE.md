# Installation guide (Windows)

1. Install .NET 10 SDK. The included `global.json` pins 10.0.404.
2. Install SQL Server LocalDB. SSMS is recommended for viewing the databases but is not required by the application.
3. Extract the ZIP to a short path, e.g. `C:\Projects\PharmacyManagementSystem_Backend_Swagger`.
4. Open PowerShell in the extracted root.
5. Run `dotnet --version`; it should report 10.0.404.
6. Run `dotnet restore PharmacyManagementSystem.sln`.
7. Run `dotnet build PharmacyManagementSystem.sln`.
8. Optional: execute `database\create-databases.sql` in SSMS. The services can create databases/tables on first startup if the LocalDB instance is available and the account has permissions.
9. Run `powershell -ExecutionPolicy Bypass -File .\scripts\start-all.ps1`.
10. Open the Swagger UI URLs in `docs\SWAGGER_TESTING_GUIDE.md`.

If your installed SDK is a different .NET 10 patch version, update `global.json` to the installed version or install 10.0.404. If using SQL Server Express/full SQL Server instead of LocalDB, update `DefaultConnection` in all five service `appsettings.json` files.

RabbitMQ is optional and disabled by default. See the Swagger guide before enabling it.
