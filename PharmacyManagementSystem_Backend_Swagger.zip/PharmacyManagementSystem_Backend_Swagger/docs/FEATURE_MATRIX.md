# Feature Matrix

| Feature | Admin | Doctor | Source-kit status |
|---|---|---|---|
| Login | Yes | Yes | Auth API starter included |
| Public registration | No | Yes | Public endpoint assigns Doctor role |
| Manage suppliers | Yes | No | Basic list/add API included; edit/delete should be completed |
| Manage drugs | Yes | View | Basic list/add/edit API included; delete/deactivate UI should be completed |
| Place orders | View all | Yes | Basic order creation API included |
| Verify/reject orders | Yes | View status | Status endpoint starter included; enforce state transitions/roles |
| Pay for verified order | View all | Yes | Payment simulator included; full order orchestration needs completion |
| Invoice access | All invoices | Own invoices | PDF generation included; secure ownership-filtered invoice list/download must be completed |
| Pickup preparation | Yes | View | Ready-for-pickup and pickup confirmation workflow is specified; complete in OrderService |
| Confirm pickup | No | Yes | Required endpoint/UI to be completed |
| View payment details | All | Own payment result | Payment list starter included; secure role filtering must be completed |
| Sales reports | Yes | No | Daily/weekly/monthly report endpoints and RabbitMQ consumer starter included |

This matrix intentionally distinguishes existing starter code from business requirements that still need implementation. Do not present unimplemented rows as completed functionality.
