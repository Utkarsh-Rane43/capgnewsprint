# Swagger API testing guide

## Swagger UI addresses

Start the backend with `scripts\start-all.ps1`, then open:

| Service | Swagger UI |
|---|---|
| Authentication | http://localhost:5001/swagger |
| Inventory | http://localhost:5002/swagger |
| Orders | http://localhost:5003/swagger |
| Payments and invoices | http://localhost:5004/swagger |
| Sales reports | http://localhost:5005/swagger |

The YARP API Gateway listens on http://localhost:5000. Swagger pages are hosted by the individual services so each service exposes its own OpenAPI document.

## Suggested smoke-test sequence

1. Open Auth Swagger and call `POST /api/auth/login` with the seeded Admin account.
2. Register a Doctor using `POST /api/auth/register`.
3. Log in as the Doctor.
4. Open Inventory Swagger and add a supplier and one or more drugs.
5. Open Orders Swagger and create an order using existing drug IDs.
6. Update order status as the workflow progresses.
7. Open Payments Swagger and simulate payment for the order ID. A successful simulation creates a payment and invoice.
8. Open Sales Reports Swagger to query daily, weekly and monthly reports.

## Seeded Admin account (local training only)

- Email: `admin@pharmacy.local`
- Password: `Admin@12345`

The credentials are configured in `src/AuthService/appsettings.json`. Change them before any shared or deployed use.

## Swagger authorization

The AuthService Swagger page includes a Bearer Authorize control. After logging in, copy the `token` value from the response and paste it into the Authorize dialog. This is required for the protected `/api/auth/users` endpoint.

## Important current scope/limitations

- Swagger UI is provided separately for each microservice; the gateway does not aggregate the five OpenAPI documents.
- RabbitMQ is disabled by default so the backend can run without installing it. Payment simulation and invoice creation work in this mode, but payment events will not be copied into the SalesReport database. After RabbitMQ is approved and installed, set `RabbitMQ:Enabled` to `true` in both PaymentService and SalesReportService appsettings and restart those services.
- This is an assessment/development starter, not a production-ready pharmacy system. It still needs completion and end-to-end verification of role authorization across all services, Doctor-specific order/invoice ownership, stock reservation and rollback, strict order-state transitions, durable messaging/outbox/retry, and full report population when RabbitMQ is disabled.
- The sample payment endpoint is a simulator only. Never enter or store real card, CVV, UPI PIN, OTP or banking credentials.
