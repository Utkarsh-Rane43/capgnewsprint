$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
Write-Host "Restoring NuGet packages..." -ForegroundColor Cyan
dotnet restore .\PharmacyManagementSystem.sln
if ($LASTEXITCODE -ne 0) { throw "dotnet restore failed. Review the error above." }
Write-Host "Building the complete backend solution..." -ForegroundColor Cyan
dotnet build .\PharmacyManagementSystem.sln --no-restore
if ($LASTEXITCODE -ne 0) { throw "dotnet build failed. Review the error above." }
Write-Host "Restore and build completed successfully." -ForegroundColor Green
Write-Host "Start the services with: .\start-all.ps1" -ForegroundColor Cyan
