& (Join-Path $PSScriptRoot 'scripts\start-all.ps1')
