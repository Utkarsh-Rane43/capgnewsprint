# Pharmacy Management System — Backend + Swagger Kit

Backend-only .NET 10 microservices starter for the pharmacy management case study. The Angular frontend has intentionally been removed because the current team scope is backend development and API testing through Swagger.

## Included

- ASP.NET Core .NET 10 microservices: Auth, Inventory, Orders, Payments, Sales Reports
- YARP API Gateway
- Entity Framework Core + SQL Server LocalDB configuration
- LINQ-based data access
- Separate database per service
- Swagger UI for all five microservices
- Seeded local Admin account and Doctor registration/login
- Simulated payment and PDF invoice generation
- Optional RabbitMQ integration (disabled by default)
- PowerShell scripts to start and stop the backend
- Setup and Swagger testing documentation

## Requirements (Windows)

1. .NET 10 SDK (the project pins SDK 10.0.404 in `global.json`; install that SDK or update `global.json` to an installed 10.0.x SDK).
2. SQL Server LocalDB (included with Visual Studio workloads or SQL Server Express LocalDB) or update each service connection string to your SQL Server instance.
3. Internet access for the first NuGet restore.
4. RabbitMQ is optional; it is not needed to start the backend or run the payment simulator in the default configuration.

## First-time setup

1. Extract this ZIP.
2. Open PowerShell in the extracted `PharmacyManagementSystem_Backend_Swagger` folder.
3. Check SDK: `dotnet --version`
4. Restore packages: `dotnet restore PharmacyManagementSystem.sln`
5. Build: `dotnet build PharmacyManagementSystem.sln`
6. (Optional) Run `database\create-databases.sql` in SSMS. Each service also creates its own database/tables on first startup using EF Core `EnsureCreated`.
7. Start all backend services: `powershell -ExecutionPolicy Bypass -File .\scripts\start-all.ps1`
8. Open the Swagger pages listed below.

## Swagger URLs

- Auth: http://localhost:5001/swagger
- Inventory: http://localhost:5002/swagger
- Orders: http://localhost:5003/swagger
- Payments: http://localhost:5004/swagger
- Sales reports: http://localhost:5005/swagger
- API Gateway: http://localhost:5000

Read `docs/SWAGGER_TESTING_GUIDE.md` for a suggested request sequence and known limitations.

## Local Admin credentials

`admin@pharmacy.local` / `Admin@12345`

Change these values in `src/AuthService/appsettings.json` before sharing the project or deploying it.

## Important

This ZIP is ready for extraction, NuGet restore, build and local startup on a machine with the prerequisites above. It is not a fully completed or production-hardened system. Several cross-service business rules and authorization checks still need implementation. See `PROJECT_STATUS.md` and `docs/SWAGGER_TESTING_GUIDE.md`.
