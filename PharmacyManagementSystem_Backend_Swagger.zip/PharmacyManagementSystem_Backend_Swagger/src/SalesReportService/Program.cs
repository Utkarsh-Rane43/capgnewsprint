using Microsoft.EntityFrameworkCore;
using SalesReportService.Data;
using SalesReportService.Workers;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<ReportDbContext>(options =>
{
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection"));
});

builder.Services.AddHostedService<PaymentEventWorker>();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI(options =>
{
    options.SwaggerEndpoint("/swagger/v1/swagger.json", "SalesReportService v1");
    options.RoutePrefix = "swagger";
});

using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<ReportDbContext>();
    await db.Database.EnsureCreatedAsync();
}

app.MapGet("/", () => "SalesReportService is running.");

app.MapGet("/api/reports/daily", async (DateTime? date, ReportDbContext db) =>
{
    var start = (date ?? DateTime.Today).Date;
    var end = start.AddDays(1);

    var sales = await db.Sales
        .Where(sale => sale.PaidAt >= start && sale.PaidAt < end)
        .ToListAsync();

    return Results.Ok(new
    {
        Date = start,
        TotalOrders = sales.Count,
        TotalSales = sales.Sum(sale => sale.Amount)
    });
});

app.MapGet("/api/reports/weekly", async (DateTime? date, ReportDbContext db) =>
{
    var selectedDate = (date ?? DateTime.Today).Date;
    var start = selectedDate.AddDays(-(int)selectedDate.DayOfWeek);
    var end = start.AddDays(7);

    var sales = await db.Sales
        .Where(sale => sale.PaidAt >= start && sale.PaidAt < end)
        .ToListAsync();

    return Results.Ok(new
    {
        WeekStart = start,
        WeekEnd = end.AddDays(-1),
        TotalOrders = sales.Count,
        TotalSales = sales.Sum(sale => sale.Amount)
    });
});

app.MapGet("/api/reports/monthly", async (int? year, int? month, ReportDbContext db) =>
{
    var selectedYear = year ?? DateTime.Today.Year;
    var selectedMonth = month ?? DateTime.Today.Month;
    var start = new DateTime(selectedYear, selectedMonth, 1);
    var end = start.AddMonths(1);

    var sales = await db.Sales
        .Where(sale => sale.PaidAt >= start && sale.PaidAt < end)
        .ToListAsync();

    return Results.Ok(new
    {
        Year = selectedYear,
        Month = selectedMonth,
        TotalOrders = sales.Count,
        TotalSales = sales.Sum(sale => sale.Amount)
    });
});

app.MapGet("/api/reports/sales", async (ReportDbContext db) =>
{
    var sales = await db.Sales
        .OrderByDescending(sale => sale.PaidAt)
        .ToListAsync();

    return Results.Ok(sales);
});

app.Run();
