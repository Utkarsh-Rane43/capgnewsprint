using Microsoft.EntityFrameworkCore;
using SalesReportService.Models;

namespace SalesReportService.Data;

public class ReportDbContext : DbContext
{
    public ReportDbContext(DbContextOptions<ReportDbContext> options) : base(options)
    {
    }

    public DbSet<SaleRecord> Sales => Set<SaleRecord>();
}
