using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using AuthService.Data;
using AuthService.Models;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<AuthDbContext>(options =>
{
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection"));
});

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo
    {
        Title = "Pharmacy Authentication API",
        Version = "v1",
        Description = "Registration, login and role-based user administration."
    });
    options.AddSecurityDefinition("Bearer", new Microsoft.OpenApi.Models.OpenApiSecurityScheme
    {
        Name = "Authorization",
        Type = Microsoft.OpenApi.Models.SecuritySchemeType.Http,
        Scheme = "bearer",
        BearerFormat = "JWT",
        In = Microsoft.OpenApi.Models.ParameterLocation.Header,
        Description = "Enter the JWT token returned by /api/auth/login. Do not add the word Bearer."
    });
    options.AddSecurityRequirement(new Microsoft.OpenApi.Models.OpenApiSecurityRequirement
    {
        {
            new Microsoft.OpenApi.Models.OpenApiSecurityScheme
            {
                Reference = new Microsoft.OpenApi.Models.OpenApiReference
                {
                    Type = Microsoft.OpenApi.Models.ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            }, Array.Empty<string>()
        }
    });
});

var jwtKey = builder.Configuration["Jwt:Key"]!;
var jwtIssuer = builder.Configuration["Jwt:Issuer"]!;
var jwtAudience = builder.Configuration["Jwt:Audience"]!;

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = jwtIssuer,
            ValidAudience = jwtAudience,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey))
        };
    });

builder.Services.AddAuthorization();

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI(options =>
{
    options.SwaggerEndpoint("/swagger/v1/swagger.json", "AuthService v1");
    options.RoutePrefix = "swagger";
});

app.UseAuthentication();
app.UseAuthorization();

using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AuthDbContext>();
    await db.Database.EnsureCreatedAsync();

    // Local training seed. Override these values with environment variables before deployment.
    var adminEmail = builder.Configuration["Admin:Email"] ?? "admin@pharmacy.local";
    var adminPassword = builder.Configuration["Admin:Password"] ?? "Admin@12345";
    var adminExists = await db.Users.AnyAsync(user => user.Email == adminEmail);

    if (!adminExists)
    {
        var admin = new User
        {
            FullName = "Pharmacy Administrator",
            Email = adminEmail,
            Role = "Admin"
        };
        var hasher = new PasswordHasher<User>();
        admin.PasswordHash = hasher.HashPassword(admin, adminPassword);
        db.Users.Add(admin);
        await db.SaveChangesAsync();
    }
}

app.MapGet("/", () => "AuthService is running.");

app.MapPost("/api/auth/register", async (RegisterRequest request, AuthDbContext db) =>
{
    if (string.IsNullOrWhiteSpace(request.FullName) ||
        string.IsNullOrWhiteSpace(request.Email) ||
        string.IsNullOrWhiteSpace(request.Password))
    {
        return Results.BadRequest("Please enter name, email and password.");
    }

    var oldUser = await db.Users.FirstOrDefaultAsync(user => user.Email == request.Email);

    if (oldUser != null)
    {
        return Results.BadRequest("This email is already registered.");
    }

    var user = new User
    {
        FullName = request.FullName,
        Email = request.Email,
        Role = "Doctor"
    };

    var passwordHasher = new PasswordHasher<User>();
    user.PasswordHash = passwordHasher.HashPassword(user, request.Password);

    db.Users.Add(user);
    await db.SaveChangesAsync();

    return Results.Ok(new { message = "User registered successfully." });
});

app.MapPost("/api/auth/login", async (LoginRequest request, AuthDbContext db) =>
{
    var user = await db.Users.FirstOrDefaultAsync(item => item.Email == request.Email);

    if (user == null)
    {
        return Results.Unauthorized();
    }

    var passwordHasher = new PasswordHasher<User>();
    var passwordResult = passwordHasher.VerifyHashedPassword(
        user, user.PasswordHash, request.Password);

    if (passwordResult == PasswordVerificationResult.Failed)
    {
        return Results.Unauthorized();
    }

    var claims = new List<Claim>
    {
        new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
        new Claim(ClaimTypes.Name, user.FullName),
        new Claim(ClaimTypes.Role, user.Role)
    };

    var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey));
    var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

    var token = new JwtSecurityToken(
        issuer: jwtIssuer,
        audience: jwtAudience,
        claims: claims,
        expires: DateTime.UtcNow.AddHours(8),
        signingCredentials: credentials);

    var tokenText = new JwtSecurityTokenHandler().WriteToken(token);

    return Results.Ok(new
    {
        token = tokenText,
        user.Id,
        user.FullName,
        user.Email,
        user.Role
    });
});

app.MapGet("/api/auth/users", async (AuthDbContext db) =>
{
    var users = await db.Users
        .Select(user => new
        {
            user.Id,
            user.FullName,
            user.Email,
            user.Role
        })
        .ToListAsync();

    return Results.Ok(users);
}).RequireAuthorization().RequireRole("Admin");

app.Run();

public record RegisterRequest(string FullName, string Email, string Password);
public record LoginRequest(string Email, string Password);
