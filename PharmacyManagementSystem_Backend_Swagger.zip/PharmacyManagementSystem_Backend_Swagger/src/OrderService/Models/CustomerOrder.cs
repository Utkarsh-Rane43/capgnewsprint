namespace OrderService.Models;

public class CustomerOrder
{
    public int Id { get; set; }
    public string DoctorName { get; set; } = "";
    public DateTime CreatedAt { get; set; }
    public string Status { get; set; } = "Pending";
    public decimal Subtotal { get; set; }
    public decimal GstTotal { get; set; }
    public decimal GrandTotal { get; set; }
    public List<OrderItem> Items { get; set; } = new();
}
