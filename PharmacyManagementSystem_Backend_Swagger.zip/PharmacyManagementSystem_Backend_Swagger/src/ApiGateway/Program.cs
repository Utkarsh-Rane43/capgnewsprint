var builder = WebApplication.CreateBuilder(args);

builder.Services.AddCors(options =>
{
    options.AddPolicy("AngularDevelopment", policy =>
    {
        policy.WithOrigins("http://localhost:4200")
            .AllowAnyHeader()
            .AllowAnyMethod();
    });
});

builder.Services.AddReverseProxy()
    .LoadFromConfig(builder.Configuration.GetSection("ReverseProxy"));

var app = builder.Build();

app.UseCors("AngularDevelopment");
app.MapGet("/", () => Results.Ok(new
{
    message = "Pharmacy API Gateway is running.",
    swagger = new
    {
        auth = "http://localhost:5001/swagger",
        inventory = "http://localhost:5002/swagger",
        orders = "http://localhost:5003/swagger",
        payments = "http://localhost:5004/swagger",
        salesReports = "http://localhost:5005/swagger"
    }
}));
app.MapReverseProxy();

app.Run();
