using Microsoft.EntityFrameworkCore;
using PaymentService.Data;
using PaymentService.Models;
using PaymentService.Services;
using QuestPDF.Fluent;
using QuestPDF.Infrastructure;
using Shared.Contracts;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<PaymentDbContext>(options =>
{
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection"));
});

builder.Services.AddSingleton<RabbitPublisher>();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

QuestPDF.Settings.License = LicenseType.Community;

app.UseSwagger();
app.UseSwaggerUI(options =>
{
    options.SwaggerEndpoint("/swagger/v1/swagger.json", "PaymentService v1");
    options.RoutePrefix = "swagger";
});

using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<PaymentDbContext>();
    await db.Database.EnsureCreatedAsync();
}

app.MapGet("/", () => "PaymentService is running.");

app.MapPost("/api/payments/simulate", async (
    PaymentRequest request,
    PaymentDbContext db,
    IConfiguration configuration,
    RabbitPublisher publisher) =>
{
    if (request.OrderId <= 0 || request.Amount <= 0)
    {
        return Results.BadRequest("Enter a valid order ID and amount.");
    }

    var configuredOutcome = configuration["PaymentSimulation:Outcome"] ?? "Success";

    if (configuredOutcome.Equals("Failure", StringComparison.OrdinalIgnoreCase))
    {
        var failedPayment = new Payment
        {
            OrderId = request.OrderId,
            Amount = request.Amount,
            Status = "Failed",
            PaidAt = DateTime.UtcNow
        };

        db.Payments.Add(failedPayment);
        await db.SaveChangesAsync();

        await publisher.PublishAsync("payment.failed", new PaymentFailedEvent
        {
            OrderId = request.OrderId,
            Reason = "Payment rejected by the training simulator.",
            FailedAt = DateTime.UtcNow
        });

        return Results.BadRequest(new { message = "Payment failed in the simulator." });
    }

    var payment = new Payment
    {
        OrderId = request.OrderId,
        Amount = request.Amount,
        Status = "Success",
        PaidAt = DateTime.UtcNow
    };

    db.Payments.Add(payment);
    await db.SaveChangesAsync();

    var invoice = new Invoice
    {
        InvoiceNumber = "INV-" + DateTime.UtcNow.ToString("yyyyMMdd") + "-" + payment.Id,
        OrderId = request.OrderId,
        PaymentId = payment.Id,
        Amount = request.Amount,
        CreatedAt = DateTime.UtcNow
    };

    db.Invoices.Add(invoice);
    await db.SaveChangesAsync();

    await publisher.PublishAsync("payment.succeeded", new PaymentSucceededEvent
    {
        OrderId = request.OrderId,
        Amount = request.Amount,
        PaidAt = payment.PaidAt
    });

    return Results.Ok(new { payment, invoice });
});

app.MapGet("/api/payments", async (PaymentDbContext db) =>
{
    var payments = await db.Payments
        .OrderByDescending(payment => payment.PaidAt)
        .ToListAsync();

    return Results.Ok(payments);
});

app.MapGet("/api/invoices/{id:int}/pdf", async (int id, PaymentDbContext db) =>
{
    var invoice = await db.Invoices.FirstOrDefaultAsync(item => item.Id == id);

    if (invoice == null)
    {
        return Results.NotFound();
    }

    var pdf = Document.Create(document =>
    {
        document.Page(page =>
        {
            page.Margin(35);
            page.Header().Text("PHARMACY INVOICE").FontSize(22).Bold();
            page.Content().Column(column =>
            {
                column.Item().Text("Invoice Number: " + invoice.InvoiceNumber);
                column.Item().Text("Order ID: " + invoice.OrderId);
                column.Item().Text("Payment ID: " + invoice.PaymentId);
                column.Item().Text("Invoice Date: " + invoice.CreatedAt.ToString("dd-MM-yyyy"));
                column.Item().Text("Total Amount: Rs. " + invoice.Amount.ToString("0.00")).Bold();
                column.Item().Text("Training invoice. Verify tax and seller/buyer information before real use.");
            });
            page.Footer().AlignCenter().Text("Thank you");
        });
    }).GeneratePdf();

    return Results.File(pdf, "application/pdf", invoice.InvoiceNumber + ".pdf");
});

app.Run();

public record PaymentRequest(int OrderId, decimal Amount);
