namespace Pharmacy.Payments;

public class Payment { public int PaymentId{get;set;} public int OrderId{get;set;} public decimal Amount{get;set;} public string PaymentStatus{get;set;}="Pending"; public string TransactionReference{get;set;}=""; }
