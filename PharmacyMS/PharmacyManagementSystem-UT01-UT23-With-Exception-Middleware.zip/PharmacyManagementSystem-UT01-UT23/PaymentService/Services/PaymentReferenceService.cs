using System.Security.Cryptography;
using System.Text;

namespace Pharmacy.Payments;

/// <summary>Builds a deterministic DB-unique reference from the caller's idempotency key.</summary>
public sealed class PaymentReferenceService : IPaymentReferenceService
{
    public string Create(string idempotencyKey)
    {
        var digest = SHA256.HashData(Encoding.UTF8.GetBytes(idempotencyKey.Trim()));
        return "IDEM-" + Convert.ToHexString(digest).Substring(0, 32);
    }
}
