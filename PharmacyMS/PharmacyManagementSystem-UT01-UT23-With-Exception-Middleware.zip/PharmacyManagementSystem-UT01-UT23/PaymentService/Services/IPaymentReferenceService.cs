namespace Pharmacy.Payments;

public interface IPaymentReferenceService
{
    string Create(string idempotencyKey);
}
