using Microsoft.AspNetCore.Diagnostics;

namespace Pharmacy.Payments.Middleware;

// Handles unexpected errors from the HTTP request pipeline in one place.
public sealed class GlobalExceptionHandler : IExceptionHandler
{
    private readonly ILogger<GlobalExceptionHandler> _logger;

    public GlobalExceptionHandler(ILogger<GlobalExceptionHandler> logger)
    {
        _logger = logger;
    }

    public async ValueTask<bool> TryHandleAsync(
        HttpContext httpContext,
        Exception exception,
        CancellationToken cancellationToken)
    {
        // Keep the detailed error in application logs, not in the API response.
        _logger.LogError(exception, "An unexpected error occurred while processing the request.");

        // A response that has already started cannot safely be replaced.
        if (httpContext.Response.HasStarted)
        {
            return false;
        }

        httpContext.Response.Clear();
        httpContext.Response.StatusCode = StatusCodes.Status500InternalServerError;

        // Return a consistent and safe error response to the API caller.
        await httpContext.Response.WriteAsJsonAsync(new
        {
            statusCode = StatusCodes.Status500InternalServerError,
            message = "An unexpected error occurred. Please try again later.",
            traceId = httpContext.TraceIdentifier
        }, cancellationToken);

        return true;
    }
}
