using Microsoft.EntityFrameworkCore;
namespace Pharmacy.Payments;
public class PaymentDb(DbContextOptions<PaymentDb> options) : DbContext(options)
{
 public DbSet<Payment> Payments=>Set<Payment>();
 protected override void OnModelCreating(ModelBuilder b){var e=b.Entity<Payment>(); e.ToTable("Payments"); e.HasKey(x=>x.PaymentId); e.Property(x=>x.Amount).HasPrecision(10,2); e.Property(x=>x.PaymentStatus).HasMaxLength(20).IsRequired(); e.Property(x=>x.TransactionReference).HasMaxLength(100).IsRequired(); e.HasIndex(x=>x.TransactionReference).IsUnique(); }
}
