using Microsoft.EntityFrameworkCore;

namespace Pharmacy.Payments;

/// <summary>Entity Framework implementation for this microservice's own database only.</summary>
public sealed class PaymentRepository(PaymentDb db) : IPaymentRepository
{
    public IQueryable<T> Query<T>() where T : class => db.Set<T>();
    public void Add<T>(T entity) where T : class => db.Set<T>().Add(entity);
    public void Remove<T>(T entity) where T : class => db.Set<T>().Remove(entity);
    public Task<int> SaveChangesAsync(CancellationToken cancellationToken = default) => db.SaveChangesAsync(cancellationToken);
}
