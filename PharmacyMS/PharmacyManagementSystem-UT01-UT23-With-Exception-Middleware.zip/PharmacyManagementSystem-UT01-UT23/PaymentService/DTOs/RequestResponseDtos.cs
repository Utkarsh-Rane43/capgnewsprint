namespace Pharmacy.Payments;

public record PaymentRequest(int OrderId, string PaymentMethod, string IdempotencyKey, bool SimulateFailure = false);
public record OrderDto(int OrderId, int UserId, decimal TotalAmount, string OrderStatus);
public record AuthUserDto(int UserId, string FullName, string Email, string Role, bool IsActive);
