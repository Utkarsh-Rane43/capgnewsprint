namespace Pharmacy.Notify;

public record EmailRequest(string To, string Subject, string Body, string? AttachmentFileName = null, string? AttachmentBase64 = null);
