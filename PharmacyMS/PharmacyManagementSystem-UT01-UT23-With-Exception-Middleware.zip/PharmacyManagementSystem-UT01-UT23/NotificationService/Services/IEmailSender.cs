namespace Pharmacy.Notify;

public interface IEmailSender
{
    Task Send(string to, string subject, string body, string? attachmentFileName = null, string? attachmentBase64 = null);
}
