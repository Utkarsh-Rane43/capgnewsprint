using System.ComponentModel.DataAnnotations;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Microsoft.Data.SqlClient;
using Microsoft.IdentityModel.Tokens;
namespace Pharmacy.Auth;
public class AuthService(IAuthRepository repository, IConfiguration cfg)
{
    public async Task<User> Register(string name, string email, string password, string role, string? adminCode)
    {
        if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("Full name is required.");
        if (string.IsNullOrWhiteSpace(email) || !new EmailAddressAttribute().IsValid(email)) throw new ArgumentException("A valid email address is required.");
        if (string.IsNullOrWhiteSpace(password) || password.Length < 8) throw new ArgumentException("Password must contain at least 8 characters.");
        role = (role ?? "Doctor").Trim();
        if (role is not ("Doctor" or "Admin")) throw new ArgumentException("Role must be Doctor or Admin.");
        if (role == "Admin")
        {
            var expectedCode = cfg["Registration:AdminInvitationCode"];
            if (string.IsNullOrWhiteSpace(expectedCode) || !CryptographicOperations.FixedTimeEquals(Encoding.UTF8.GetBytes(adminCode ?? ""), Encoding.UTF8.GetBytes(expectedCode)))
                throw new UnauthorizedAccessException("A valid Admin invitation code is required.");
        }
        else if (!string.IsNullOrWhiteSpace(adminCode)) throw new ArgumentException("Admin invitation code is only valid for Admin registration.");
        var normalizedEmail = email.Trim().ToLowerInvariant();
        if (await repository.Query<User>().AnyAsync(x => x.Email == normalizedEmail)) throw new DuplicateEmailException();
        var user = new User { FullName = name.Trim(), Email = normalizedEmail, PasswordHash = Hash(password), Role = role };
        repository.Add(user);
        try { await repository.SaveChangesAsync(); }
        catch (DbUpdateException ex) when (ex.GetBaseException() is SqlException sqlException && (sqlException.Number == 2601 || sqlException.Number == 2627))
        {
            throw new DuplicateEmailException();
        }
        return user;
    }
    public async Task<(User user, string token)> Login(string email, string password)
    {
        var normalizedEmail = (email ?? "").Trim().ToLowerInvariant();
        var user = await repository.Query<User>().SingleOrDefaultAsync(x => x.Email == normalizedEmail) ?? throw new UnauthorizedAccessException("Invalid credentials.");
        if (!user.IsActive || !Verify(password ?? "", user.PasswordHash)) throw new UnauthorizedAccessException("Invalid credentials.");
        var claims = new[]
        {
            new Claim(JwtRegisteredClaimNames.Sub, user.UserId.ToString()),
            new Claim(ClaimTypes.NameIdentifier, user.UserId.ToString()),
            new Claim(JwtRegisteredClaimNames.Email, user.Email),
            new Claim(ClaimTypes.Role, user.Role)
        };
        var keyText = cfg["Jwt:Key"] ?? throw new InvalidOperationException("Jwt:Key is not configured.");
        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(keyText));
        var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
        var token = new JwtSecurityToken(cfg["Jwt:Issuer"], cfg["Jwt:Audience"], claims, expires: DateTime.UtcNow.AddHours(1), signingCredentials: credentials);
        return (user, new JwtSecurityTokenHandler().WriteToken(token));
    }
    public static string Hash(string value)
    {
        var salt = RandomNumberGenerator.GetBytes(16);
        var hash = Rfc2898DeriveBytes.Pbkdf2(value, salt, 120000, HashAlgorithmName.SHA256, 32);
        return Convert.ToBase64String(salt) + ":" + Convert.ToBase64String(hash);
    }
    public static bool Verify(string value, string stored)
    {
        try
        {
            var parts = stored.Split(':');
            if (parts.Length != 2) return false;
            var hash = Rfc2898DeriveBytes.Pbkdf2(value, Convert.FromBase64String(parts[0]), 120000, HashAlgorithmName.SHA256, 32);
            return CryptographicOperations.FixedTimeEquals(hash, Convert.FromBase64String(parts[1]));
        }
        catch { return false; }
    }
}

public sealed class DuplicateEmailException : Exception { public DuplicateEmailException() : base("Email already registered.") { } }
