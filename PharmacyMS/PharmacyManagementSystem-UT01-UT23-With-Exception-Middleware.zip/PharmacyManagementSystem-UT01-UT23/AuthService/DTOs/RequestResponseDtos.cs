namespace Pharmacy.Auth;

public record RegisterRequest(string FullName, string Email, string Password, string Role = "Doctor", string? AdminInvitationCode = null);
public record LoginRequest(string Email, string Password);
public record UpdateUserRequest(string FullName, bool IsActive);
public record UpdateUserStatusRequest(bool IsActive);
