using Microsoft.EntityFrameworkCore;
namespace Pharmacy.Auth;
public class AuthDb(DbContextOptions<AuthDb> options) : DbContext(options)
{
    public DbSet<User> Users => Set<User>();
    protected override void OnModelCreating(ModelBuilder b)
    {
        var e = b.Entity<User>();
        e.ToTable("Users"); e.HasKey(x => x.UserId);
        e.Property(x => x.FullName).HasMaxLength(100).IsRequired();
        e.Property(x => x.Email).HasMaxLength(150).IsRequired();
        e.Property(x => x.PasswordHash).HasMaxLength(255).IsRequired();
        e.Property(x => x.Role).HasMaxLength(20).IsRequired();
        e.Property(x => x.IsActive).IsRequired();
        e.HasIndex(x => x.Email).IsUnique();
    }
}
