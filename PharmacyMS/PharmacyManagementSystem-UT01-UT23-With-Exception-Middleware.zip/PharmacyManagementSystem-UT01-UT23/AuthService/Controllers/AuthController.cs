using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using System.Net.Http.Json;
namespace Pharmacy.Auth;
[ApiController]
[Route("api")]
public class AuthController(AuthService service, IAuthRepository repository, IHttpClientFactory clients, ILogger<AuthController> logger) : ControllerBase
{
    [AllowAnonymous, HttpPost("auth/register")]
    public async Task<IActionResult> Register(RegisterRequest request)
    {
        try
        {
            var user = await service.Register(request.FullName, request.Email, request.Password, request.Role, request.AdminInvitationCode);
            try
            {
                await clients.CreateClient("Notify").PostAsJsonAsync("/api/notifications/email", new
                {
                    to = user.Email,
                    subject = "Pharmacy Management System registration",
                    body = $@"<!doctype html><html><body style=""font-family:Arial,sans-serif;background:#f3f6fa;padding:24px;color:#243247""><div style=""max-width:600px;margin:auto;background:#fff;border:1px solid #e4eaf1;border-radius:10px;overflow:hidden""><div style=""background:#17365d;color:#fff;padding:22px 28px""><h2 style=""margin:0"">Welcome to Pharmacy Management System</h2></div><div style=""padding:26px 28px""><p>Hello {System.Net.WebUtility.HtmlEncode(user.FullName)},</p><p>Your {System.Net.WebUtility.HtmlEncode(user.Role)} account has been created successfully.</p><p>You can now sign in using your registered email address and password. Keep your login credentials confidential.</p><p>Regards,<br/>Pharmacy Management Team</p></div><div style=""padding:14px 28px;background:#f8fafc;color:#718096;font-size:12px"">Automated account notification. Please do not reply.</div></div></body></html>"
                });
            }
            catch (Exception ex) { logger.LogWarning(ex, "Registration notification could not be sent."); }
            return StatusCode(201, new { success = true, message = "User registered successfully", data = new { user.UserId, user.FullName, user.Email, user.Role } });
        }
        catch (UnauthorizedAccessException ex) { return Unauthorized(new { success = false, message = ex.Message }); }
        catch (DuplicateEmailException ex) { return Conflict(new { success = false, message = ex.Message }); }
        catch (ArgumentException ex) { return BadRequest(new { success = false, message = ex.Message }); }
    }
    [AllowAnonymous, HttpPost("auth/login")]
    public async Task<IActionResult> Login(LoginRequest request)
    {
        try
        {
            var (user, token) = await service.Login(request.Email, request.Password);
            return Ok(new { success = true, message = "Login successful", data = new { user.UserId, user.Email, user.Role, token, expiresIn = 3600 } });
        }
        catch (UnauthorizedAccessException ex) { return Unauthorized(new { success = false, message = ex.Message }); }
    }
    [Authorize(Roles = "Admin"), HttpGet("users")]
    public async Task<IActionResult> Users() => Ok(await repository.Query<User>().Select(u => new { u.UserId, u.FullName, u.Email, u.Role, u.IsActive }).ToListAsync());
    [Authorize, HttpGet("users/{id:int}")]
    public async Task<IActionResult> GetUser(int id)
    {
        var user = await repository.Query<User>().SingleOrDefaultAsync(u => u.UserId == id);
        if (user is null) return NotFound();
        var callerId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
        if (!User.IsInRole("Admin") && callerId != id.ToString()) return Forbid();
        return Ok(new { user.UserId, user.FullName, user.Email, user.Role, user.IsActive });
    }
    [Authorize(Roles = "Admin"), HttpPut("users/{id:int}/status")]
    public async Task<IActionResult> UpdateStatus(int id, UpdateUserStatusRequest request)
    {
        var user = await repository.Query<User>().SingleOrDefaultAsync(u => u.UserId == id);
        if (user is null) return NotFound(new { message = "User not found." });
        if (user.Role != "Doctor") return BadRequest(new { message = "Only Doctor accounts can be deactivated or reactivated here." });
        user.IsActive = request.IsActive;
        await repository.SaveChangesAsync();
        try
        {
            var action = request.IsActive ? "reactivated" : "deactivated";
            var subject = request.IsActive ? "Your pharmacy account has been reactivated" : "Your pharmacy account has been deactivated";
            var body = $@"<!doctype html><html><body style=""font-family:Arial,sans-serif;background:#f3f6fa;padding:24px;color:#243247""><div style=""max-width:600px;margin:auto;background:#fff;border:1px solid #e4eaf1;border-radius:10px;overflow:hidden""><div style=""background:#17365d;color:#fff;padding:22px 28px""><h2 style=""margin:0"">Account status update</h2></div><div style=""padding:26px 28px""><p>Hello {System.Net.WebUtility.HtmlEncode(user.FullName)},</p><p>Your Doctor account has been <b>{action}</b> by the pharmacy administrator.</p><p>Account status: <b>{(request.IsActive ? "Active" : "Inactive")}</b></p><p>{(request.IsActive ? "You can sign in again using your registered credentials." : "You will not be able to sign in while your account is inactive. If you believe this is incorrect, please contact the pharmacy administrator.")}</p><p>Regards,<br/>Pharmacy Management Team</p></div><div style=""padding:14px 28px;background:#f8fafc;color:#718096;font-size:12px"">Automated account notification. Please do not reply.</div></div></body></html>";
            await clients.CreateClient("Notify").PostAsJsonAsync("/api/notifications/email", new { to = user.Email, subject, body });
        }
        catch (Exception ex) { logger.LogWarning(ex, "Account status email could not be sent for user {UserId}.", user.UserId); }
        return Ok(new { success = true, message = request.IsActive ? "Doctor account reactivated." : "Doctor account deactivated.", data = new { user.UserId, user.FullName, user.Email, user.Role, user.IsActive } });
    }
    [Authorize(Roles = "Admin"), HttpPut("users/{id:int}")]
    public async Task<IActionResult> Update(int id, UpdateUserRequest request)
    {
        var user = await repository.Query<User>().SingleOrDefaultAsync(u => u.UserId == id);
        if (user is null) return NotFound();
        if (string.IsNullOrWhiteSpace(request.FullName)) return BadRequest(new { message = "Full name is required." });
        user.FullName = request.FullName.Trim(); user.IsActive = request.IsActive;
        await repository.SaveChangesAsync(); return NoContent();
    }
}

