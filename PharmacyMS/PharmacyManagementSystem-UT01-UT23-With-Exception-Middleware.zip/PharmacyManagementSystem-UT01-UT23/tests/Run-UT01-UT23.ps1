param(
    [string]$BaseUrl = "http://localhost:5000",
    [string]$DoctorPassword = "DoctorPass@123",
    [string]$AdminPassword = "AdminPass@123",
    [switch]$TryEmailSuccess,
    [switch]$TryEmailFailure,
    [string]$EmailAddress = "user@test.com"
)

$ErrorActionPreference = "Stop"
$BaseUrl = $BaseUrl.TrimEnd('/')
$stamp = Get-Date -Format "yyyyMMddHHmmss"
$doctorEmail = "ut.doctor.$stamp@test.local"
$adminEmail = "ut.admin.$stamp@test.local"
$results = [System.Collections.Generic.List[object]]::new()

function Invoke-Api {
    param(
        [string]$Method,
        [string]$RootUrl,
        [string]$Path,
        [object]$Body = $null,
        [string]$Token = "",
        [hashtable]$ExtraHeaders = @{}
    )
    $headers = @{}
    if ($Token) { $headers['Authorization'] = "Bearer $Token" }
    foreach ($key in $ExtraHeaders.Keys) { $headers[$key] = $ExtraHeaders[$key] }
    $params = @{ Method = $Method; Uri = ($RootUrl.TrimEnd('/') + $Path); Headers = $headers; UseBasicParsing = $true; ErrorAction = 'Stop' }
    if ($null -ne $Body) {
        $params['ContentType'] = 'application/json'
        $params['Body'] = ($Body | ConvertTo-Json -Depth 20 -Compress)
    }
    try {
        $response = Invoke-WebRequest @params
        $raw = [string]$response.Content
        $status = [int]$response.StatusCode
    }
    catch {
        $webResponse = $_.Exception.Response
        if ($null -eq $webResponse) { throw }
        $status = [int]$webResponse.StatusCode
        $raw = ''
        try {
            $stream = $webResponse.GetResponseStream()
            if ($stream) {
                $reader = [System.IO.StreamReader]::new($stream)
                $raw = $reader.ReadToEnd()
                $reader.Dispose()
            }
        } catch { }
    }
    $parsed = $null
    if ($raw) { try { $parsed = $raw | ConvertFrom-Json } catch { } }
    return [pscustomobject]@{ Status = $status; Body = $parsed; Raw = $raw }
}

function Record-Test([string]$Id, [string]$Name, [int]$Expected, $Response) {
    $actual = if ($null -eq $Response) { 0 } else { [int]$Response.Status }
    $passed = ($actual -eq $Expected)
    $state = if ($passed) { 'PASS' } else { 'FAIL' }
    $results.Add([pscustomobject]@{ ID = $Id; Scenario = $Name; Expected = $Expected; Actual = $actual; Result = $state })
    Write-Host ("{0} {1} - expected {2}, got {3}" -f $state,$Id,$Expected,$actual)
    return $Response
}

function New-Order([string]$Token, [int]$DrugId, [int]$Qty) {
    return Invoke-Api -Method POST -RootUrl $BaseUrl -Path '/api/orders' -Token $Token -Body @{ items = @(@{ drugId = $DrugId; quantity = $Qty }) }
}

# Read local test-only configuration for the Admin invitation code and internal service key.
$authConfig = Get-Content (Join-Path $PSScriptRoot '..\AuthService\appsettings.json') -Raw | ConvertFrom-Json
$inventoryConfig = Get-Content (Join-Path $PSScriptRoot '..\InventoryService\appsettings.json') -Raw | ConvertFrom-Json
$notifyConfig = Get-Content (Join-Path $PSScriptRoot '..\NotificationService\appsettings.json') -Raw | ConvertFrom-Json
$adminCode = [string]$authConfig.Registration.AdminInvitationCode
$internalKey = [string]$inventoryConfig.Internal.ServiceKey

Write-Host "Running Pharmacy Management System acceptance tests against $BaseUrl"
Write-Host "Unique Doctor test account: $doctorEmail"

# UT01-UT04: Authentication
$r = Invoke-Api POST $BaseUrl '/api/auth/register' @{ fullName='UT Doctor'; email=$doctorEmail; password=$DoctorPassword; role='Doctor' }
Record-Test 'UT01' 'Register valid user' 201 $r | Out-Null
$r = Invoke-Api POST $BaseUrl '/api/auth/register' @{ fullName='UT Doctor Duplicate'; email=$doctorEmail; password=$DoctorPassword; role='Doctor' }
Record-Test 'UT02' 'Register duplicate email' 409 $r | Out-Null
$login = Invoke-Api POST $BaseUrl '/api/auth/login' @{ email=$doctorEmail; password=$DoctorPassword }
Record-Test 'UT03' 'Login with valid credentials' 200 $login | Out-Null
$doctorToken = [string]$login.Body.data.token
$r = Invoke-Api POST $BaseUrl '/api/auth/login' @{ email=$doctorEmail; password='DefinitelyWrong@123' }
Record-Test 'UT04' 'Login with wrong password' 401 $r | Out-Null
if (-not $doctorToken) { throw 'Could not obtain a Doctor JWT; stopping dependent tests.' }

# Create a test Admin. This is setup data, not an additional UT case.
$r = Invoke-Api POST $BaseUrl '/api/auth/register' @{ fullName='UT Admin'; email=$adminEmail; password=$AdminPassword; role='Admin'; adminInvitationCode=$adminCode }
if ($r.Status -ne 201) { throw "Admin setup failed with HTTP $($r.Status). Check Registration:AdminInvitationCode in AuthService/appsettings.json." }
$adminLogin = Invoke-Api POST $BaseUrl '/api/auth/login' @{ email=$adminEmail; password=$AdminPassword }
if ($adminLogin.Status -ne 200) { throw 'Admin login setup failed.' }
$adminToken = [string]$adminLogin.Body.data.token

# UT05-UT10: Inventory. A Supplier is needed because Drug.SupplierId is a real FK in InventoryDB.
$supplier = Invoke-Api POST $BaseUrl '/api/suppliers' @{ supplierName='UT Test Supplier'; email='supplier@test.local'; phone='0000000000'; address='Test Address' } $adminToken
if ($supplier.Status -ne 201) { throw "Supplier setup failed with HTTP $($supplier.Status)." }
$supplierId = [int]$supplier.Body.supplierId
$expiry = (Get-Date).AddYears(2).ToString('yyyy-MM-dd')
$drugBody = @{ drugName='Paracetamol UT'; manufacturer='UT Pharma'; price=25; expiryDate=$expiry; supplierId=$supplierId; initialQuantity=100 }
$drug = Invoke-Api POST $BaseUrl '/api/drugs' $drugBody $adminToken
Record-Test 'UT05' 'Add medicine' 201 $drug | Out-Null
if ($drug.Status -ne 201) { throw "UT test setup stopped: medicine could not be created (HTTP $($drug.Status))." }
$drugId = [int]$drug.Body.drugId
$negative = Invoke-Api POST $BaseUrl '/api/drugs' (@{ drugName='Invalid'; manufacturer='UT Pharma'; price=-25; expiryDate=$expiry; supplierId=$supplierId; initialQuantity=10 }) $adminToken
Record-Test 'UT06' 'Add medicine with negative price' 400 $negative | Out-Null
$r = Invoke-Api GET $BaseUrl ("/api/inventory/{0}" -f $drugId) $null $doctorToken
Record-Test 'UT07' 'Check available stock' 200 $r | Out-Null
$internalRoot = 'http://localhost:5002'
$r = Invoke-Api POST $internalRoot '/api/inventory/reserve' @{ drugId=$drugId; quantity=5 } '' @{ 'X-Internal-Key' = $internalKey }
Record-Test 'UT08' 'Reserve available stock' 200 $r | Out-Null
$r = Invoke-Api POST $internalRoot '/api/inventory/reserve' @{ drugId=$drugId; quantity=10000 } '' @{ 'X-Internal-Key' = $internalKey }
Record-Test 'UT09' 'Reserve unavailable stock' 409 $r | Out-Null
$r = Invoke-Api POST $internalRoot '/api/inventory/release' @{ drugId=$drugId; quantity=5 } '' @{ 'X-Internal-Key' = $internalKey }
Record-Test 'UT10' 'Release reserved stock' 200 $r | Out-Null

# UT11-UT15: Orders. A separate pending order is created for rejection after UT13 verifies the first.
$order1 = New-Order $doctorToken $drugId 2
Record-Test 'UT11' 'Place valid order' 201 $order1 | Out-Null
$r = Invoke-Api POST $BaseUrl '/api/orders' @{ items=@() } $doctorToken
Record-Test 'UT12' 'Place empty order' 400 $r | Out-Null
if ($order1.Status -ne 201) { throw 'Could not create first order; stopping dependent order/payment tests.' }
$order1Id = [int]$order1.Body.data.orderId
$r = Invoke-Api PUT $BaseUrl ("/api/orders/{0}/verify" -f $order1Id) $null $adminToken
Record-Test 'UT13' 'Verify pending order' 200 $r | Out-Null
$order2 = New-Order $doctorToken $drugId 2
if ($order2.Status -ne 201) { throw 'Could not create second order required for rejection tests.' }
$order2Id = [int]$order2.Body.data.orderId
$r = Invoke-Api PUT $BaseUrl ("/api/orders/{0}/reject" -f $order2Id) $null $adminToken
Record-Test 'UT14' 'Reject pending order and release stock' 200 $r | Out-Null
$r = Invoke-Api PUT $BaseUrl ("/api/orders/{0}/verify" -f $order2Id) $null $adminToken
Record-Test 'UT15' 'Verify rejected order' 409 $r | Out-Null

# UT16-UT18: Payments. Payment amount is read from the stored order total; it is not accepted from the client.
$key16 = "UT16-$stamp"
$r = Invoke-Api POST $BaseUrl '/api/payments' @{ orderId=$order1Id; paymentMethod='Card'; idempotencyKey=$key16; simulateFailure=$false } $doctorToken
Record-Test 'UT16' 'Process valid simulated payment' 200 $r | Out-Null
$order3 = New-Order $doctorToken $drugId 2
if ($order3.Status -ne 201) { throw 'Could not create third order required for failed-payment tests.' }
$order3Id = [int]$order3.Body.data.orderId
$r = Invoke-Api PUT $BaseUrl ("/api/orders/{0}/verify" -f $order3Id) $null $adminToken
if ($r.Status -ne 200) { throw 'Could not verify third order for UT17/UT18.' }
$key18 = "PAY501-$stamp"
$failureBody = @{ orderId=$order3Id; paymentMethod='Card'; idempotencyKey=$key18; simulateFailure=$true }
$r = Invoke-Api POST $BaseUrl '/api/payments' $failureBody $doctorToken
Record-Test 'UT17' 'Process failed simulated payment' 200 $r | Out-Null
$firstPaymentId = $r.Body.data.paymentId
$r = Invoke-Api POST $BaseUrl '/api/payments' $failureBody $doctorToken
Record-Test 'UT18' 'Repeat payment with same idempotency key' 200 $r | Out-Null
if ($r.Body.data.paymentId -ne $firstPaymentId) { Write-Host 'FAIL UT18 duplicate response returned a different PaymentId.'; $results.Add([pscustomobject]@{ID='UT18-CHECK';Scenario='Same payment record replayed';Expected=$firstPaymentId;Actual=$r.Body.data.paymentId;Result='FAIL'}) }

# UT19: Invoice after a successful payment.
$r = Invoke-Api GET $BaseUrl ("/api/invoices/{0}" -f $order1Id) $null $doctorToken
Record-Test 'UT19' 'Retrieve paid-order invoice' 200 $r | Out-Null

# UT20-UT21: Security.
$r = Invoke-Api GET $BaseUrl '/api/users'
Record-Test 'UT20' 'Access protected Admin API without token' 401 $r | Out-Null
$r = Invoke-Api GET $BaseUrl '/api/users' $null $doctorToken
Record-Test 'UT21' 'Doctor accesses Admin-only API' 403 $r | Out-Null

# UT22/UT23: SMTP-dependent tests. UT22 needs working SMTP credentials; UT23 needs invalid/unavailable SMTP configuration.
if ($TryEmailSuccess) {
    $r = Invoke-Api POST $BaseUrl '/api/notifications/email' @{ to=$EmailAddress; subject='UT22 Pharmacy test'; body='UT22 email delivery test.' }
    Record-Test 'UT22' 'Send email successfully' 200 $r | Out-Null
} else {
    $results.Add([pscustomobject]@{ ID='UT22'; Scenario='Send email successfully'; Expected=200; Actual='SKIPPED'; Result='SKIPPED - use -TryEmailSuccess after SMTP setup' })
    Write-Host 'SKIP UT22 - pass -TryEmailSuccess after SMTP is configured.'
}
if ($TryEmailFailure) {
    $r = Invoke-Api POST $BaseUrl '/api/notifications/email' @{ to=$EmailAddress; subject='UT23 SMTP failure test'; body='This should fail when SMTP is unavailable.' }
    Record-Test 'UT23' 'Handle SMTP failure' 500 $r | Out-Null
} elseif ([string]::IsNullOrWhiteSpace([string]$notifyConfig.Smtp.Host)) {
    $r = Invoke-Api POST $BaseUrl '/api/notifications/email' @{ to=$EmailAddress; subject='UT23 SMTP failure test'; body='Expected failure because SMTP host is not configured.' }
    Record-Test 'UT23' 'Handle SMTP failure with missing SMTP host' 500 $r | Out-Null
} else {
    $results.Add([pscustomobject]@{ ID='UT23'; Scenario='Handle SMTP failure'; Expected=500; Actual='SKIPPED'; Result='SKIPPED - set invalid SMTP config and use -TryEmailFailure' })
    Write-Host 'SKIP UT23 - set SMTP to an unavailable host, restart NotificationService, then pass -TryEmailFailure.'
}

Write-Host "`n========== ACCEPTANCE TEST SUMMARY =========="
$results | Format-Table -AutoSize
$failed = @($results | Where-Object { $_.Result -like 'FAIL*' }).Count
$skipped = @($results | Where-Object { $_.Result -like 'SKIPPED*' }).Count
Write-Host ("Passed: {0} | Failed: {1} | Skipped: {2}" -f (@($results | Where-Object Result -eq 'PASS').Count),$failed,$skipped)
if ($failed -gt 0) { exit 1 }
