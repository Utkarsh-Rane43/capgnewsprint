using Microsoft.EntityFrameworkCore;
namespace Pharmacy.Orders;
public class OrderDb(DbContextOptions<OrderDb> options) : DbContext(options)
{
 public DbSet<Order> Orders=>Set<Order>(); public DbSet<OrderItem> OrderItems=>Set<OrderItem>();
 protected override void OnModelCreating(ModelBuilder b){ var o=b.Entity<Order>(); o.ToTable("Orders"); o.HasKey(x=>x.OrderId); o.Property(x=>x.TotalAmount).HasPrecision(10,2); o.Property(x=>x.OrderDate).HasColumnType("datetime"); o.Property(x=>x.OrderStatus).HasMaxLength(20).IsRequired(); var i=b.Entity<OrderItem>(); i.ToTable("OrderItems"); i.HasKey(x=>x.OrderItemId); i.Property(x=>x.UnitPrice).HasPrecision(10,2); i.Property(x=>x.SubTotal).HasPrecision(10,2); o.HasMany(x=>x.Items).WithOne().HasForeignKey(x=>x.OrderId).OnDelete(DeleteBehavior.Cascade); }
}
