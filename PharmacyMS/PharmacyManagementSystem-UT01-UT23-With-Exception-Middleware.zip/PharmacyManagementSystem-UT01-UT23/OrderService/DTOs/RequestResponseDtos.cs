namespace Pharmacy.Orders;

public record PaymentInfo(int PaymentId, int OrderId, decimal Amount, string PaymentStatus, string TransactionReference);
public record InvoiceDrugInfo(int DrugId, string DrugName);
public record PlaceOrderRequest(List<PlaceOrderItem> Items);
public record PlaceOrderItem(int DrugId, int Quantity);
public record DrugDto(int DrugId, string DrugName, string Manufacturer, decimal Price, DateTime ExpiryDate, int SupplierId);
public record StockDto(int InventoryId, int DrugId, int AvailableQuantity, int ReservedQuantity);
public record PaymentStatusRequest(string Status);
public record AuthUserDto(int UserId, string FullName, string Email, string Role, bool IsActive);
