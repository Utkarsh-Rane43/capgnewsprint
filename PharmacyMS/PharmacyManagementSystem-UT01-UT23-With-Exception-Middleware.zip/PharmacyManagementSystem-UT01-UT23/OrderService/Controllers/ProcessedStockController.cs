using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Pharmacy.Orders;

[ApiController]
public class ProcessedStockController(IOrderRepository repository, IConfiguration config) : ControllerBase
{
    // Internal read-only summary. Processed means units belonging to successfully paid orders.
    [HttpGet("/internal/orders/processed-stock")]
    public async Task<IActionResult> Get()
    {
        var key = config["Internal:ServiceKey"];
        if (string.IsNullOrWhiteSpace(key) || Request.Headers["X-Internal-Key"] != key)
            return Unauthorized();

        var rows = await repository.Query<OrderItem>()
            .Join(repository.Query<Order>(), item => item.OrderId, order => order.OrderId,
                (item, order) => new { item.DrugId, item.Quantity, order.OrderStatus })
            .Where(x => x.OrderStatus == "Paid" || x.OrderStatus == "PickedUp")
            .GroupBy(x => x.DrugId)
            .Select(g => new { drugId = g.Key, processedQuantity = g.Sum(x => x.Quantity) })
            .ToListAsync();

        return Ok(rows);
    }
}
