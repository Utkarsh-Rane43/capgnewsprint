using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using System.Net.Http.Json;
namespace Pharmacy.Orders;
[ApiController, Route("api/orders"), Authorize]
public class OrderController(IOrderRepository repository, IOrderWorkflowService workflow, IHttpClientFactory clients, IConfiguration config) : ControllerBase
{
    [HttpPost, Authorize(Roles = "Doctor")]
    public async Task<IActionResult> Place(PlaceOrderRequest request)
    {
        if (request.Items is null || request.Items.Count == 0 || request.Items.Any(x => x.Quantity <= 0)) return BadRequest(new { message = "Order must contain at least one item with a positive quantity." });
        var userId = GetUserId(); if (userId <= 0) return Unauthorized();
        var inventory = clients.CreateClient("Inventory"); ForwardUserToken(inventory);
        var items = new List<OrderItem>(); decimal total = 0;
        foreach (var requested in request.Items)
        {
            var drugResponse = await inventory.GetAsync($"/api/drugs/{requested.DrugId}");
            if (!drugResponse.IsSuccessStatusCode) return BadRequest(new { message = $"Medicine {requested.DrugId} was not found or is unavailable." });
            var drug = await drugResponse.Content.ReadFromJsonAsync<DrugDto>();
            if (drug is null || drug.ExpiryDate.Date <= DateTime.UtcNow.Date) return BadRequest(new { message = "Medicine is inactive, expired or invalid." });
            var stockResponse = await inventory.GetAsync($"/api/inventory/{requested.DrugId}");
            if (!stockResponse.IsSuccessStatusCode) return Conflict(new { message = $"Stock for medicine {requested.DrugId} is unavailable." });
            var stock = await stockResponse.Content.ReadFromJsonAsync<StockDto>();
            if (stock is null || stock.AvailableQuantity < requested.Quantity) return Conflict(new { message = $"Insufficient stock for medicine {requested.DrugId}." });
            var lineTotal = drug.Price * requested.Quantity;
            items.Add(new OrderItem { DrugId = requested.DrugId, Quantity = requested.Quantity, UnitPrice = drug.Price, SubTotal = lineTotal });
            total += lineTotal;
        }
        var reserved = new List<OrderItem>();
        foreach (var item in items)
        {
            var response = await PostInternalInventoryAsync(inventory, "reserve", item.DrugId, item.Quantity);
            if (!response.IsSuccessStatusCode)
            {
                foreach (var previous in reserved) await PostInternalInventoryAsync(inventory, "release", previous.DrugId, previous.Quantity);
                return Conflict(new { message = "Stock reservation failed. No order was created; completed reservations were released." });
            }
            reserved.Add(item);
        }
        var order = new Order { UserId = userId, TotalAmount = total, Items = items };
        repository.Add(order);
        try { await repository.SaveChangesAsync(); }
        catch
        {
            foreach (var item in reserved) await PostInternalInventoryAsync(inventory, "release", item.DrugId, item.Quantity);
            throw;
        }
        await TryNotifyAsync(userId, $"Order received — #{order.OrderId}", EmailTemplates.OrderPlaced(order));
        return StatusCode(201, new { success = true, message = "Order placed successfully", data = new { order.OrderId, order.TotalAmount, order.OrderStatus } });
    }
    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        IQueryable<Order> query = repository.Query<Order>().Include(x => x.Items);
        if (!User.IsInRole("Admin")) query = query.Where(x => x.UserId == GetUserId());
        return Ok(await query.OrderByDescending(x => x.OrderDate).ToListAsync());
    }
    [HttpGet("my-orders"), Authorize(Roles = "Doctor")]
    public async Task<IActionResult> Mine() => Ok(await repository.Query<Order>().Include(x => x.Items).Where(x => x.UserId == GetUserId()).OrderByDescending(x => x.OrderDate).ToListAsync());
    [HttpGet("{id:int}")]
    public async Task<IActionResult> Get(int id)
    {
        var order = await repository.Query<Order>().Include(x => x.Items).SingleOrDefaultAsync(x => x.OrderId == id);
        if (order is null) return NotFound();
        if (!User.IsInRole("Admin") && order.UserId != GetUserId()) return Forbid();
        return Ok(order);
    }
    [HttpPut("{id:int}/verify"), Authorize(Roles = "Admin")]
    public async Task<IActionResult> Verify(int id)
    {
        var order = await repository.Query<Order>().Include(x => x.Items).SingleOrDefaultAsync(x => x.OrderId == id);
        if (order is null) return NotFound();
        if (!workflow.CanVerify(order)) return Conflict(new { message = "Only pending orders can be verified." });
        order.OrderStatus = "Verified"; await repository.SaveChangesAsync();
        await TryNotifyAsync(order.UserId, $"Order approved — #{id}", EmailTemplates.OrderVerified(order));
        return Ok(new { success = true, message = "Order verified", data = order });
    }
    [HttpPut("{id:int}/reject"), Authorize(Roles = "Admin")]
    public async Task<IActionResult> Reject(int id)
    {
        var order = await repository.Query<Order>().Include(x => x.Items).SingleOrDefaultAsync(x => x.OrderId == id);
        if (order is null) return NotFound();
        if (!workflow.CanReject(order)) return Conflict(new { message = "Only pending orders can be rejected." });
        var inventory = clients.CreateClient("Inventory");
        foreach (var item in order.Items)
        {
            var response = await PostInternalInventoryAsync(inventory, "release", item.DrugId, item.Quantity);
            if (!response.IsSuccessStatusCode) return StatusCode(502, new { message = "Could not release reserved stock. Order remains pending; retry after Inventory Service is available." });
        }
        order.OrderStatus = "Rejected"; await repository.SaveChangesAsync();
        await TryNotifyAsync(order.UserId, $"Order update — #{id}", EmailTemplates.OrderRejected(order));
        return Ok(new { success = true, message = "Order rejected and reserved stock released", data = order });
    }
    [HttpPost("{id:int}/cancel"), Authorize(Roles = "Doctor")]
    public async Task<IActionResult> Cancel(int id)
    {
        var order = await repository.Query<Order>().Include(x => x.Items).SingleOrDefaultAsync(x => x.OrderId == id);
        if (order is null) return NotFound();
        if (order.UserId != GetUserId()) return Forbid();
        if (!workflow.CanCancel(order))
            return Conflict(new { message = order.OrderStatus is "PickedUp" or "Cancelled" ? "This order can no longer be cancelled." : "Only pending, verified or paid orders can be cancelled." });

        var wasPaid = workflow.WasPaid(order);
        var inventory = clients.CreateClient("Inventory");
        var released = new List<OrderItem>();
        foreach (var item in order.Items)
        {
            var response = await PostInternalInventoryAsync(inventory, "release", item.DrugId, item.Quantity);
            if (!response.IsSuccessStatusCode)
            {
                // Compensate earlier releases so the order remains consistent if a later line fails.
                foreach (var previous in released)
                    await PostInternalInventoryAsync(inventory, "reserve", previous.DrugId, previous.Quantity);
                return StatusCode(502, new { message = "Stock could not be fully released. The system attempted to restore earlier stock changes; contact the Admin if reconciliation is needed." });
            }
            released.Add(item);
        }

        order.OrderStatus = "Cancelled";
        await repository.SaveChangesAsync();

        var subject = wasPaid
            ? $"Cancellation confirmed — Order #{id} | Refund information"
            : $"Cancellation confirmed — Order #{id}";
        var body = wasPaid
            ? EmailTemplates.OrderCancelledPaid(order, "Refunds for this simulated payment must be reviewed and processed manually to the original/source payment account. No automatic bank or UPI transfer is made by this application.")
            : EmailTemplates.OrderCancelled(order);
        await TrySendEmailAsync(order.UserId, subject, body);
        return Ok(new { success = true, message = wasPaid
            ? "Order cancelled and reserved stock released. Refund processing information has been emailed; no automatic transfer is performed."
            : "Order cancelled and reserved stock released.", data = order });
    }

    [AllowAnonymous, HttpPost("/internal/orders/{id:int}/payment-status")]
    public async Task<IActionResult> PaymentStatus(int id, PaymentStatusRequest request)
    {
        if (!IsInternalRequest()) return Unauthorized();
        if (request.Status is not ("Success" or "Failed")) return BadRequest(new { message = "Payment status must be Success or Failed." });
        var order = await repository.Query<Order>().SingleOrDefaultAsync(x => x.OrderId == id); if (order is null) return NotFound();
        if (request.Status == "Success" && !workflow.CanMarkPaid(order)) return Conflict(new { message = "Only verified orders can be marked paid." });
        if (request.Status == "Success") order.OrderStatus = "Paid";
        await repository.SaveChangesAsync(); return Ok(new { success = true, order.OrderId, order.OrderStatus });
    }
    [HttpPost("{id:int}/finalize-pickup"), Authorize(Roles = "Admin")]
    public async Task<IActionResult> FinalizePickup(int id)
    {
        var order = await repository.Query<Order>().Include(x => x.Items).SingleOrDefaultAsync(x => x.OrderId == id);
        if (order is null) return NotFound();
        if (!workflow.CanFinalizePickup(order)) return Conflict(new { message = "Only paid orders can be picked up." });
        var inventory = clients.CreateClient("Inventory");
        foreach (var item in order.Items)
        {
            var response = await PostInternalInventoryAsync(inventory, "finalize-pickup", item.DrugId, item.Quantity);
            if (!response.IsSuccessStatusCode) return StatusCode(502, new { message = "Inventory finalization failed. Do not retry blindly; reconcile reserved quantities before retrying." });
        }
        order.OrderStatus = "PickedUp"; await repository.SaveChangesAsync();
        await TryNotifyAsync(order.UserId, $"Pickup confirmed — Order #{id}", EmailTemplates.OrderPickedUp(order));
        return Ok(new { success = true, message = "Pickup finalized", data = order });
    }
    [AllowAnonymous, HttpGet("/internal/orders/sales-summary")]
    public async Task<IActionResult> SalesSummary([FromQuery] DateTime from, [FromQuery] DateTime to)
    {
        if (!IsInternalRequest()) return Unauthorized();
        if (to < from) return BadRequest(new { message = "The 'to' date must be on or after the 'from' date." });
        var start = from.Date; var end = to.Date.AddDays(1);
        var summary = await repository.Query<Order>().Where(x => (x.OrderStatus == "Paid" || x.OrderStatus == "PickedUp") && x.OrderDate >= start && x.OrderDate < end)
            .GroupBy(_ => 1).Select(g => new { TotalOrders = g.Count(), TotalSales = g.Sum(x => x.TotalAmount) })
            .SingleOrDefaultAsync();
        return Ok(new { totalOrders = summary?.TotalOrders ?? 0, totalSales = summary?.TotalSales ?? 0m });
    }
    private int GetUserId() => int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier) ?? User.FindFirstValue("sub"), out var id) ? id : 0;
    private void ForwardUserToken(HttpClient client)
    {
        var token = Request.Headers.Authorization.ToString();
        if (!string.IsNullOrWhiteSpace(token)) client.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", token);
    }
    private async Task<HttpResponseMessage> PostInternalInventoryAsync(HttpClient client, string action, int drugId, int quantity)
    {
        using var request = new HttpRequestMessage(HttpMethod.Post, $"/api/inventory/{action}") { Content = JsonContent.Create(new { drugId, quantity }) };
        request.Headers.Add("X-Internal-Key", config["Internal:ServiceKey"] ?? "");
        return await client.SendAsync(request);
    }
    private bool IsInternalRequest() => !string.IsNullOrWhiteSpace(config["Internal:ServiceKey"]) && Request.Headers["X-Internal-Key"] == config["Internal:ServiceKey"];
    private Task TrySendEmailAsync(int userId, string subject, string body) => TryNotifyAsync(userId, subject, body);

    private async Task TryNotifyAsync(int userId, string subject, string body)
    {
        try
        {
            var auth = clients.CreateClient("Auth");
            ForwardUserToken(auth);
            var userResponse = await auth.GetAsync($"/api/users/{userId}");
            if (!userResponse.IsSuccessStatusCode) return;
            var user = await userResponse.Content.ReadFromJsonAsync<AuthUserDto>();
            if (user is null || string.IsNullOrWhiteSpace(user.Email)) return;
            await clients.CreateClient("Notify").PostAsJsonAsync("/api/notifications/email", new { to = user.Email, subject, body });
        }
        catch { /* Notification is best-effort; order processing must remain available. */ }
    }
}
