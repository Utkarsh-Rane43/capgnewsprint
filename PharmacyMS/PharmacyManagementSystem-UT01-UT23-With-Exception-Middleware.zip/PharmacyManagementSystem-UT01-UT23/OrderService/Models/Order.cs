namespace Pharmacy.Orders;

public class Order { public int OrderId{get;set;} public int UserId{get;set;} public DateTime OrderDate{get;set;}=DateTime.UtcNow; public decimal TotalAmount{get;set;} public string OrderStatus{get;set;}="PendingVerification"; public List<OrderItem> Items{get;set;}=[]; }
