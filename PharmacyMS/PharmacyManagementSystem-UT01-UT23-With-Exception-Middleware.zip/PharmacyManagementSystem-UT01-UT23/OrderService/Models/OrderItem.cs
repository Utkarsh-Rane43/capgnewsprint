namespace Pharmacy.Orders;

public class OrderItem { public int OrderItemId{get;set;} public int OrderId{get;set;} public int DrugId{get;set;} public int Quantity{get;set;} public decimal UnitPrice{get;set;} public decimal SubTotal{get;set;} }
