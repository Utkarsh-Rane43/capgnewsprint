namespace Pharmacy.Orders;

/// <summary>Centralises the order-state rules used by admin and payment workflows.</summary>
public sealed class OrderWorkflowService : IOrderWorkflowService
{
    public bool CanVerify(Order order) => order.OrderStatus == "PendingVerification";
    public bool CanReject(Order order) => order.OrderStatus == "PendingVerification";
    public bool CanCancel(Order order) => order.OrderStatus is "PendingVerification" or "Verified" or "Paid";
    public bool WasPaid(Order order) => order.OrderStatus == "Paid";
    public bool CanMarkPaid(Order order) => order.OrderStatus == "Verified";
    public bool CanFinalizePickup(Order order) => order.OrderStatus == "Paid";
}
