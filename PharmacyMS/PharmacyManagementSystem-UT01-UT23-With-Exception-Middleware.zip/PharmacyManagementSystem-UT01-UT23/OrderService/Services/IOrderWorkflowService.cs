namespace Pharmacy.Orders;

public interface IOrderWorkflowService
{
    bool CanVerify(Order order);
    bool CanReject(Order order);
    bool CanCancel(Order order);
    bool WasPaid(Order order);
    bool CanMarkPaid(Order order);
    bool CanFinalizePickup(Order order);
}
