using Microsoft.EntityFrameworkCore;

namespace Pharmacy.Inventory;

/// <summary>Owns the available/reserved quantity rules for internal stock operations.</summary>
public sealed class StockReservationService(IInventoryRepository repository) : IStockReservationService
{
    public async Task<StockReservationResult> ChangeAsync(StockRequest request, string action)
    {
        if (request.Quantity <= 0)
            return new(false, 400, "Quantity must be positive.", null);

        var stock = await repository.Query<Stock>().SingleOrDefaultAsync(x => x.DrugId == request.DrugId);
        if (stock is null)
            return new(false, 404, "Stock record was not found.", null);

        if (action == "reserve")
        {
            if (stock.AvailableQuantity < request.Quantity)
                return new(false, 409, "Insufficient stock.", null);

            stock.AvailableQuantity -= request.Quantity;
            stock.ReservedQuantity += request.Quantity;
        }
        else if (action is "release" or "finalize")
        {
            if (stock.ReservedQuantity < request.Quantity)
                return new(false, 409, "Reserved quantity is insufficient.", null);

            stock.ReservedQuantity -= request.Quantity;
            if (action == "release") stock.AvailableQuantity += request.Quantity;
        }
        else
        {
            return new(false, 400, "Unsupported stock operation.", null);
        }

        await repository.SaveChangesAsync();
        return new(true, 200, null, stock);
    }
}
