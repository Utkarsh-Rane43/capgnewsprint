namespace Pharmacy.Inventory;

public interface IStockReservationService
{
    Task<StockReservationResult> ChangeAsync(StockRequest request, string action);
}

public sealed record StockReservationResult(bool Success, int StatusCode, string? Message, Stock? Stock);
