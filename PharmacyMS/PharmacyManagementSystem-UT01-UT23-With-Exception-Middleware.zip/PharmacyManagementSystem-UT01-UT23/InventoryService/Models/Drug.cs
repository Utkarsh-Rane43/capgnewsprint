namespace Pharmacy.Inventory;

public class Drug { public int DrugId {get;set;} public string DrugName {get;set;}=""; public string Manufacturer {get;set;}=""; public decimal Price {get;set;} public DateTime ExpiryDate {get;set;} public int SupplierId {get;set;} }
