namespace Pharmacy.Inventory;

public class Stock { public int InventoryId {get;set;} public int DrugId {get;set;} public int AvailableQuantity {get;set;} public int ReservedQuantity {get;set;} }
