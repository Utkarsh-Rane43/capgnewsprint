using Microsoft.EntityFrameworkCore;
namespace Pharmacy.Inventory;
public class InventoryDb(DbContextOptions<InventoryDb> options) : DbContext(options)
{
    public DbSet<Drug> Drugs => Set<Drug>();
    public DbSet<Supplier> Suppliers => Set<Supplier>();
    public DbSet<Stock> Inventory => Set<Stock>();
    protected override void OnModelCreating(ModelBuilder b)
    {
        var d=b.Entity<Drug>(); d.ToTable("Drugs"); d.HasKey(x=>x.DrugId);
        d.Property(x=>x.DrugName).HasMaxLength(100).IsRequired(); d.Property(x=>x.Manufacturer).HasMaxLength(100).IsRequired();
        d.Property(x=>x.Price).HasPrecision(10,2); d.Property(x=>x.ExpiryDate).HasColumnType("date");
        var s=b.Entity<Supplier>(); s.ToTable("Suppliers"); s.HasKey(x=>x.SupplierId);
        s.Property(x=>x.SupplierName).HasMaxLength(100).IsRequired(); s.Property(x=>x.Email).HasMaxLength(150); s.Property(x=>x.Phone).HasMaxLength(20); s.Property(x=>x.Address).HasMaxLength(255);
        var i=b.Entity<Stock>(); i.ToTable("Inventory"); i.HasKey(x=>x.InventoryId); i.HasIndex(x=>x.DrugId).IsUnique();
        d.HasOne<Supplier>().WithMany().HasForeignKey(x=>x.SupplierId).OnDelete(DeleteBehavior.Restrict);
        i.HasOne<Drug>().WithMany().HasForeignKey(x=>x.DrugId).OnDelete(DeleteBehavior.Restrict);
    }
}
