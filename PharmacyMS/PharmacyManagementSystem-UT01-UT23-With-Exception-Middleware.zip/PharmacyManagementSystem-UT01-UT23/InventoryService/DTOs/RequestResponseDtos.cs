namespace Pharmacy.Inventory;

public record DrugRequest(string DrugName,string Manufacturer,decimal Price,DateTime ExpiryDate,int SupplierId,int InitialQuantity=0);
public record SupplierRequest(string SupplierName,string? Email,string? Phone,string? Address);
public record StockRequest(int DrugId,int Quantity);
public record QuantityRequest(int Quantity);
public record ProcessedStockDto(int DrugId, int ProcessedQuantity);
