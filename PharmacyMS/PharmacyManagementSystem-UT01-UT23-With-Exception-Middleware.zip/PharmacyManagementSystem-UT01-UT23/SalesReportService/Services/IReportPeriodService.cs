namespace Pharmacy.Reports;

public interface IReportPeriodService
{
    (DateTime Start, DateTime EndInclusive) ForMonth(int year, int month);
    (DateTime Start, DateTime EndInclusive) ForYear(int year);
}
