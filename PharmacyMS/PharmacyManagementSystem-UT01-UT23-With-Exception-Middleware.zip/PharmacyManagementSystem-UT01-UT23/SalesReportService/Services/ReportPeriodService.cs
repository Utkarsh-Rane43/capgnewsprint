namespace Pharmacy.Reports;

/// <summary>Provides calendar date boundaries shared by monthly and annual report queries.</summary>
public sealed class ReportPeriodService : IReportPeriodService
{
    public (DateTime Start, DateTime EndInclusive) ForMonth(int year, int month)
    {
        var start = new DateTime(year, month, 1);
        return (start, start.AddMonths(1).AddDays(-1));
    }

    public (DateTime Start, DateTime EndInclusive) ForYear(int year)
        => (new DateTime(year, 1, 1), new DateTime(year, 12, 31));
}
