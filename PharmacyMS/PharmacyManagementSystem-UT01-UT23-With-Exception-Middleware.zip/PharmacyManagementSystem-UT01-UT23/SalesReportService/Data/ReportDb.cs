using Microsoft.EntityFrameworkCore;
namespace Pharmacy.Reports;
public class ReportDb(DbContextOptions<ReportDb> options) : DbContext(options)
{
 public DbSet<SalesReport> SalesReports=>Set<SalesReport>();
 protected override void OnModelCreating(ModelBuilder b){var e=b.Entity<SalesReport>(); e.ToTable("SalesReports"); e.HasKey(x=>x.ReportId); e.Property(x=>x.ReportDate).HasColumnType("date"); e.Property(x=>x.TotalSales).HasPrecision(10,2); }
}
