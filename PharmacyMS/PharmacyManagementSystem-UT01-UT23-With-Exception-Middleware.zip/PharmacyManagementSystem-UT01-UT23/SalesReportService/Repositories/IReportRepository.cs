namespace Pharmacy.Reports;

/// <summary>Service-owned data access contract. Query keeps EF Core LINQ composable inside this service.</summary>
public interface IReportRepository
{
    IQueryable<T> Query<T>() where T : class;
    void Add<T>(T entity) where T : class;
    void Remove<T>(T entity) where T : class;
    Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
}
