namespace Pharmacy.Reports;

public class SalesReport { public int ReportId{get;set;} public DateTime ReportDate{get;set;} public int TotalOrders{get;set;} public decimal TotalSales{get;set;} }
