namespace Pharmacy.Reports;

public record ReportIngest(DateTime ReportDate, int TotalOrders, decimal TotalSales);
public record SalesSummaryDto(int TotalOrders, decimal TotalSales);
