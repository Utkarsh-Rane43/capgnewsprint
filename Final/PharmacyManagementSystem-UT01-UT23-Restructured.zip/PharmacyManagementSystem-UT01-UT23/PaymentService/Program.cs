using Pharmacy.Payments.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using Pharmacy.Payments;

var b = WebApplication.CreateBuilder(args);
b.Services.AddControllers(); b.Services.AddEndpointsApiExplorer();
b.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo
    {
        Title = "Pharmacy Payment Service",
        Version = "v1"
    });
    options.AddSecurityDefinition("Bearer", new Microsoft.OpenApi.Models.OpenApiSecurityScheme
    {
        Name = "Authorization",
        Type = Microsoft.OpenApi.Models.SecuritySchemeType.Http,
        Scheme = "bearer",
        BearerFormat = "JWT",
        In = Microsoft.OpenApi.Models.ParameterLocation.Header,
        Description = "Paste the JWT access token. Swagger sends it as Authorization: Bearer <token>."
    });
    options.AddSecurityRequirement(new Microsoft.OpenApi.Models.OpenApiSecurityRequirement
    {
        {
            new Microsoft.OpenApi.Models.OpenApiSecurityScheme
            {
                Reference = new Microsoft.OpenApi.Models.OpenApiReference
                {
                    Type = Microsoft.OpenApi.Models.ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            Array.Empty<string>()
        }
    });
});
b.Services.AddDbContext<PaymentDb>(options => options.UseSqlServer(
    b.Configuration.GetConnectionString("Default"),
    sql => sql.EnableRetryOnFailure(3, TimeSpan.FromSeconds(5), null)));
b.Services.AddHttpClient("Orders", c => c.BaseAddress = new Uri(b.Configuration["Services:Orders"] ?? "http://localhost:5003"));
b.Services.AddHttpClient("Auth", c => c.BaseAddress = new Uri(b.Configuration["Services:Auth"] ?? "http://localhost:5001"));
b.Services.AddHttpClient("Notify", c => c.BaseAddress = new Uri(b.Configuration["Services:Notification"] ?? "http://localhost:5006"));
b.Services.AddScoped<IPaymentRepository, PaymentRepository>();
b.Services.AddScoped<IPaymentReferenceService, PaymentReferenceService>();
var jwtKey = b.Configuration["Jwt:Key"] ?? throw new InvalidOperationException("Jwt:Key is missing.");
b.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(options => options.TokenValidationParameters = new TokenValidationParameters
{
    ValidateIssuer = true, ValidateAudience = true, ValidateLifetime = true, ValidateIssuerSigningKey = true,
    ValidIssuer = b.Configuration["Jwt:Issuer"], ValidAudience = b.Configuration["Jwt:Audience"],
    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey)),
    NameClaimType = System.Security.Claims.ClaimTypes.NameIdentifier,
    RoleClaimType = System.Security.Claims.ClaimTypes.Role
});
b.Services.AddAuthorization();
var app = b.Build();
await DatabaseInitializer.InitializeAsync<PaymentDb>(app.Services, app.Configuration);
app.UseSwagger(); app.UseSwaggerUI(); app.UseAuthentication(); app.UseAuthorization();
app.MapControllers(); app.MapGet("/health", () => Results.Ok(new { service = "PaymentService", status = "Healthy" })); app.Run();
