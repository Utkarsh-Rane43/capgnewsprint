using Pharmacy.Notify;
var b = WebApplication.CreateBuilder(args);
b.Services.AddControllers(); b.Services.AddEndpointsApiExplorer();
b.Services.AddSwaggerGen(o => o.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo { Title = "Pharmacy Notification Service", Version = "v1" }));
b.Services.AddScoped<IEmailSender, EmailSender>();
var app = b.Build();
app.UseSwagger(); app.UseSwaggerUI(); app.MapControllers();
app.MapGet("/health", () => Results.Ok(new { service = "NotificationService", status = "Healthy" }));
app.Run();
