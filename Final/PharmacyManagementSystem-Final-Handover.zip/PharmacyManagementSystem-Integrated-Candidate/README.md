# Pharmacy Management System

See **[docs/PROJECT-GUIDE.md](docs/PROJECT-GUIDE.md)** for the consolidated project handover:
architecture, service responsibilities, database diagrams and column explanations,
local setup, API routes, workflow, and UT01–UT23 acceptance test catalogue.

## Run locally
1. Install .NET 10 SDK and SQL Server LocalDB.
2. Run `Run-Local.bat`.
3. Open `http://localhost:5000/swagger`.

Run existing NUnit tests with:

```bash
dotnet test PharmacyManagementSystem.sln
```

The acceptance test catalogue contains 23 scenarios. The current automated NUnit
project has 3 password-hashing unit tests; see the guide for the distinction and
the UT23 SMTP response-code mismatch that needs resolution.
