const $ = (selector) => document.querySelector(selector);
let token = localStorage.getItem('pharmaToken') || '';
let me = JSON.parse(localStorage.getItem('pharmaUser') || 'null');
let tab = '';
let catalogCache = new Map();
let quantitySelection = null;

const api = async (path, options = {}) => {
    const headers = { ...(options.headers || {}) };
    if (token) headers.Authorization = `Bearer ${token}`;
    if (options.body) headers['Content-Type'] = 'application/json';
    const response = await fetch(path, { ...options, headers });
    const text = await response.text();
    let data;
    try { data = text ? JSON.parse(text) : null; } catch { data = text; }
    if (!response.ok) throw new Error(data?.message || data?.title || `Request failed (${response.status})`);
    return data;
};

const esc = (value) => String(value ?? '').replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
}[c]));
const money = value => `₹${Number(value || 0).toFixed(2)}`;
const cartKey = () => `pharmaCart_${me?.userId || 'guest'}`;
const getCart = () => JSON.parse(localStorage.getItem(cartKey()) || '[]');
const saveCart = items => localStorage.setItem(cartKey(), JSON.stringify(items));

function msg(text, error = false, where = '#appMessage') {
    const element = $(where);
    if (!element) return;
    element.textContent = text || '';
    element.classList.toggle('error', !!error);
}
function authMode(mode) {
    $('#loginForm').classList.toggle('hidden', mode !== 'login');
    $('#registerForm').classList.toggle('hidden', mode !== 'register');
    document.querySelectorAll('.tab').forEach(x => x.classList.toggle('active', x.dataset.auth === mode));
    msg('', false, '#authMessage');
}
document.querySelectorAll('.tab').forEach(x => x.onclick = () => authMode(x.dataset.auth));
$('#regRole').onchange = e => $('#adminCodeWrap').classList.toggle('hidden', e.target.value !== 'Admin');

$('#loginForm').onsubmit = async e => {
    e.preventDefault();
    const form = new FormData(e.target);
    try {
        const result = await api('/api/auth/login', { method: 'POST', body: JSON.stringify(Object.fromEntries(form)) });
        const user = result.data;
        token = user.token;
        me = { userId: user.userId, email: user.email, role: user.role };
        localStorage.setItem('pharmaToken', token);
        localStorage.setItem('pharmaUser', JSON.stringify(me));
        showApp();
    } catch (error) { msg(error.message, true, '#authMessage'); }
};
$('#registerForm').onsubmit = async e => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.target));
    try {
        await api('/api/auth/register', { method: 'POST', body: JSON.stringify(data) });
        msg('Account created. Please sign in.', false, '#authMessage');
        authMode('login');
        $('#loginForm [name=email]').value = data.email;
    } catch (error) { msg(error.message, true, '#authMessage'); }
};

function logout() {
    token = ''; me = null;
    localStorage.removeItem('pharmaToken');
    localStorage.removeItem('pharmaUser');
    $('#auth').classList.remove('hidden');
    $('#app').classList.add('hidden');
    $('#userbar').classList.add('hidden');
}
window.logout = logout;

function showApp() {
    if (!token || !me) return;
    $('#auth').classList.add('hidden');
    $('#app').classList.remove('hidden');
    $('#userbar').classList.remove('hidden');
    $('#who').textContent = `${me.email} · ${me.role}`;
    $('#roleLabel').textContent = `${me.role.toUpperCase()} WORKSPACE`;
    $('#welcomeTitle').textContent = me.role === 'Admin' ? 'Pharmacy overview' : 'Medicine store';
    $('#welcomeText').textContent = me.role === 'Admin'
        ? 'Manage suppliers, medicines, stock, orders, invoices and reports.'
        : 'Browse medicines, manage your cart, place orders and view invoices.';

    const items = me.role === 'Admin'
        ? ['Overview', 'Suppliers', 'Medicines', 'Inventory', 'Purchase Planning', 'Orders', 'Invoices', 'Reports', 'Users']
        : ['Medicines', 'Cart', 'My Orders', 'Invoices'];
    $('#nav').innerHTML = items.map((name, index) =>
        `<button class="${index === 0 ? 'active' : ''}" data-tab="${name}">${name}${name === 'Cart' && getCart().length ? ` (${getCart().length})` : ''}</button>`
    ).join('');
    $('#nav').querySelectorAll('button').forEach(button => button.onclick = () => {
        document.querySelectorAll('#nav button').forEach(x => x.classList.toggle('active', x === button));
        render(button.dataset.tab);
    });
    render(items[0]);
}

function table(headers, rows) {
    if (!rows?.length) return '<div class="empty">No records found yet.</div>';
    return `<div class="table-wrap"><table><thead><tr>${headers.map(x => `<th>${x}</th>`).join('')}</tr></thead><tbody>${rows.map(row =>
        `<tr>${row.map(value => `<td>${value ?? ''}</td>`).join('')}</tr>`
    ).join('')}</tbody></table></div>`;
}
function form(title, fields, label = 'Save') {
    return `<div class="card form-card"><h3>${title}</h3><form id="workForm"><div class="form-grid">${fields.map(field => `
        <label class="${field.wide ? 'wide' : ''}">${field.label}
        ${field.type === 'select'
            ? `<select name="${field.name}" ${field.required ? 'required' : ''}>${field.options.map(option => `<option value="${option.value}">${esc(option.label)}</option>`).join('')}</select>`
            : `<input name="${field.name}" type="${field.type || 'text'}" ${field.required ? 'required' : ''} ${field.step ? `step="${field.step}"` : ''} ${field.min !== undefined ? `min="${field.min}"` : ''} placeholder="${field.placeholder || ''}">`}
        </label>`).join('')}</div><button class="primary">${label}</button></form></div>`;
}

async function render(view) {
    tab = view;
    msg('');
    const content = $('#content');
    content.innerHTML = '<div class="empty">Loading…</div>';
    try {
        if (view === 'Overview') {
            const [suppliers, drugs, orders, stock] = await Promise.all([
                api('/api/suppliers'), api('/api/drugs'), api('/api/orders'), api('/api/inventory')
            ]);
            const paid = orders.filter(x => ['Paid', 'PickedUp'].includes(x.orderStatus));
            const pending = orders.filter(x => x.orderStatus === 'PendingVerification');
            const todayKey = new Date().toISOString().slice(0, 10);
            const todayOrders = orders.filter(x => String(x.orderDate || '').slice(0, 10) === todayKey);
            const lowStock = stock.filter(x => Number(x.availableQuantity || 0) <= 10);
            const expiringSoon = drugs.filter(x => {
                const days = (new Date(x.expiryDate) - new Date()) / 86400000;
                return Number.isFinite(days) && days >= 0 && days <= 30;
            });
            const recent = [...orders].sort((a,b) => new Date(b.orderDate) - new Date(a.orderDate)).slice(0, 5);
            const statusClass = value => String(value || '').toLowerCase().replace(/[^a-z]/g, '-');
            content.innerHTML = `
                <div class="dashboard-intro">
                    <div><span class="eyebrow">PHARMACY OPERATIONS</span><h2>Good ${new Date().getHours() < 12 ? 'morning' : new Date().getHours() < 17 ? 'afternoon' : 'evening'}, ${esc(me.email.split('@')[0])}</h2><p>Here’s the latest snapshot of your pharmacy operations.</p></div>
                    <div class="today-chip"><span class="pulse-dot"></span> Live workspace <span>·</span> ${new Date().toLocaleDateString(undefined,{weekday:'short',day:'numeric',month:'short'})}</div>
                </div>
                <div class="grid dashboard-metrics">
                    <div class="card metric-card"><div class="metric-top"><span class="metric-icon">♧</span><span class="metric-caption">SUPPLIERS</span></div><div class="metric">${suppliers.length}</div><small>Registered partners</small></div>
                    <div class="card metric-card"><div class="metric-top"><span class="metric-icon">✚</span><span class="metric-caption">MEDICINES</span></div><div class="metric">${drugs.length}</div><small>Catalogue items</small></div>
                    <div class="card metric-card"><div class="metric-top"><span class="metric-icon">▤</span><span class="metric-caption">TODAY'S ORDERS</span></div><div class="metric">${todayOrders.length}</div><small>${orders.length} orders overall</small></div>
                    <div class="card metric-card"><div class="metric-top"><span class="metric-icon">✓</span><span class="metric-caption">COMPLETED PAYMENTS</span></div><div class="metric">${paid.length}</div><small>Paid or picked up</small></div>
                </div>
                <div class="dashboard-columns">
                    <section class="card dashboard-panel"><div class="section-heading"><div><span class="eyebrow">ACTION REQUIRED</span><h3>Stock & attention</h3></div><span class="soft-count">${lowStock.length + expiringSoon.length} alerts</span></div>
                        <div class="attention-row"><span class="attention-icon warning">!</span><div><b>Low stock</b><small>${lowStock.length ? `${lowStock.length} medicine(s) at or below 10 available units` : 'No low-stock medicines right now'}</small></div><button class="text-action" onclick="document.querySelector('[data-tab=Inventory]').click()">Review</button></div>
                        <div class="attention-row"><span class="attention-icon expiry">◷</span><div><b>Expiring soon</b><small>${expiringSoon.length ? `${expiringSoon.length} medicine(s) expire within 30 days` : 'No medicines expiring in the next 30 days'}</small></div><button class="text-action" onclick="document.querySelector('[data-tab=Medicines]').click()">Review</button></div>
                        <div class="attention-row"><span class="attention-icon pending">↗</span><div><b>Pending verification</b><small>${pending.length} order(s) waiting for admin review</small></div><button class="text-action" onclick="document.querySelector('[data-tab=Orders]').click()">Open</button></div>
                    </section>
                    <section class="card dashboard-panel"><div class="section-heading"><div><span class="eyebrow">RECENT ACTIVITY</span><h3>Latest orders</h3></div><button class="text-action" onclick="document.querySelector('[data-tab=Orders]').click()">View all</button></div>
                        ${recent.length ? `<div class="activity-list">${recent.map(order => `<div class="activity-item"><div class="activity-avatar">#${esc(order.orderId)}</div><div class="activity-copy"><b>Order #${esc(order.orderId)}</b><small>${esc(String(order.orderDate || '').replace('T',' ').slice(0,16))} · ${money(order.totalAmount)}</small></div><span class="status-pill ${statusClass(order.orderStatus)}">${esc(order.orderStatus)}</span></div>`).join('')}</div>` : '<div class="empty compact-empty">No orders yet. New orders will appear here.</div>'}
                    </section>
                </div>
                <div class="card workflow-strip"><div><span class="eyebrow">HOW IT FLOWS</span><h3>From prescription request to pickup</h3><p>Keep each order moving through the same clear, auditable process.</p></div><div class="workflow-steps"><span><i>1</i> Order placed</span><b>→</b><span><i>2</i> Admin verifies</span><b>→</b><span><i>3</i> Payment</span><b>→</b><span><i>4</i> Pickup</span></div></div>`;
        }
        else if (view === 'Suppliers') {
            const suppliers = await api('/api/suppliers');
            content.innerHTML = form('Add supplier', [
                { name: 'supplierName', label: 'Supplier name', required: true },
                { name: 'email', label: 'Email', type: 'email' },
                { name: 'phone', label: 'Phone' },
                { name: 'address', label: 'Address', wide: true }
            ]) + `<h3>Registered suppliers</h3>${table(['ID', 'Name', 'Email', 'Phone', 'Address'], suppliers.map(x =>
                [x.supplierId, esc(x.supplierName), esc(x.email), esc(x.phone), esc(x.address)]))}`;
            wireForm('supplier');
        }
        else if (view === 'Medicines') {
            const [drugs, suppliers, stock] = await Promise.all([api('/api/drugs'), api('/api/suppliers'), api('/api/inventory')]);
            catalogCache = new Map(drugs.map(drug => [drug.drugId, { ...drug, availableQuantity: stock.find(row => row.drugId === drug.drugId)?.availableQuantity ?? 0 }]));
            const stockByDrug = new Map(stock.map(x => [x.drugId, x]));
            const addForm = me.role === 'Admin' ? form('Add medicine', [
                { name: 'drugName', label: 'Medicine name', required: true },
                { name: 'manufacturer', label: 'Manufacturer', required: true },
                { name: 'price', label: 'Price (₹)', type: 'number', step: '0.01', min: 0.01, required: true },
                { name: 'expiryDate', label: 'Expiry date', type: 'date', required: true },
                { name: 'supplierId', label: 'Supplier', type: 'select', required: true, options: suppliers.map(x => ({ value: x.supplierId, label: `${x.supplierName} (#${x.supplierId})` })) },
                { name: 'initialQuantity', label: 'Opening stock', type: 'number', min: 0, required: true }
            ]) : '';
            content.innerHTML = addForm + `<h3>Medicine catalogue</h3>${table(
                ['ID', 'Medicine', 'Manufacturer', 'Price', 'Expiry', 'Available', 'Actions'],
                drugs.map(x => {
                    const stockRow = stockByDrug.get(x.drugId);
                    const actions = me.role === 'Doctor'
                        ? `<button class="action" onclick="addToCart(${x.drugId})">Add to Cart</button><button class="action" onclick="orderNow(${x.drugId})">Order Now</button>`
                        : '';
                    return [x.drugId, esc(x.drugName), esc(x.manufacturer), money(x.price), esc(x.expiryDate).slice(0, 10), stockRow?.availableQuantity ?? 0, actions];
                })
            )}`;
            if (me.role === 'Admin') wireForm('drug');
        }
        else if (view === 'Inventory') {
            const [rows, drugs] = await Promise.all([api('/api/inventory'), api('/api/drugs')]);
            const drugMap = new Map(drugs.map(x => [x.drugId, x]));
            const today = new Date(); today.setHours(0,0,0,0);
            const expired = drugs.filter(x => new Date(x.expiryDate) < today);
            const expiring = drugs.filter(x => { const days=(new Date(x.expiryDate)-today)/86400000; return days>=0 && days<=60; });
            const low = rows.filter(x => Number(x.availableQuantity) <= 10);
            content.innerHTML = `<div class="dashboard-intro"><div><span class="eyebrow">INVENTORY CONTROL</span><h2>Stock & expiry monitoring</h2><p>Monitor the current stock balances and medicine-level expiry dates.</p></div></div>
                <div class="grid dashboard-metrics">
                  <div class="card metric-card"><span class="metric-caption">LOW STOCK</span><div class="metric">${low.length}</div><small>10 or fewer available units</small></div>
                  <div class="card metric-card"><span class="metric-caption">EXPIRING IN 60 DAYS</span><div class="metric">${expiring.length}</div><small>Based on medicine expiry date</small></div>
                  <div class="card metric-card"><span class="metric-caption">EXPIRED</span><div class="metric">${expired.length}</div><small>Review before dispensing</small></div>
                  <div class="card metric-card"><span class="metric-caption">MEDICINES TRACKED</span><div class="metric">${drugs.length}</div><small>Current catalogue</small></div>
                </div>
                <div class="card dashboard-panel"><h3>Update available stock</h3><p class="muted">This updates the existing Inventory.AvailableQuantity value. It does not create a stock ledger or retain historical adjustment records.</p>
                  <form id="stockAdjustForm" class="form-grid">
                    <label>Medicine<select name="drugId" required>${drugs.map(d=>`<option value="${d.drugId}">${esc(d.drugName)} (#${d.drugId})</option>`).join('')}</select></label>
                    <label>New available quantity<input name="quantity" type="number" min="0" step="1" required placeholder="Enter total available units"></label>
                    <div class="wide"><button class="primary">Save stock balance</button></div>
                  </form>
                </div>
                <h3>Current stock position</h3><p class="muted">Processed quantity is calculated from paid/picked-up orders; it is not an additional database column.</p>${table(
                ['Drug ID', 'Medicine', 'Available', 'Reserved', 'Processed (paid)', 'Reorder alert', 'Expiry'],
                rows.map(x => {const d=drugMap.get(x.drugId); const days=d?(new Date(d.expiryDate)-today)/86400000:9999;
                    return [x.drugId,esc(x.drugName),x.availableQuantity,x.reservedQuantity,x.processedQuantity??0,
                    Number(x.availableQuantity)<=10?'<span class="status-pill pendingverification">Reorder</span>':'<span class="status-pill paid">Healthy</span>',
                    d? (days<0?'<span class="status-pill rejected">Expired</span>':days<=60?'<span class="status-pill pendingverification">Expiring soon</span>':esc(String(d.expiryDate).slice(0,10))):'—'];})
            )}`;
            $('#stockAdjustForm').onsubmit = async e => {
                e.preventDefault(); const data=Object.fromEntries(new FormData(e.target));
                try { await api(`/api/inventory/${Number(data.drugId)}`,{method:'PUT',body:JSON.stringify({quantity:Number(data.quantity)})});
                    msg('Available stock balance updated. No historical adjustment log is stored in the approved schema.');
                    render('Inventory');
                } catch(err) { msg(err.message,true); }
            };
        }
        else if (view === 'Purchase Planning') {
            const [suppliers,drugs,stock]=await Promise.all([api('/api/suppliers'),api('/api/drugs'),api('/api/inventory')]);
            const supplierMap=new Map(suppliers.map(x=>[x.supplierId,x]));
            const suggested=stock.filter(x=>Number(x.availableQuantity)<=10).map(x=>({...x,drug:drugs.find(d=>d.drugId===x.drugId)}));
            content.innerHTML=`<div class="dashboard-intro"><div><span class="eyebrow">PROCUREMENT WORKSPACE</span><h2>Purchase planning</h2><p>Prepare supplier-wise replenishment drafts from current stock levels.</p></div><div class="today-chip">Suggested reorder threshold · 10 units</div></div>
              <div class="card dashboard-panel"><div class="section-heading"><div><h3>Replenishment suggestions</h3><small class="muted">Draft only — not saved as purchase orders.</small></div><button class="primary" onclick="printPurchasePlan()">Print purchase plan</button></div>
              ${suggested.length?table(['Supplier','Medicine','Available','Suggested quantity','Supplier contact'],suggested.map(x=>{const sup=supplierMap.get(x.drug?.supplierId); const qty=Math.max(20,30-Number(x.availableQuantity||0)); return [esc(sup?.supplierName||'Supplier not found'),esc(x.drug?.drugName||x.drugName),x.availableQuantity,`<input class="purchase-qty" data-drug="${x.drugId}" type="number" min="1" value="${qty}" style="width:90px">`,esc(sup?.email||'—')];}))
              :'<div class="empty">No medicines currently meet the reorder threshold.</div>'}
              <p class="muted">This screen creates a printable planning sheet only. The approved database has no purchase-order table, so drafts cannot be persisted, received, or tracked as formal purchase orders.</p></div>`;
            window.currentPurchasePlan=suggested.map(x=>({drugId:x.drugId,drugName:x.drug?.drugName||x.drugName,supplierName:supplierMap.get(x.drug?.supplierId)?.supplierName||'Supplier',available:x.availableQuantity,suggested:Math.max(20,30-Number(x.availableQuantity||0))}));
        }
        else if (view === 'Cart') {
            await renderCart(content);
        }
        else if (view === 'Orders' || view === 'My Orders') {
            const orders = await api(me.role === 'Doctor' ? '/api/orders/my-orders' : '/api/orders');
            content.innerHTML = `<h3>${me.role === 'Doctor' ? 'Your orders' : 'All pharmacy orders'}</h3>${table(
                ['Order', 'Date', 'User ID', 'Total', 'Status', 'Items / Actions'],
                orders.map(order => {
                    const itemText = (order.items || []).map(item => `Drug ${item.drugId} × ${item.quantity}`).join(', ');
                    let actions = '';
                    if (me.role === 'Admin' && order.orderStatus === 'PendingVerification')
                        actions += `<button class="action" onclick="orderAction(${order.orderId},'verify')">Verify</button><button class="action" onclick="orderAction(${order.orderId},'reject')">Reject</button>`;
                    if (me.role === 'Doctor' && order.orderStatus === 'Verified') actions += `<button class="action" onclick="pay(${order.orderId})">Pay</button>`;
                    if (me.role === 'Doctor' && ['PendingVerification', 'Verified', 'Paid'].includes(order.orderStatus)) actions += `<button class="action" onclick="cancelOrder(${order.orderId}, '${order.orderStatus}')">Cancel order</button>`;
                    if (me.role === 'Admin' && order.orderStatus === 'Paid') actions += `<button class="action" onclick="pickup(${order.orderId})">Finalize pickup</button>`;
                    if (['Paid', 'PickedUp'].includes(order.orderStatus)) actions += `<button class="action" onclick="invoice(${order.orderId})">Invoice PDF</button>`;
                    return [order.orderId, esc(order.orderDate).replace('T', ' ').slice(0, 16), order.userId, money(order.totalAmount), esc(order.orderStatus), `${esc(itemText)}<br>${actions}`];
                })
            )}`;
        }
        else if (view === 'Invoices') {
            const orders = await api(me.role === 'Doctor' ? '/api/orders/my-orders' : '/api/orders');
            const paidOrders = orders.filter(x => ['Paid', 'PickedUp'].includes(x.orderStatus));
            content.innerHTML = `<h3>${me.role === 'Admin' ? 'Pharmacy invoices' : 'Your invoices'}</h3><p class="muted">Invoices become available after a successful payment.</p>${table(
                ['Invoice', 'Order date', 'Order ID', 'Total', 'Order status', 'Download'],
                paidOrders.map(x => [`INV-${String(x.orderId).padStart(5, '0')}`, esc(x.orderDate).replace('T', ' ').slice(0, 16), x.orderId, money(x.totalAmount), esc(x.orderStatus), `<button class="action" onclick="invoice(${x.orderId})">Download PDF</button>`])
            )}`;
        }
        else if (view === 'Reports') {
            content.innerHTML = `<div class="card"><h3>Sales reports</h3><div class="form-grid">
                <label>Report period<select id="reportPeriod"><option value="daily">Daily</option><option value="monthly">Monthly</option><option value="yearly">Annual</option></select></label>
                <label id="reportDateWrap">Date<input id="reportDate" type="date" value="${new Date().toISOString().slice(0, 10)}"></label>
                <label id="reportMonthWrap" class="hidden">Month<input id="reportMonth" type="month" value="${new Date().toISOString().slice(0, 7)}"></label>
                <label id="reportYearWrap" class="hidden">Year<input id="reportYear" type="number" min="2000" max="2100" value="${new Date().getFullYear()}"></label>
            </div><button class="primary" onclick="loadReport()">Generate report</button></div><div id="reportData"></div>`;
            $('#reportPeriod').onchange = updateReportFields;
            await loadReport();
        }
        else if (view === 'Users') {
            const users = await api('/api/users');
            content.innerHTML = `<h3>Registered users</h3><p class="muted">Deactivate Doctor accounts to prevent future sign-ins. Existing access tokens may remain valid until they expire.</p>${table(['ID', 'Name', 'Email', 'Role', 'Active', 'Account action'], users.map(x =>
                [x.userId, esc(x.fullName), esc(x.email), esc(x.role), x.isActive ? 'Yes' : 'No',
                 x.role === 'Doctor' ? `<button class="action" onclick="setDoctorActive(${x.userId}, ${!x.isActive})">${x.isActive ? 'Deactivate' : 'Reactivate'}</button>` : '—']))}`;
        }
    } catch (error) {
        content.innerHTML = `<div class="empty">${esc(error.message)}<br><small>Check that services are running and your account has permission.</small></div>`;
    }
}

async function renderCart(content) {
    const cart = getCart();
    if (!cart.length) {
        content.innerHTML = '<div class="empty">Your cart is empty. Open Medicines and add some items.</div>';
        return;
    }
    const [drugs, stock] = await Promise.all([api('/api/drugs'), api('/api/inventory')]);
    const drugMap = new Map(drugs.map(x => [x.drugId, x]));
    const stockMap = new Map(stock.map(x => [x.drugId, x]));
    const validItems = cart.filter(x => drugMap.has(x.drugId));
    saveCart(validItems);
    const total = validItems.reduce((sum, item) => sum + (drugMap.get(item.drugId)?.price || 0) * item.quantity, 0);
    content.innerHTML = `<div class="card"><h3>Shopping cart</h3><p class="muted">Stock is reserved only when you check out and submit the order.</p>${table(
        ['Medicine', 'Unit price', 'Available now', 'Quantity', 'Subtotal', 'Action'],
        validItems.map(item => {
            const drug = drugMap.get(item.drugId), quantity = item.quantity;
            return [esc(drug.drugName), money(drug.price), stockMap.get(item.drugId)?.availableQuantity ?? 0,
                `<input aria-label="Quantity" type="number" min="1" max="999" value="${quantity}" onchange="changeCartQuantity(${item.drugId},this.value)" style="width:85px">`,
                money(drug.price * quantity), `<button class="action" onclick="removeFromCart(${item.drugId})">Remove</button>`];
        })
    )}<div class="row" style="justify-content:flex-end;margin-top:18px"><strong>Estimated total: ${money(total)}</strong><button class="primary" onclick="checkoutCart()">Proceed to checkout</button></div></div>`;
}


function printPurchasePlan() {
    const rows=window.currentPurchasePlan||[];
    if(!rows.length){alert('There are no replenishment suggestions to print.');return;}
    const quantities=Object.fromEntries([...document.querySelectorAll('.purchase-qty')].map(x=>[x.dataset.drug,Math.max(1,Number(x.value)||1)]));
    const body=rows.map(x=>`<tr><td>${esc(x.supplierName)}</td><td>${esc(x.drugName)}</td><td>${x.available}</td><td>${quantities[x.drugId]??x.suggested}</td></tr>`).join('');
    const win=window.open('','_blank','width=900,height=700');
    if(!win){alert('Please allow pop-ups to print the purchase plan.');return;}
    win.document.write(`<!doctype html><html><head><title>Pharmacy Replenishment Plan</title><style>body{font:14px Arial;padding:32px;color:#20352a}h1{color:#176b50}table{width:100%;border-collapse:collapse;margin-top:24px}th,td{padding:12px;border:1px solid #dce7df;text-align:left}th{background:#eaf4ed}small{color:#66756c}</style></head><body><h1>Pharmacy Replenishment Plan</h1><p>Prepared ${new Date().toLocaleString()}</p><small>Planning document only — not a saved purchase order or supplier commitment.</small><table><thead><tr><th>Supplier</th><th>Medicine</th><th>Available units</th><th>Suggested order units</th></tr></thead><tbody>${body}</tbody></table><script>window.onload=()=>window.print();</script></body></html>`);
    win.document.close();
}
window.printPurchasePlan=printPurchasePlan;

function wireForm(kind) {
    const formElement = $('#workForm');
    if (!formElement) return;
    formElement.onsubmit = async event => {
        event.preventDefault();
        const data = Object.fromEntries(new FormData(formElement));
        try {
            if (kind === 'supplier') {
                await api('/api/suppliers', { method: 'POST', body: JSON.stringify(data) });
            } else {
                data.price = Number(data.price);
                data.supplierId = Number(data.supplierId);
                data.initialQuantity = Number(data.initialQuantity);
                await api('/api/drugs', { method: 'POST', body: JSON.stringify(data) });
            }
            msg('Saved successfully.');
            render(tab);
        } catch (error) { msg(error.message, true); }
    };
}

window.addToCart = drugId => openQuantityDialog(drugId, 'cart');
window.orderNow = drugId => openQuantityDialog(drugId, 'order');

function openQuantityDialog(drugId, action) {
    const drug = catalogCache.get(drugId);
    if (!drug) {
        msg('Medicine details are not available. Refresh the catalogue and try again.', true);
        return;
    }

    const alreadyInCart = getCart().find(item => item.drugId === drugId)?.quantity || 0;
    const remaining = Math.max(0, Number(drug.availableQuantity) - (action === 'cart' ? alreadyInCart : 0));
    quantitySelection = { drugId, action, drug, remaining };
    $('#quantityMedicine').textContent = drug.drugName;
    $('#quantityPrice').textContent = money(drug.price);
    $('#quantityStock').textContent = `${drug.availableQuantity} units`;
    $('#quantityInput').value = '1';
    $('#quantityInput').max = Math.max(1, remaining);
    $('#quantityHint').textContent = action === 'cart' && alreadyInCart
        ? `${alreadyInCart} already in your cart · ${remaining} more available`
        : 'Choose the number of units you need.';
    $('#quantityConfirm').textContent = action === 'cart' ? 'Add to cart' : 'Continue to order';
    $('#quantityError').textContent = remaining < 1 ? 'No additional stock is available for this medicine.' : '';
    $('#quantityConfirm').disabled = remaining < 1;
    updateQuantitySubtotal();
    $('#quantityDialog').classList.remove('hidden');
    document.body.classList.add('dialog-open');
    window.setTimeout(() => $('#quantityInput').focus(), 30);
}

window.closeQuantityDialog = () => {
    $('#quantityDialog').classList.add('hidden');
    document.body.classList.remove('dialog-open');
    quantitySelection = null;
};

window.adjustQuantity = delta => {
    const input = $('#quantityInput');
    const max = Number(input.max || 999);
    input.value = String(Math.min(max, Math.max(1, Number(input.value || 1) + delta)));
    updateQuantitySubtotal();
};

function updateQuantitySubtotal() {
    if (!quantitySelection) return;
    const quantity = Number($('#quantityInput').value || 0);
    $('#quantitySubtotal').textContent = money(quantitySelection.drug.price * Math.max(0, quantity));
    const valid = Number.isInteger(quantity) && quantity >= 1 && quantity <= quantitySelection.remaining;
    $('#quantityError').textContent = valid ? '' : `Enter a whole number between 1 and ${quantitySelection.remaining}.`;
    $('#quantityConfirm').disabled = !valid;
}
$('#quantityInput').addEventListener('input', updateQuantitySubtotal);

window.confirmQuantitySelection = async () => {
    if (!quantitySelection) return;
    const { drugId, action, remaining } = quantitySelection;
    const quantity = Number($('#quantityInput').value);
    if (!Number.isInteger(quantity) || quantity < 1 || quantity > remaining) {
        updateQuantitySubtotal();
        return;
    }

    closeQuantityDialog();
    if (action === 'order') {
        await submitOrder([{ drugId, quantity }], false);
        return;
    }

    const cart = getCart();
    const existing = cart.find(item => item.drugId === drugId);
    if (existing) existing.quantity += quantity;
    else cart.push({ drugId, quantity });
    saveCart(cart);
    msg(`${quantity} × ${catalogCache.get(drugId)?.drugName || 'Medicine'} added to your cart.`);
    showCartCount();
};

window.changeCartQuantity = (drugId, value) => {
    const quantity = Number(value);
    if (!Number.isInteger(quantity) || quantity < 1) return render('Cart');
    const cart = getCart();
    const item = cart.find(x => x.drugId === drugId);
    if (item) item.quantity = quantity;
    saveCart(cart);
    render('Cart');
};
window.removeFromCart = drugId => {
    saveCart(getCart().filter(x => x.drugId !== drugId));
    showCartCount();
    render('Cart');
};
window.checkoutCart = async () => {
    const cart = getCart();
    if (!cart.length) return msg('Your cart is empty.', true);
    await submitOrder(cart, true);
};
async function submitOrder(items, clearCart = false) {
    try {
        const result = await api('/api/orders', { method: 'POST', body: JSON.stringify({ items }) });
        if (clearCart) saveCart([]);
        showCartCount();
        msg(`Order ${result.data?.orderId ?? ''} placed. It is waiting for Admin verification.`);
        render('My Orders');
    } catch (error) { msg(error.message, true); }
}
function showCartCount() {
    const button = [...document.querySelectorAll('#nav button')].find(x => x.dataset.tab === 'Cart');
    if (button) button.textContent = `Cart${getCart().length ? ` (${getCart().length})` : ''}`;
}
window.orderAction = async (id, action) => {
    try {
        await api(`/api/orders/${id}/${action}`, { method: 'PUT' });
        msg(`Order ${action === 'verify' ? 'verified' : 'rejected'} successfully.`);
        render(tab);
    } catch (error) { msg(error.message, true); }
};
window.setDoctorActive = async (id, isActive) => {
    const action = isActive ? 'reactivate' : 'deactivate';
    if (!confirm(`Are you sure you want to ${action} Doctor account ${id}?`)) return;
    try {
        await api(`/api/users/${id}/status`, { method: 'PUT', body: JSON.stringify({ isActive }) });
        msg(`Doctor account ${action}d successfully.`);
        render('Users');
    } catch (error) { msg(error.message, true); }
};
window.cancelOrder = async (id, status) => {
    const paid = status === 'Paid';
    const note = paid
        ? `Cancel paid order ${id}? The reserved stock will be released. A refund must be reviewed and processed manually to the original/source payment account; this simulated system cannot transfer funds.`
        : `Cancel order ${id}? The reserved stock will be released.`;
    if (!confirm(note)) return;
    try {
        const result = await api(`/api/orders/${id}/cancel`, { method: 'POST' });
        msg(result.message || 'Order cancelled.');
        render('My Orders');
    } catch (error) { msg(error.message, true); }
};
window.pickup = async id => {
    if (!confirm(`Finalize pickup for order ${id}? This will deduct its reserved quantity from physical stock.`)) return;
    try {
        await api(`/api/orders/${id}/finalize-pickup`, { method: 'POST' });
        msg('Pickup finalized. Stock has been processed.');
        render(tab);
    } catch (error) { msg(error.message, true); }
};
window.pay = async id => {
    if (!confirm(`Proceed with simulated payment for order ${id}?`)) return;
    try {
        const result = await api('/api/payments', { method: 'POST', body: JSON.stringify({
            orderId: id, paymentMethod: 'Simulated', idempotencyKey: crypto.randomUUID(), simulateFailure: false
        }) });
        msg(result.message || 'Payment processed.');
        render('My Orders');
    } catch (error) { msg(error.message, true); }
};
window.invoice = async id => {
    try {
        const response = await fetch(`/api/invoices/${id}`, { headers: { Authorization: `Bearer ${token}` } });
        if (!response.ok) {
            const body = await response.json().catch(() => ({}));
            throw new Error(body.message || 'Invoice unavailable.');
        }
        const blob = await response.blob();
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url; link.download = `Invoice-${id}.pdf`; link.click();
        URL.revokeObjectURL(url);
    } catch (error) { msg(error.message, true); }
};

function updateReportFields() {
    const period = $('#reportPeriod').value;
    $('#reportDateWrap').classList.toggle('hidden', period !== 'daily');
    $('#reportMonthWrap').classList.toggle('hidden', period !== 'monthly');
    $('#reportYearWrap').classList.toggle('hidden', period !== 'yearly');
}
window.loadReport = async () => {
    try {
        const period = $('#reportPeriod').value;
        let result;
        if (period === 'daily') {
            const date = $('#reportDate').value;
            const response = await api(`/api/reports/generate/daily?date=${encodeURIComponent(date)}`, { method: 'POST' });
            result = response.data;
            result.period = date;
        } else if (period === 'monthly') {
            const [year, month] = $('#reportMonth').value.split('-');
            result = await api(`/api/reports/monthly-summary?year=${year}&month=${Number(month)}`);
            result.period = `${year}-${month}`;
        } else {
            const year = $('#reportYear').value;
            result = await api(`/api/reports/yearly?year=${year}`);
            result.period = year;
        }
        $('#reportData').innerHTML = `<div class="grid">
            <div class="card"><span class="muted">Report period</span><div class="metric" style="font-size:22px">${esc(result.period)}</div></div>
            <div class="card"><span class="muted">Total orders</span><div class="metric">${result.totalOrders}</div></div>
            <div class="card"><span class="muted">Total sales</span><div class="metric">${money(result.totalSales)}</div></div>
        </div><p class="muted">Sales include orders with successful payment status. The report period is based on the order date because the approved schema does not store payment timestamps.</p>`;
    } catch (error) {
        $('#reportData').innerHTML = `<div class="empty">${esc(error.message)}</div>`;
    }
};

document.addEventListener('keydown', event => { if (event.key === 'Escape' && quantitySelection) closeQuantityDialog(); });

if (token && me) showApp();
