using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using System.Net.Http.Json;
using System.Security.Claims;
namespace Pharmacy.Payments;
[ApiController, Route("api/payments"), Authorize(Roles = "Doctor,Admin")]
public class PaymentController(PaymentDb db, IHttpClientFactory clients, IConfiguration config) : ControllerBase
{
    [HttpPost, Authorize(Roles = "Doctor")]
    public async Task<IActionResult> Pay(PaymentRequest request)
    {
        if (request.OrderId <= 0 || string.IsNullOrWhiteSpace(request.PaymentMethod) || string.IsNullOrWhiteSpace(request.IdempotencyKey)) return BadRequest(new { message = "OrderId, payment method and idempotency key are required." });
        var idempotencyKey = request.IdempotencyKey.Trim();
        // Persist idempotency through the diagram-approved TransactionReference column only.
        var transactionReference = "IDEM-" + Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(idempotencyKey))).Substring(0, 32);
        var existing = await db.Payments.SingleOrDefaultAsync(x => x.TransactionReference == transactionReference);
        if (existing is not null)
        {
            if (existing.OrderId != request.OrderId) return Conflict(new { message = "Idempotency key has already been used for a different order." });
            if (existing.PaymentStatus == "Success")
            {
                var replaySync = await SyncOrderPaymentStatusAsync(existing.OrderId, existing.PaymentStatus);
                if (!replaySync.IsSuccessStatusCode) return StatusCode(502, new { message = "Payment exists, but Order Service status reconciliation failed." });
            }
            return Ok(new { success = existing.PaymentStatus == "Success", message = "Duplicate request safely replayed", data = existing });
        }
        var orderClient = clients.CreateClient("Orders");
        var authorization = Request.Headers.Authorization.ToString();
        if (!string.IsNullOrWhiteSpace(authorization)) orderClient.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", authorization);
        var orderResponse = await orderClient.GetAsync($"/api/orders/{request.OrderId}");
        if (orderResponse.StatusCode == System.Net.HttpStatusCode.Forbidden) return Forbid();
        if (!orderResponse.IsSuccessStatusCode) return NotFound(new { message = "Order not found or inaccessible." });
        var order = await orderResponse.Content.ReadFromJsonAsync<OrderDto>();
        if (order is null || order.UserId != GetUserId()) return Forbid();
        if (order.OrderStatus != "Verified") return Conflict(new { message = "Only verified orders can be paid." });
        var paymentSucceeded = !request.SimulateFailure;
        var payment = new Payment
        {
            OrderId = request.OrderId, Amount = order.TotalAmount,
            PaymentStatus = paymentSucceeded ? "Success" : "Failed",
            TransactionReference = transactionReference
        };
        db.Payments.Add(payment);
        try { await db.SaveChangesAsync(); }
        catch (DbUpdateException)
        {
            var duplicate = await db.Payments.SingleOrDefaultAsync(x => x.TransactionReference == transactionReference);
            if (duplicate is not null) return Ok(new { success = true, message = "Duplicate request safely replayed", data = duplicate });
            throw;
        }
        var statusResponse = await SyncOrderPaymentStatusAsync(request.OrderId, payment.PaymentStatus);
        if (!statusResponse.IsSuccessStatusCode)
            return StatusCode(502, new { success = false, message = "Payment was recorded, but Order Service status update failed. Reconciliation is required.", data = payment });
        await TryNotifyAsync(order.UserId, paymentSucceeded ? $"Payment confirmed — Order #{order.OrderId}" : $"Payment not completed — Order #{order.OrderId}", paymentSucceeded
            ? $@"<!doctype html><html><body style=""font-family:Arial,sans-serif;background:#f3f6fa;padding:24px;color:#243247""><div style=""max-width:600px;margin:auto;background:#fff;border:1px solid #e4eaf1;border-radius:10px;overflow:hidden""><div style=""background:#176b50;color:#fff;padding:22px 28px""><h2 style=""margin:0"">Payment successful</h2></div><div style=""padding:26px 28px""><p>Your simulated payment has been recorded successfully.</p><p><b>Order:</b> #{order.OrderId}<br/><b>Amount:</b> ₹{order.TotalAmount:0.00}<br/><b>Transaction reference:</b> {payment.TransactionReference}<br/><b>Status:</b> Successful</p><p>Your invoice is attached in a separate email. Please retain it for your records.</p><p>Regards,<br/>Pharmacy Management Team</p></div></div></body></html>"
            : $@"<!doctype html><html><body style=""font-family:Arial,sans-serif;background:#f3f6fa;padding:24px;color:#243247""><div style=""max-width:600px;margin:auto;background:#fff;border:1px solid #e4eaf1;border-radius:10px;overflow:hidden""><div style=""background:#8a4b16;color:#fff;padding:22px 28px""><h2 style=""margin:0"">Payment was not completed</h2></div><div style=""padding:26px 28px""><p>We could not complete the simulated payment for your order.</p><p><b>Order:</b> #{order.OrderId}<br/><b>Amount:</b> ₹{order.TotalAmount:0.00}<br/><b>Reference:</b> {payment.TransactionReference}<br/><b>Status:</b> Failed</p><p>Your order remains verified. You may return to My Orders and try payment again.</p><p>Regards,<br/>Pharmacy Management Team</p></div></div></body></html>");
        if (paymentSucceeded) await TryEmailInvoiceAsync(order.UserId, order.OrderId);
        return Ok(new { success = paymentSucceeded, message = paymentSucceeded ? "Payment completed successfully (simulated)." : "Payment failed (simulated).", data = payment });
    }
    [HttpGet("{id:int}")]
    public async Task<IActionResult> Get(int id)
    {
        var payment = await db.Payments.FindAsync(id); if (payment is null) return NotFound();
        if (!await CanAccessOrderAsync(payment.OrderId)) return Forbid();
        return Ok(payment);
    }
    [HttpGet("order/{orderId:int}")]
    public async Task<IActionResult> ByOrder(int orderId)
    {
        if (!await CanAccessOrderAsync(orderId)) return Forbid();
        return Ok(await db.Payments.Where(x => x.OrderId == orderId).OrderByDescending(x => x.PaymentId).ToListAsync());
    }
    private async Task<HttpResponseMessage> SyncOrderPaymentStatusAsync(int orderId, string status)
    {
        using var update = new HttpRequestMessage(HttpMethod.Post, $"/internal/orders/{orderId}/payment-status") { Content = JsonContent.Create(new { status }) };
        update.Headers.Add("X-Internal-Key", config["Internal:ServiceKey"] ?? "");
        return await clients.CreateClient("Orders").SendAsync(update);
    }
    private async Task TryNotifyAsync(int userId, string subject, string body)
    {
        try
        {
            var auth = clients.CreateClient("Auth");
            var token = Request.Headers.Authorization.ToString();
            if (!string.IsNullOrWhiteSpace(token)) auth.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", token);
            var userResponse = await auth.GetAsync($"/api/users/{userId}");
            if (!userResponse.IsSuccessStatusCode) return;
            var user = await userResponse.Content.ReadFromJsonAsync<AuthUserDto>();
            if (user is null || string.IsNullOrWhiteSpace(user.Email)) return;
            await clients.CreateClient("Notify").PostAsJsonAsync("/api/notifications/email", new { to = user.Email, subject, body });
        }
        catch { /* Email is best-effort; payment processing must remain available. */ }
    }
    private async Task TryEmailInvoiceAsync(int userId, int orderId)
    {
        try
        {
            var auth = clients.CreateClient("Auth");
            var token = Request.Headers.Authorization.ToString();
            if (!string.IsNullOrWhiteSpace(token)) auth.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", token);
            var userResponse = await auth.GetAsync($"/api/users/{userId}");
            if (!userResponse.IsSuccessStatusCode) return;
            var user = await userResponse.Content.ReadFromJsonAsync<AuthUserDto>();
            if (user is null || string.IsNullOrWhiteSpace(user.Email)) return;

            var orderClient = clients.CreateClient("Orders");
            if (!string.IsNullOrWhiteSpace(token)) orderClient.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", token);
            var invoiceResponse = await orderClient.GetAsync($"/api/invoices/{orderId}");
            if (!invoiceResponse.IsSuccessStatusCode) return;
            var pdf = await invoiceResponse.Content.ReadAsByteArrayAsync();
            await clients.CreateClient("Notify").PostAsJsonAsync("/api/notifications/email", new
            {
                to = user.Email,
                subject = $"Invoice for pharmacy order {orderId}",
                body = $@"<!doctype html><html><body style=""font-family:Arial,sans-serif;background:#f3f6fa;padding:24px;color:#243247""><div style=""max-width:600px;margin:auto;background:#fff;border:1px solid #e4eaf1;border-radius:10px;padding:28px""><h2> Your invoice is ready</h2><p>Thank you. The payment for order #{orderId} was successful.</p><p>Your PDF invoice is attached to this email. Please keep it for your records.</p><p>Regards,<br/>Pharmacy Management Team</p></div></body></html>",
                attachmentFileName = $"Invoice-{orderId}.pdf",
                attachmentBase64 = Convert.ToBase64String(pdf)
            });
        }
        catch { /* Email delivery is best-effort; a successful payment must remain recorded. */ }
    }

    private int GetUserId() => int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier) ?? User.FindFirstValue("sub"), out var id) ? id : 0;
    private async Task<bool> CanAccessOrderAsync(int orderId)
    {
        var client = clients.CreateClient("Orders");
        var token = Request.Headers.Authorization.ToString(); if (!string.IsNullOrWhiteSpace(token)) client.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", token);
        var response = await client.GetAsync($"/api/orders/{orderId}");
        if (!response.IsSuccessStatusCode) return false;
        var order = await response.Content.ReadFromJsonAsync<OrderDto>();
        return order is not null && (User.IsInRole("Admin") || order.UserId == GetUserId());
    }
}
public record PaymentRequest(int OrderId, string PaymentMethod, string IdempotencyKey, bool SimulateFailure = false);
public record OrderDto(int OrderId, int UserId, decimal TotalAmount, string OrderStatus);
public record AuthUserDto(int UserId, string FullName, string Email, string Role, bool IsActive);
