using System.Net;

namespace Pharmacy.Orders;

internal static class EmailTemplates
{
    private static string E(string? value) => WebUtility.HtmlEncode(value ?? "");
    private static string Shell(string title, string intro, string details, string closing) => $"""
        <!doctype html><html><body style="margin:0;background:#f3f6fa;font-family:Arial,Helvetica,sans-serif;color:#243247">
        <div style="max-width:640px;margin:28px auto;background:#ffffff;border:1px solid #e4eaf1;border-radius:12px;overflow:hidden">
          <div style="background:#17365d;padding:24px 30px;color:#ffffff"><div style="font-size:12px;letter-spacing:1.5px;opacity:.85">PHARMACY MANAGEMENT SYSTEM</div><h1 style="font-size:22px;margin:10px 0 0">{E(title)}</h1></div>
          <div style="padding:28px 30px"><p style="font-size:15px;line-height:1.6;margin-top:0">{intro}</p>
            <div style="background:#f6f8fb;border:1px solid #e5ebf2;border-radius:8px;padding:16px 18px;font-size:14px;line-height:1.7">{details}</div>
            <p style="font-size:14px;line-height:1.6;margin:22px 0 0">{closing}</p>
          </div><div style="background:#f8fafc;border-top:1px solid #e8edf3;padding:16px 30px;color:#6b7788;font-size:12px;line-height:1.5">This is an automated message from the Pharmacy Management System. Please do not reply to this email.</div>
        </div></body></html>
        """;

    private static string OrderFacts(Order order) =>
        $"<b>Order number:</b> #{order.OrderId}<br><b>Order date:</b> {order.OrderDate:dd MMM yyyy, hh:mm tt}<br><b>Order total:</b> ₹{order.TotalAmount:0.00}<br><b>Items:</b> {order.Items.Sum(x => x.Quantity)}";

    public static string OrderPlaced(Order order) => Shell("We received your order",
        "Hello, your medicine order has been submitted successfully and is now waiting for review by the pharmacy Admin.",
        OrderFacts(order) + "<br><b>Current status:</b> Pending verification",
        "We will email you again when the Admin reviews your order. You can check the latest status in My Orders.");

    public static string OrderVerified(Order order) => Shell("Your order has been approved",
        "Good news — the pharmacy Admin has verified your order. You can now proceed with the simulated payment from your account.",
        OrderFacts(order) + "<br><b>Current status:</b> Verified",
        "Please sign in to the Pharmacy Management System and complete payment when you are ready.");

    public static string OrderRejected(Order order) => Shell("Update on your medicine order",
        "The pharmacy Admin has rejected your order. The reserved stock has been released back into available inventory.",
        OrderFacts(order) + "<br><b>Current status:</b> Rejected",
        "Please contact the pharmacy if you need clarification or would like to submit a new order.");

    public static string OrderPickedUp(Order order) => Shell("Pickup confirmed",
        "This is to confirm that your order has been marked as picked up by the pharmacy.",
        OrderFacts(order) + "<br><b>Current status:</b> Picked up",
        "Thank you for choosing our pharmacy. Please retain your invoice for your records.");

    public static string OrderCancelled(Order order) => Shell("Your order has been cancelled",
        "Your cancellation request was completed successfully. The reserved stock has been released back into available inventory.",
        OrderFacts(order) + "<br><b>Current status:</b> Cancelled",
        "No payment refund is applicable because this order had not been paid. If you need assistance, please contact the pharmacy.");

    public static string OrderCancelledPaid(Order order, string refundNote) => Shell("Your paid order has been cancelled",
        "Your cancellation request was completed successfully. The reserved stock has been released back into available inventory.",
        OrderFacts(order) + "<br><b>Current status:</b> Cancelled<br><br><b>Refund information:</b> " + E(refundNote),
        "Please retain this email for reference. The pharmacy team should review the payment and arrange any eligible refund to the original/source payment account. This application uses simulated payments and does not initiate an actual bank or UPI refund.");
}
