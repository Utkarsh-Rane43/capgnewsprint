# Pharmacy Management System — fresh strict-schema rebuild

This source tree uses the previous project ZIPs as references, but the persisted entities were aligned to the user's uploaded database diagram. The diagram is authoritative.

## Stack
.NET 10, ASP.NET Core Web API, EF Core/ LINQ, SQL Server LocalDB, JWT/RBAC, YARP API Gateway, Swagger, NUnit and SMTP. Six services: Auth, Inventory, Order, Payment, Sales Report and Notification.

## Database rule
Exactly five databases and eight tables. SQL script creates only empty databases. EF Core `EnsureCreated` creates tables from each service's model at first run. No SQL INSERT/UPDATE/DELETE is used by the application. See `docs/SCHEMA-AUTHORITY.md`.

## Start
1. Install .NET 10 SDK and SQL Server LocalDB.
2. Run `docs/Create-Databases.sql` once in SSMS connected to `(localdb)\MSSQLLocalDB`.
3. Run `Build-Check.ps1` in PowerShell.
4. Run `Run-Local.bat`.
5. Open Gateway Swagger at http://localhost:5000/swagger.

## Registration
Doctor and Admin use the same registration endpoint. Admin requires the invitation code configured in Auth Service settings. See `docs/ADMIN-REGISTRATION.md`.

## Testing
Follow `docs/TESTING-ORDER.md`. Swagger is the primary manual test surface. Configure SMTP in Notification Service settings; see `docs/SMTP-SETUP.md`.

## Important validation note
This environment does not contain the .NET SDK, so a local `dotnet restore/build/test` could not be run here. Run `Build-Check.ps1` on the target Windows machine before testing. This source package should be treated as a rebuild candidate until that build and the end-to-end workflow tests pass. In particular, verify invoice PDF delivery as an email attachment rather than assuming it from the invoice download endpoint.
