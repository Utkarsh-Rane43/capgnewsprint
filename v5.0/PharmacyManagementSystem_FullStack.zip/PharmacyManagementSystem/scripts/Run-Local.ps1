$ErrorActionPreference='Stop'
$projects=@('Auth','Inventory','Payment','SalesReport','Notification','Order')
foreach($s in $projects){$p=Start-Process dotnet -ArgumentList @('run','--project',"src/Services/$($s)Service/$($s)Service.csproj") -PassThru -WindowStyle Minimized;Write-Host "$s started (PID $($p.Id))"}
Start-Sleep -Seconds 3
Start-Process dotnet -ArgumentList @('run','--project','src/Gateway/Gateway.csproj') -WindowStyle Minimized
Write-Host 'Gateway: http://localhost:7000/swagger | Angular: cd frontend/pharmacy-ui; npm install; npm start'
