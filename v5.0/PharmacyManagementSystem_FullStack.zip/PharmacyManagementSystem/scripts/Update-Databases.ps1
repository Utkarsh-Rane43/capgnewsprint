$ErrorActionPreference = 'Stop'
$services = @(
  @{Name='Auth'; Context='UserDbContext'},
  @{Name='Inventory'; Context='InventoryDbContext'},
  @{Name='Order'; Context='OrderDbContext'},
  @{Name='Payment'; Context='PaymentDbContext'},
  @{Name='SalesReport'; Context='ReportDbContext'}
)
foreach ($s in $services) {
  $project = "src/Services/$($s.Name)Service/$($s.Name)Service.csproj"
  dotnet ef database update --project $project --startup-project $project --context $s.Context
}
