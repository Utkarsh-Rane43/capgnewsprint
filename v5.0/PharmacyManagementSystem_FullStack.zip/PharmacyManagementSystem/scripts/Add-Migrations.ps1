$ErrorActionPreference = 'Stop'
$services = @(
  @{Name='Auth'; Context='UserDbContext'},
  @{Name='Inventory'; Context='InventoryDbContext'},
  @{Name='Order'; Context='OrderDbContext'},
  @{Name='Payment'; Context='PaymentDbContext'},
  @{Name='SalesReport'; Context='ReportDbContext'}
)
dotnet tool restore
foreach ($s in $services) {
  $project = "src/Services/$($s.Name)Service/$($s.Name)Service.csproj"
  dotnet ef migrations add InitialCreate --project $project --startup-project $project --context $s.Context --output-dir Migrations
}
