using NUnit.Framework;using FluentAssertions;using Pharmacy.BuildingBlocks;
namespace Pharmacy.Tests;
[TestFixture] public class WorkflowTests {
[Test] public void ValidEmail_IsAccepted()=>PharmacyRules.IsValidEmail("doctor@example.com").Should().BeTrue();
[Test] public void InvalidEmail_IsRejected()=>PharmacyRules.IsValidEmail("not-an-email").Should().BeFalse();
[Test] public void PasswordOfEightCharacters_IsAccepted()=>PharmacyRules.IsValidPassword("Pharma123").Should().BeTrue();
[Test] public void ShortPassword_IsRejected()=>PharmacyRules.IsValidPassword("abc123").Should().BeFalse();
[Test] public void PositiveQuantity_IsAccepted()=>PharmacyRules.IsValidQuantity(2).Should().BeTrue();
[Test] public void ZeroQuantity_IsRejected()=>PharmacyRules.IsValidQuantity(0).Should().BeFalse();
[Test] public void NegativeQuantity_IsRejected()=>PharmacyRules.IsValidQuantity(-3).Should().BeFalse();
[Test] public void NonEmptyValidCart_IsAccepted()=>PharmacyRules.IsValidCart(new[]{new OrderLineRequest(1,2)}).Should().BeTrue();
[Test] public void EmptyCart_IsRejected()=>PharmacyRules.IsValidCart(new List<OrderLineRequest>()).Should().BeFalse();
[Test] public void CartWithInvalidLine_IsRejected()=>PharmacyRules.IsValidCart(new[]{new OrderLineRequest(1,1),new OrderLineRequest(2,0)}).Should().BeFalse();
[Test] public void AvailableStock_SubtractsReservations()=>PharmacyRules.AvailableStock(12,5).Should().Be(7);
[Test] public void InsufficientStock_IsDetected()=>PharmacyRules.HasEnoughStock(10,4,7).Should().BeFalse();
[Test] public void SufficientStock_IsAccepted()=>PharmacyRules.HasEnoughStock(10,4,6).Should().BeTrue();
[Test] public void Gst_IsCalculatedToTwoDecimals()=>PharmacyRules.CalculateGst(199.99m,5).Should().Be(10.00m);
[Test] public void OrderTotal_AddsSubtotalAndGst()=>PharmacyRules.CalculateTotal(200m,10m).Should().Be(210m);
[Test] public void PendingOrder_CanBeVerified()=>PharmacyRules.CanVerify(OrderStatus.PendingVerification).Should().BeTrue();
[Test] public void PaidOrder_CannotBeVerifiedAgain()=>PharmacyRules.CanVerify(OrderStatus.Paid).Should().BeFalse();
[Test] public void VerifiedOrder_CanBePaid()=>PharmacyRules.CanPay(OrderStatus.Verified).Should().BeTrue();
[Test] public void PendingOrder_CannotBePaid()=>PharmacyRules.CanPay(OrderStatus.PendingVerification).Should().BeFalse();
[Test] public void OnlyPaidOrder_CanBePickedUp()=>PharmacyRules.CanPickup(OrderStatus.Paid).Should().BeTrue();
[Test] public void TestCardEnding0000_SimulatesFailure()=>PharmacyRules.IsPaymentSuccessful("4242420000").Should().BeFalse();
[Test] public void OtherTestCard_SimulatesSuccess()=>PharmacyRules.IsPaymentSuccessful("4242424242424242").Should().BeTrue();
[Test] public void Invoice_IsAvailableAfterPayment()=>PharmacyRules.CanViewInvoice(OrderStatus.Completed).Should().BeTrue();
}
