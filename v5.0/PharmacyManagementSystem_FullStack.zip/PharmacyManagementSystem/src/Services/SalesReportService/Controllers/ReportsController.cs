using Microsoft.AspNetCore.Mvc;using Microsoft.AspNetCore.Authorization;using Microsoft.EntityFrameworkCore;using Pharmacy.BuildingBlocks;
namespace SalesReportService.Controllers;
[ApiController][Route("api/reports")][Authorize(Roles=Roles.Admin)]public class ReportsController(ReportDbContext db):ControllerBase{
[HttpGet("summary")]public async Task<IActionResult> Summary(){var rows=await db.SalesReports.ToListAsync();return Ok(new{Daily=rows.Where(x=>x.PeriodType=="Daily").OrderByDescending(x=>x.PeriodStart).Take(30),Monthly=rows.Where(x=>x.PeriodType=="Monthly").OrderByDescending(x=>x.PeriodStart).Take(12),Annual=rows.Where(x=>x.PeriodType=="Annual").OrderByDescending(x=>x.PeriodStart).Take(5)});}
[HttpPost("snapshot")]public async Task<IActionResult> Snapshot([FromBody]SalesReport r){if(r.Revenue<0||r.OrderCount<0)return BadRequest();r.SalesReportId=0;db.SalesReports.Add(r);await db.SaveChangesAsync();return Ok(r);}
}
