using Microsoft.AspNetCore.Mvc;using System.Net;using System.Net.Mail;
namespace NotificationService.Controllers;
public record EmailRequest(string To,string Subject,string Body);
[ApiController][Route("api/notifications")]public class NotificationsController(IConfiguration cfg,ILogger<NotificationsController> log):ControllerBase{
[HttpPost("email")]public async Task<IActionResult> Email(EmailRequest r){var host=cfg["Smtp:Host"];if(string.IsNullOrWhiteSpace(host)){log.LogInformation("SMTP not configured. Email to {To}: {Subject}",r.To,r.Subject);return Ok(new{Message="Email logged; SMTP is not configured."});}using var client=new SmtpClient(host,int.Parse(cfg["Smtp:Port"]??"587")){EnableSsl=true,Credentials=new NetworkCredential(cfg["Smtp:User"],cfg["Smtp:Password"])};using var msg=new MailMessage(cfg["Smtp:From"]!,r.To,r.Subject,r.Body);await client.SendMailAsync(msg);return Ok(new{Message="Email sent."});}
}
