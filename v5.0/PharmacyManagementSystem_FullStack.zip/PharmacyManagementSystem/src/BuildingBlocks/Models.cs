using System.ComponentModel.DataAnnotations;
namespace Pharmacy.BuildingBlocks;
public static class Roles { public const string Admin="Admin", Doctor="Doctor"; }
public enum OrderStatus { PendingVerification, Rejected, Verified, Paid, Completed }
public sealed class User { public int UserId {get;set;} [MaxLength(120)] public string Name {get;set;}=""; [MaxLength(254)] public string Email {get;set;}=""; [MaxLength(500)] public string PasswordHash {get;set;}=""; [MaxLength(20)] public string Role {get;set;}=Roles.Doctor; public bool IsActive {get;set;}=true; public DateTime CreatedAtUtc {get;set;}=DateTime.UtcNow; }
public sealed class Drug { public int DrugId {get;set;} [MaxLength(150)] public string Name {get;set;}=""; [MaxLength(500)] public string Description {get;set;}=""; [MaxLength(80)] public string Category {get;set;}="General"; public decimal UnitPrice {get;set;} public decimal GstRate {get;set;}=5; public bool IsActive {get;set;}=true; }
public sealed class Supplier { public int SupplierId {get;set;} [MaxLength(150)] public string Name {get;set;}=""; [MaxLength(254)] public string Email {get;set;}=""; [MaxLength(250)] public string Address {get;set;}=""; public bool IsActive {get;set;}=true; }
public sealed class Stock { public int StockId {get;set;} public int DrugId {get;set;} public int SupplierId {get;set;} public int QuantityOnHand {get;set;} public int QuantityReserved {get;set;} public int Available => QuantityOnHand-QuantityReserved; public byte[] RowVersion {get;set;}=Array.Empty<byte>(); }
public sealed class PharmacyOrder { public int OrderId {get;set;} public Guid PublicOrderId {get;set;}=Guid.NewGuid(); public int DoctorId {get;set;} public string Status {get;set;}=OrderStatus.PendingVerification.ToString(); public decimal Subtotal {get;set;} public decimal GstAmount {get;set;} public decimal TotalAmount {get;set;} [MaxLength(300)] public string? RejectionReason {get;set;} public DateTime CreatedAtUtc {get;set;}=DateTime.UtcNow; public List<OrderItem> Items {get;set;}=[]; }
public sealed class OrderItem { public int OrderItemId {get;set;} public int OrderId {get;set;} public int DrugId {get;set;} [MaxLength(150)] public string DrugName {get;set;}=""; public int Quantity {get;set;} public decimal UnitPrice {get;set;} public decimal GstRate {get;set;} public decimal LineTotal {get;set;} }
public sealed class Payment { public int PaymentId {get;set;} public int OrderId {get;set;} public string Status {get;set;}="Pending"; public decimal Amount {get;set;} [MaxLength(80)] public string TransactionReference {get;set;}=""; public DateTime CreatedAtUtc {get;set;}=DateTime.UtcNow; }
public sealed class SalesReport { public int SalesReportId {get;set;} public string PeriodType {get;set;}="Daily"; public DateOnly PeriodStart {get;set;} public int OrderCount {get;set;} public decimal Revenue {get;set;} public DateTime GeneratedAtUtc {get;set;}=DateTime.UtcNow; }
public sealed record RegisterRequest(string Name,string Email,string Password);
public sealed record LoginRequest(string Email,string Password);
public sealed record AuthResponse(string Token,string Role,string Name,string Email);
public sealed record DrugRequest(string Name,string Description,string Category,decimal UnitPrice,decimal GstRate,int InitialStock=0,int SupplierId=1);
public sealed record CreateOrderRequest(List<OrderLineRequest> Items);
public sealed record OrderLineRequest(int DrugId,int Quantity);
public sealed record PaymentRequest(int OrderId,string TestCard);
public sealed record ApiMessage(string Message);

public static class PharmacyRules {
 public static bool IsValidEmail(string? email)=>!string.IsNullOrWhiteSpace(email)&&new System.ComponentModel.DataAnnotations.EmailAddressAttribute().IsValid(email);
 public static bool IsValidPassword(string? password)=>!string.IsNullOrEmpty(password)&&password.Length>=8;
 public static bool IsValidQuantity(int quantity)=>quantity>0;
 public static bool IsValidCart(IEnumerable<OrderLineRequest>? items)=>items!=null&&items.Any()&&items.All(x=>x.DrugId>0&&x.Quantity>0);
 public static int AvailableStock(int onHand,int reserved)=>onHand-reserved;
 public static bool HasEnoughStock(int onHand,int reserved,int requested)=>requested>0&&AvailableStock(onHand,reserved)>=requested;
 public static decimal CalculateGst(decimal subtotal,decimal rate)=>Math.Round(subtotal*rate/100m,2);
 public static decimal CalculateTotal(decimal subtotal,decimal gst)=>Math.Round(subtotal+gst,2);
 public static bool CanVerify(OrderStatus status)=>status==OrderStatus.PendingVerification;
 public static bool CanPay(OrderStatus status)=>status==OrderStatus.Verified;
 public static bool CanPickup(OrderStatus status)=>status==OrderStatus.Paid;
 public static bool IsPaymentSuccessful(string? testCard)=>!string.IsNullOrWhiteSpace(testCard)&&!testCard.EndsWith("0000",StringComparison.Ordinal);
 public static bool CanViewInvoice(OrderStatus status)=>status is OrderStatus.Paid or OrderStatus.Completed;
 public static bool IsAdmin(string? role)=>role==Roles.Admin;
}
