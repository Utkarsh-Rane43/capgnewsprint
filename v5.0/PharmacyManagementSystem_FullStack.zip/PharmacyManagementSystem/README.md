# Pharmacy Management System

A trainee-friendly full-stack pharmacy workflow built with C#, ASP.NET Core Web API (.NET 10), EF Core, LINQ, SQL Server, YARP, JWT, Angular and NUnit.

## Solution layout
- `src/BuildingBlocks`: contracts, entities, password/JWT helpers and service-owned EF Core DbContexts.
- `src/Services/*`: six independently runnable APIs: Auth, Inventory, Order, Payment, SalesReport and Notification.
- `src/Gateway`: YARP reverse-proxy gateway.
- `frontend/pharmacy-ui`: Angular standalone application.
- `tests/Pharmacy.Tests`: 23 NUnit unit tests.
- `scripts`: migration, database and local run helpers.

The six APIs use five service-owned SQL Server databases. Notification has no database and sends SMTP email. Cross-service identifiers are logical IDs; there are no cross-service foreign keys. There is no broker, Docker, or real payment integration.

## Prerequisites
- .NET 10 SDK
- SQL Server / SQL Server Express / LocalDB
- Node.js 18.19+ and npm (Angular 18 is used for compatibility with Node 18.20.x)

## Configure SQL Server
Update each service's `ConnectionStrings:DefaultConnection` in its `appsettings.Development.json`. Defaults target `(localdb)\MSSQLLocalDB` and create five databases: UserDB, InventoryDB, OrderDB, PaymentDB and ReportDB.

## Create/update schemas
Install the EF CLI once with `dotnet tool install --global dotnet-ef --version 10.0.0`. Run from repository root (PowerShell):
```powershell
./scripts/Add-Migrations.ps1
./scripts/Update-Databases.ps1
```
Migrations are kept in the owning API project. On first setup, EF Core creates each service schema. If no migration exists yet, the script adds `InitialCreate` before updating.

## Run all services
```powershell
./scripts/Run-Local.ps1
```
Ports: Gateway 7000, Auth 7001, Inventory 7002, Order 7003, Payment 7004, SalesReport 7005, Notification 7006. Swagger: each service exposes its own `/swagger` UI on its port. Gateway Swagger UI is at `http://localhost:7000/swagger`; YARP API routes are prefixed `/auth`, `/inventory`, `/orders`, `/payments`, `/reports`, `/notifications`.

## Seeded Admin
On first Auth API startup, a default Admin is created if absent:
- Email: `admin@pharmacy.local`
- Password: `Admin@12345`

Change this password immediately for any shared/demo environment. Doctors register through the UI. Both roles use the same login endpoint.

## Frontend
```bash
cd frontend/pharmacy-ui
npm install
npm start
```
Open `http://localhost:4200`. Configure the API base URL in `src/environments/environment.ts` if the gateway port changes. Demo workflow: register/login as Doctor, browse medicines, add to cart, place order; login as Admin, verify/reject, view reports and confirm pickup. Payment is a simulation; use card number ending `0000` to simulate failure, any other non-empty test card to simulate success.

## Tests
```bash
dotnet test tests/Pharmacy.Tests/Pharmacy.Tests.csproj
```
The NUnit suite contains exactly 23 test cases covering validation, stock reservation, order transitions, payment simulation, totals and authorization rules. These are unit tests; run API smoke tests against SQL Server separately using Swagger.

## Workflow rules
1. Doctor creates an order. Order API validates requested quantities/prices against Inventory API.
2. Inventory reserves stock; Order is stored as `PendingVerification`.
3. Admin verifies or rejects. Rejection releases reservations.
4. Doctor pays only after verification. A failed simulated payment remains retryable and does not mark the order paid.
5. Successful payment marks the order `Paid`.
6. Admin confirms pickup. Inventory converts reserved units into on-hand deduction; SalesReport records the completed sale.
7. Invoice data is derived from Order + Payment records; no invoice-specific columns are added to Payments.

## Notes
- All money uses `decimal` and GST is calculated in the order service.
- Passwords are hashed using ASP.NET Core `PasswordHasher`.
- JWT authorization is role-based (`Admin`, `Doctor`).
- SMTP settings are optional; if not configured, notification API logs the message instead of failing the business operation.
- Keep secrets in user-secrets/environment variables. The seeded credentials are for local evaluation only.
