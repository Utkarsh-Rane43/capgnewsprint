# Database and API reference

## Databases (service-owned)
- **UserDB.Users**: UserId, Name, Email, PasswordHash, Role, IsActive, CreatedAtUtc. No phone/contact column.
- **InventoryDB**: Drugs, Suppliers, Stocks. Stock uses DrugId and SupplierId as logical references. DrugId is unique in Stocks.
- **OrderDB**: Orders, OrderItems. DoctorId and DrugId are logical references; no foreign keys into other service databases. OrderItems has a local FK to its own Order header.
- **PaymentDB.Payments**: PaymentId, OrderId (logical reference), Status, Amount, TransactionReference, CreatedAtUtc. Invoice attributes are not added to this table.
- **ReportDB.SalesReports**: SalesReportId, PeriodType, PeriodStart, OrderCount, Revenue, GeneratedAtUtc.
- Notification Service has no database.

The service DbContexts use EF Core and LINQ. Database schema evolution is handled by per-service EF Core migrations.

## Main endpoints (prefix with gateway route)
| Service | Endpoint | Access |
|---|---|---|
| Auth | POST `/auth/api/auth/register` | Public (Doctor only) |
| Auth | POST `/auth/api/auth/login` | Public (Admin + Doctor) |
| Inventory | GET `/inventory/api/inventory/drugs` | Public catalogue |
| Inventory | POST `/inventory/api/inventory/drugs` | Admin |
| Inventory | GET/POST `/inventory/api/inventory/suppliers` | Admin |
| Order | POST `/orders/api/orders` | Doctor |
| Order | GET `/orders/api/orders/mine` | Authenticated |
| Order | GET `/orders/api/orders` | Admin |
| Order | POST `/orders/api/orders/{id}/verify` | Admin |
| Order | POST `/orders/api/orders/{id}/reject` | Admin |
| Order | POST `/orders/api/orders/{id}/pickup` | Admin |
| Order | GET `/orders/api/orders/{id}/invoice` | Owner or Admin, after payment |
| Payment | POST `/payments/api/payments` | Authenticated |
| Payment | GET `/payments/api/payments` | Admin |
| Reports | GET `/reports/api/reports/summary` | Admin |
| Reports | POST `/reports/api/reports/snapshot` | Admin |
| Notification | POST `/notifications/api/notifications/email` | Internal/demo endpoint |

Swagger is enabled independently on each service. YARP exposes a unified gateway route. For full production deployment, add service-to-service authentication, rate limiting, centralized secrets, retries/compensation and a durable notification outbox.
