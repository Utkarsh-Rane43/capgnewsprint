using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using System.Net.Http.Json;
using System.Text;

namespace Pharmacy.Orders;

[ApiController, Route("api/invoices"), Authorize]
public class InvoiceController(OrderDb db, IHttpClientFactory clients, IConfiguration config) : ControllerBase
{
    [HttpGet("{orderId:int}")]
    public async Task<IActionResult> Get(int orderId)
    {
        var order = await db.Orders.AsNoTracking().Include(x => x.Items)
            .SingleOrDefaultAsync(x => x.OrderId == orderId);
        if (order is null) return NotFound();

        var userId = int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier) ?? User.FindFirstValue("sub"), out var id) ? id : 0;
        if (!User.IsInRole("Admin") && userId != order.UserId) return Forbid();
        if (order.OrderStatus is not ("Paid" or "PickedUp"))
            return Conflict(new { message = "Invoice is available only after successful payment." });

        PaymentInfo? payment = null;
        try
        {
            var client = clients.CreateClient("Payments");
            var token = Request.Headers.Authorization.ToString();
            if (!string.IsNullOrWhiteSpace(token)) client.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", token);
            var response = await client.GetAsync($"/api/payments/order/{orderId}");
            if (response.IsSuccessStatusCode)
            {
                var payments = await response.Content.ReadFromJsonAsync<List<PaymentInfo>>();
                payment = payments?.OrderByDescending(x => x.PaymentId).FirstOrDefault();
            }
        }
        catch { /* Invoice can still be produced from the paid order if payment lookup is unavailable. */ }

        var gstRate = config.GetValue<decimal>("Invoice:DefaultGstRatePercent", 5m);
        var pricesIncludeGst = config.GetValue<bool>("Invoice:PricesIncludeGst", true);
        var pdf = InvoicePdf.Create(order, payment, DateTime.Now, gstRate, pricesIncludeGst);
        return File(pdf, "application/pdf", $"Invoice-{order.OrderId}.pdf");
    }
}

public record PaymentInfo(int PaymentId, int OrderId, decimal Amount, string PaymentStatus, string TransactionReference);

internal static class InvoicePdf
{
    public static byte[] Create(Order order, PaymentInfo? payment, DateTime generatedAt, decimal gstRate, bool pricesIncludeGst)
    {
        var content = new StringBuilder();
        void Text(double x, double y, int size, string value, bool bold = false)
        {
            content.Append("BT /").Append(bold ? "F2" : "F1").Append(' ').Append(size)
                .Append(" Tf 1 0 0 1 ").Append(x).Append(' ').Append(y).Append(" Tm (")
                .Append(Escape(value)).Append(") Tj ET\n");
        }
        void Line(double x1, double y1, double x2, double y2)
            => content.Append(x1).Append(' ').Append(y1).Append(" m ").Append(x2).Append(' ').Append(y2).Append(" l S\n");
        void Rect(double x, double y, double w, double h)
            => content.Append(x).Append(' ').Append(y).Append(' ').Append(w).Append(' ').Append(h).Append(" re B\n");

        content.Append("0.12 0.22 0.34 rg 0 792 595 50 re f\n1 1 1 rg\n");
        Text(42, 815, 19, "PHARMACY MANAGEMENT", true);
        Text(42, 798, 9, "SALES INVOICE  |  CUSTOMER COPY");
        content.Append("0 0 0 RG 0.7 w\n");
        Text(42, 760, 16, $"INVOICE  INV-{order.OrderId:D5}", true);
        Text(42, 739, 10, $"Order number: {order.OrderId}");
        Text(42, 724, 10, $"Order date: {order.OrderDate:dd MMM yyyy, hh:mm tt}");
        Text(330, 739, 10, $"Invoice generated: {generatedAt:dd MMM yyyy, hh:mm tt}");
        Text(330, 724, 10, $"Order status: {order.OrderStatus}");

        content.Append("0.92 0.95 0.97 rg\n"); Rect(38, 675, 519, 25);
        content.Append("0 0 0 rg\n");
        Text(48, 684, 9, "MEDICINE", true); Text(300, 684, 9, "QTY", true);
        Text(360, 684, 9, "UNIT PRICE", true); Text(465, 684, 9, "AMOUNT", true);
        double y = 658;
        foreach (var item in order.Items)
        {
            Text(48, y, 9, $"Medicine ID {item.DrugId}");
            Text(300, y, 9, item.Quantity.ToString());
            Text(360, y, 9, $"Rs. {item.UnitPrice:0.00}");
            Text(465, y, 9, $"Rs. {item.SubTotal:0.00}");
            Line(42, y - 7, 552, y - 7);
            y -= 24;
        }
        var totalY = Math.Max(250, y - 12);
        content.Append("0.92 0.95 0.97 rg\n"); Rect(350, totalY - 12, 207, 34);
        content.Append("0 0 0 rg\n");
        Text(365, totalY, 11, "GRAND TOTAL", true);
        Text(465, totalY, 11, $"Rs. {order.TotalAmount:0.00}", true);

        var gstAmount = pricesIncludeGst ? order.TotalAmount * gstRate / (100m + gstRate) : order.TotalAmount * gstRate / 100m;
        var taxableAmount = pricesIncludeGst ? order.TotalAmount - gstAmount : order.TotalAmount;
        var invoiceTotal = pricesIncludeGst ? order.TotalAmount : order.TotalAmount + gstAmount;
        var gstY = totalY - 54;
        Text(42, gstY + 24, 11, "GST SUMMARY (CONFIGURED DEFAULT RATE)", true);
        Line(42, gstY + 17, 552, gstY + 17);
        Text(48, gstY, 9, $"Taxable value: Rs. {taxableAmount:0.00}");
        Text(48, gstY - 15, 9, $"GST @ {gstRate:0.##}%: Rs. {gstAmount:0.00}");
        Text(48, gstY - 30, 9, $"CGST: Rs. {gstAmount/2m:0.00}   SGST: Rs. {gstAmount/2m:0.00}");
        Text(350, gstY - 15, 10, $"Invoice total: Rs. {invoiceTotal:0.00}", true);
        Text(48, gstY - 46, 7, "GST rate is a configurable default; product-wise GST/HSN is not stored in the approved schema.");

        var payY = gstY - 88;
        Text(42, payY + 20, 12, "PAYMENT DETAILS", true);
        Line(42, payY + 13, 552, payY + 13);
        Text(48, payY - 2, 9, $"Payment status: {payment?.PaymentStatus ?? "Successful (order marked paid)"}");
        Text(48, payY - 18, 9, $"Transaction reference: {payment?.TransactionReference ?? "Not available"}");
        Text(48, payY - 34, 9, "Payment date/time: Not recorded (kept out to preserve the approved database schema)");

        Text(42, 65, 9, "Thank you for choosing our pharmacy.");
        Text(42, 49, 8, "This is a computer-generated invoice. No signature is required.");
        Text(42, 30, 8, "Please retain this invoice for your records.");

        var stream = Encoding.ASCII.GetBytes("q\n" + content + "Q\n");
        var objects = new List<byte[]>
        {
            Encoding.ASCII.GetBytes("<< /Type /Catalog /Pages 2 0 R >>"),
            Encoding.ASCII.GetBytes("<< /Type /Pages /Kids [3 0 R] /Count 1 >>"),
            Encoding.ASCII.GetBytes("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R /F2 5 0 R >> >> /Contents 6 0 R >>"),
            Encoding.ASCII.GetBytes("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"),
            Encoding.ASCII.GetBytes("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>")
        };
        using var ms = new MemoryStream();
        using var writer = new StreamWriter(ms, Encoding.ASCII, leaveOpen: true);
        writer.Write("%PDF-1.4\n"); writer.Flush();
        var offsets = new List<long> { 0 };
        for (var i = 0; i < objects.Count; i++)
        {
            offsets.Add(ms.Position); writer.Write($"{i + 1} 0 obj\n"); writer.Flush();
            ms.Write(objects[i]); writer.Write("\nendobj\n"); writer.Flush();
        }
        offsets.Add(ms.Position); writer.Write("6 0 obj\n"); writer.Write($"<< /Length {stream.Length} >>\nstream\n"); writer.Flush();
        ms.Write(stream); writer.Write("endstream\nendobj\n"); writer.Flush();
        var xref = ms.Position; writer.Write("xref\n0 7\n0000000000 65535 f \n");
        for (var i = 1; i < offsets.Count; i++) writer.Write($"{offsets[i]:D10} 00000 n \n");
        writer.Write($"trailer\n<< /Size 7 /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF"); writer.Flush();
        return ms.ToArray();
    }

    private static string Escape(string value) => value.Replace("\\", "\\\\").Replace("(", "\\(")
        .Replace(")", "\\)").Replace("\r", " ").Replace("\n", " ");
}
