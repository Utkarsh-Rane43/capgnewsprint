# Testing Guide — UT01 to UT23

The authoritative test-case list for this project is `TEST-CASES-UT01-UT23.xlsx` (with a Markdown copy at `TEST-CASES-UT01-UT23.md`). It contains the 23 scenarios supplied for the current LLD baseline. Do not renumber or silently alter expected outcomes.

## Swagger setup

1. Start the local application using `Run-Local.bat`.
2. Open `http://localhost:5000/swagger`.
3. Register a Doctor account and log in.
4. Copy the JWT from the login response and use Swagger's **Authorize** control for protected endpoints.
5. Use the seeded Admin account for Admin-only inventory and order-review scenarios.

## Test execution order

Run UT01–UT04 (authentication), UT05–UT10 (inventory), UT11–UT15 (orders), UT16–UT18 (payments), UT19 (invoice), UT20–UT21 (security), and UT22–UT23 (notifications).

## Important environment notes

- UT10 is an inventory reservation-release scenario. It may be tested through the internal stock release route or through the order rejection flow, depending on the service routing configuration.
- UT17 expects a simulated failed payment with HTTP 200 and a persisted `Failed` status, exactly as specified in the supplied test case.
- UT23 expects HTTP 500. If the current Notification Service maps SMTP failure to HTTP 503, record the mismatch instead of editing the expected result in the supplied baseline.
- Do not put production SMTP credentials or service-to-service secrets into test files.
- Update the **Actual Result / Remarks** column in the workbook during execution. Mark a case Passed only after observing its expected result.

## Build and automated test project

Run `dotnet test PharmacyManagementSystem.sln` after restoring packages. The NUnit project currently contains automated unit tests; the 23 LLD cases are the functional/API test plan and are not all automatically implemented as NUnit tests.
