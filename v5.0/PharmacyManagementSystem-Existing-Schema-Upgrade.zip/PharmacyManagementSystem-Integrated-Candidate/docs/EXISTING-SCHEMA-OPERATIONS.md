# Operational feature upgrade — existing schema only

This update preserves the existing five databases and eight tables. It does not add tables, columns, or migrations.

## Implemented using existing records and APIs

- Inventory workspace shows low-stock counts using a fixed threshold of 10 available units.
- Inventory workspace flags medicine records expiring within 60 days and already-expired medicine records, using `Drugs.ExpiryDate`.
- Admin can set the current available stock balance through the existing `PUT /api/inventory/{drugId}` endpoint. The endpoint prevents a new available balance lower than reserved stock.
- Purchase Planning groups low-stock medicine suggestions by the supplier already linked to each medicine. Suggested quantities are editable in the browser and can be printed as a replenishment planning sheet.
- Invoice PDF displays a GST summary using the configurable default rate in `OrderService/appsettings.json`. Prices are GST-inclusive by default.

## What is intentionally not implemented

The fixed schema does not contain the data needed to persist these workflows:
- Medicine batch/lot records and batch-specific expiry/FEFO traceability.
- Formal purchase orders, purchase-order lines, goods receipt, and supplier invoice reconciliation.
- Durable stock adjustment history, movement ledger, or user-attributed audit trail.
- Per-medicine HSN and GST rates.

The UI and documentation must not imply those records exist. Purchase Planning is a printable draft only. Stock balance edits update the existing aggregate inventory row and do not create an audit record.

## Configuration

`src/OrderService/appsettings.json`:

```json
"Invoice": {
  "DefaultGstRatePercent": 5.0,
  "PricesIncludeGst": true
}
```

The 5% value is a configurable example default, not a claim that every medicine is legally taxed at 5%. Verify applicable GST rates and registration details before issuing commercial invoices.

## Verification

The source package has been checked for ZIP integrity, test-case workbook presence, and frontend JavaScript syntax. Run the .NET build, EF Core migrations, and SQL Server integration tests on the Windows development machine before treating it as deployment-ready.
