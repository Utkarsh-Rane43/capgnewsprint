# Authoritative database schema — unchanged

This project intentionally keeps the approved schema unchanged: exactly five databases and eight existing tables. No additional database, table, or persisted column is introduced by the operational usability upgrade.

## UserDB — Auth Service
`Users(UserId INT PK, FullName VARCHAR(100), Email VARCHAR(150), PasswordHash VARCHAR(255), Role VARCHAR(20), IsActive BIT)`

## InventoryDB — Inventory Service
- `Suppliers(SupplierId INT PK, SupplierName VARCHAR(100), Email VARCHAR(150), Phone VARCHAR(20), Address VARCHAR(255))`
- `Drugs(DrugId INT PK, DrugName VARCHAR(100), Manufacturer VARCHAR(100), Price DECIMAL(10,2), ExpiryDate DATE, SupplierId INT)`
- `Inventory(InventoryId INT PK, DrugId INT, AvailableQuantity INT, ReservedQuantity INT)`

## OrderDB — Order Service
- `Orders(OrderId INT PK, UserId INT, OrderDate DATETIME, TotalAmount DECIMAL(10,2), OrderStatus VARCHAR(20))`
- `OrderItems(OrderItemId INT PK, OrderId INT, DrugId INT, Quantity INT, UnitPrice DECIMAL(10,2), SubTotal DECIMAL(10,2))`

## PaymentDB — Payment Service
`Payments(PaymentId INT PK, OrderId INT, Amount DECIMAL(10,2), PaymentStatus VARCHAR(20), TransactionReference VARCHAR(100))`

## ReportDB — Sales Report Service
`SalesReports(ReportId INT PK, ReportDate DATE, TotalOrders INT, TotalSales DECIMAL(10,2))`

There are no cross-database SQL foreign keys. IDs crossing service boundaries are logical references validated through service APIs.

## Explicit limitations caused by the fixed schema

- Expiry monitoring is medicine-level and uses `Drugs.ExpiryDate`. It is not batch/lot-level expiry tracking because there is no batch table.
- Reorder alerts use a fixed UI threshold of 10 available units. A per-medicine reorder threshold cannot be persisted without a new column.
- Stock adjustment updates the existing `Inventory.AvailableQuantity`, subject to the reserved-stock guard. The reason may be shown in the current UI interaction, but no durable stock movement/audit history can be kept without a ledger table.
- Purchase Planning generates a printable supplier-wise replenishment suggestion from current supplier, medicine, and stock records. It is not a saved purchase order; formal PO lifecycle and goods receipt require new tables.
- GST invoice breakdown uses the configurable default rate in `OrderService/appsettings.json`. The approved schema has no HSN or per-medicine GST rate, so the generated summary is not a product-specific tax determination. Confirm the correct rate and tax registration details with the pharmacy's accountant before real commercial use.
- Invoice prices are configured as GST-inclusive by default (`Invoice:PricesIncludeGst: true`). Change only after confirming how medicine prices are entered in the catalogue.

These are deliberate constraints, not missing implementation. Do not describe the current build as supporting batch traceability, formal purchase order persistence, stock audit history, or item-specific GST.
