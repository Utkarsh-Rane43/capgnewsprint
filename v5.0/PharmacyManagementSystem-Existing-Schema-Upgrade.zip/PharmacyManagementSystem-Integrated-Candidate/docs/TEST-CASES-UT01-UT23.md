# Pharmacy Management System — Test Cases (UT01–UT23)

These 23 test cases are transcribed from the test-case list supplied for this project. Scenario names, preconditions, steps, test data and expected results are preserved. The final column is the remarks/result column and is initially set to `—` for execution-time updates.

| Test Case ID | Module | Test Case | Preconditions | Test Steps | Test Data | Expected Result | Actual Result / Remarks |
|---|---|---|---|---|---|---|---|
| UT01 | Authentication | Register valid user | Email not registered | Submit registration form | Valid name, email, password | User created successfully (201 Created) | — |
| UT02 | Authentication | Register duplicate email | Email already exists | Submit registration form | Existing email | Duplicate email rejected (409 Conflict) | — |
| UT03 | Authentication | Login with valid credentials | Active registered user | Submit login request | Valid email and password | JWT generated (200 OK) | — |
| UT04 | Authentication | Login with wrong password | User exists | Submit login request | Incorrect password | Login rejected (401 Unauthorized) | — |
| UT05 | Inventory | Add medicine | Admin authenticated | Submit medicine details | Paracetamol, ₹25, Qty: 100 | Medicine added (201 Created) | — |
| UT06 | Inventory | Add medicine with negative price | Admin authenticated | Submit medicine details | Price: -₹25 | Validation error (400 Bad Request) | — |
| UT07 | Inventory | Check available stock | Medicine exists | Request stock by DrugId | DrugId: 101 | Stock details returned (200 OK) | — |
| UT08 | Inventory | Reserve available stock | Sufficient stock exists | Submit reservation request | DrugId: 101, Qty: 5 | Stock reserved (200 OK) | — |
| UT09 | Inventory | Reserve unavailable stock | Insufficient stock exists | Submit reservation request | DrugId: 101, Qty: 10000 | Reservation rejected (409 Conflict) | — |
| UT10 | Inventory | Release reserved stock | Stock is reserved | Submit release request | DrugId: 101, Qty: 5 | Stock released (200 OK) | — |
| UT11 | Orders | Place valid order | User authenticated; stock available | Submit order request | UserId: 1, DrugId: 101, Qty: 2 | Order created (201 Created) | — |
| UT12 | Orders | Place empty order | User authenticated | Submit empty order | Items: Empty | Validation error (400 Bad Request) | — |
| UT13 | Orders | Verify pending order | Order is Pending | Submit verification request | OrderId: 501 | Order status updated (200 OK) | — |
| UT14 | Orders | Reject pending order | Pending order; stock reserved | Submit rejection request | OrderId: 501 | Order rejected; stock released (200 OK) | — |
| UT15 | Orders | Verify rejected order | Order already Rejected | Submit verification request | OrderId: 501 | Operation rejected (409 Conflict) | — |
| UT16 | Payments | Process valid payment | Valid order exists | Submit payment request | OrderId: 501, ₹500 | Payment successful (200 OK) | — |
| UT17 | Payments | Process failed payment | Valid order exists | Simulate payment failure | OrderId: 501, ₹500 | Payment marked Failed (200 OK)* | — |
| UT18 | Payments | Repeat payment request | Payment already processed | Retry with same idempotency key | OrderId: 501, PAY501 | Duplicate processing prevented (200 OK) | — |
| UT19 | Invoice | Retrieve paid-order invoice | Order paid successfully | Request invoice by OrderId | OrderId: 501 | Invoice returned (200 OK) | — |
| UT20 | Security | Access API without token | Protected API available | Call API without JWT | No token | Access denied (401 Unauthorized) | — |
| UT21 | Security | Doctor accesses Admin API | Doctor has valid JWT | Call Admin-only API | Doctor JWT | Access forbidden (403 Forbidden) | — |
| UT22 | Notification | Send email successfully | SMTP configured | Submit email request | user@test.com, Order Confirmation | Email sent (200 OK) | — |
| UT23 | Notification | Handle SMTP failure | SMTP unavailable | Submit email request | Invalid SMTP configuration | Sending failure handled (500 Internal Server Error) | — |

## Execution notes

- Execute UT01–UT04 against the Auth Service.
- Execute UT05–UT10 against the Inventory Service and its reservation/release workflow.
- Execute UT11–UT15 against the Order Service and the cross-service stock workflow.
- Execute UT16–UT18 against the simulated Payment Service, using the same idempotency key for UT18.
- Execute UT19 against the invoice endpoint for a successfully paid order.
- Execute UT20 and UT21 with no token and a Doctor JWT respectively.
- Execute UT22 and UT23 only with controlled SMTP test configuration; do not use production mail credentials.

## Notes requiring implementation/environment confirmation

- UT10 may be exercised through the internal Inventory reservation-release endpoint or via order rejection, depending on the configured service-to-service route.
- UT17 expects the simulated payment failure to be represented as a completed API operation with a Failed payment status and HTTP 200, as specified in the supplied test case.
- UT23 specifies HTTP 500. If the service currently maps SMTP outages to HTTP 503, record the observed result and raise the expected-status difference for review rather than silently changing this test case.
- UT16/UT17 use HTTP 200 as specified in the supplied list; validate the actual API response contract before marking Passed.

## Execution result legend

`Not Run` · `Passed` · `Failed` · `Blocked`
