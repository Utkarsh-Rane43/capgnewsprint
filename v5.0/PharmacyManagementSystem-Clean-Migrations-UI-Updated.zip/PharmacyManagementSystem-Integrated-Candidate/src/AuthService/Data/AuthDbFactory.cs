using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using Pharmacy.Auth;

namespace Pharmacy.Auth.Data;

public sealed class AuthDbFactory : IDesignTimeDbContextFactory<AuthDb>
{
    public AuthDb CreateDbContext(string[] args)
    {
        var configuration = new ConfigurationBuilder()
            .SetBasePath(AppContext.BaseDirectory)
            .AddJsonFile("appsettings.json", optional: false)
            .AddEnvironmentVariables()
            .Build();

        var connectionString = configuration.GetConnectionString("Default")
            ?? throw new InvalidOperationException("Connection string 'Default' is missing.");

        var options = new DbContextOptionsBuilder<AuthDb>()
            .UseSqlServer(connectionString)
            .Options;

        return new AuthDb(options);
    }
}
