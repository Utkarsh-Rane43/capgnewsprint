using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.EntityFrameworkCore.Metadata;
using Pharmacy.Auth;

namespace Pharmacy.Auth.Data.Migrations;

[DbContext(typeof(AuthDb))]
partial class AuthDbModelSnapshot : ModelSnapshot
{
    protected override void BuildModel(ModelBuilder modelBuilder)
    {
        modelBuilder.HasAnnotation("ProductVersion", "10.0.15")
            .HasAnnotation("Relational:MaxIdentifierLength", 128);
        Microsoft.EntityFrameworkCore.SqlServerModelBuilderExtensions.UseIdentityColumns(modelBuilder);
        modelBuilder.Entity<Pharmacy.Auth.User>(b =>
{
    b.Property<int>("UserId").ValueGeneratedOnAdd().HasColumnType("int");
    Microsoft.EntityFrameworkCore.SqlServerPropertyBuilderExtensions.UseIdentityColumn(b.Property<int>("UserId"));
    b.Property<string>("FullName").IsRequired().HasMaxLength(100).HasColumnType("nvarchar(100)");
    b.Property<string>("Email").IsRequired().HasMaxLength(150).HasColumnType("nvarchar(150)");
    b.Property<string>("PasswordHash").IsRequired().HasMaxLength(255).HasColumnType("nvarchar(255)");
    b.Property<string>("Role").IsRequired().HasMaxLength(20).HasColumnType("nvarchar(20)");
    b.Property<bool>("IsActive").HasColumnType("bit");
    b.HasKey("UserId");
    b.HasIndex("Email").IsUnique();
    b.ToTable("Users");
});
    }
}
