using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.EntityFrameworkCore;
using Pharmacy.Auth;
using Pharmacy.Auth.Data;

namespace Pharmacy.Auth.Data.Migrations;

[DbContext(typeof(AuthDb))]
[Migration("202611230001_InitialCreate")]
public sealed class InitialCreate : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.Sql(@"CREATE TABLE [Users] (
 [UserId] INT IDENTITY(1,1) NOT NULL CONSTRAINT [PK_Users] PRIMARY KEY,
 [FullName] NVARCHAR(100) NOT NULL,
 [Email] NVARCHAR(150) NOT NULL,
 [PasswordHash] NVARCHAR(255) NOT NULL,
 [Role] NVARCHAR(20) NOT NULL,
 [IsActive] BIT NOT NULL
);
CREATE UNIQUE INDEX [IX_Users_Email] ON [Users]([Email]);");
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.Sql(@"DROP TABLE [Users];");
    }
}
