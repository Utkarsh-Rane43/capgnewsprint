namespace Pharmacy.Common;
public record ApiResult<T>(bool Success, string Message, T? Data = default, object? Errors = null);
