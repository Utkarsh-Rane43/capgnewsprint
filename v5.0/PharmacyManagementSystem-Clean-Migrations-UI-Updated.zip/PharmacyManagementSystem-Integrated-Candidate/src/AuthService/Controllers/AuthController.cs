using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using System.Net.Http.Json;
namespace Pharmacy.Auth;
[ApiController]
[Route("api")]
public class AuthController(AuthService service, AuthDb db, IHttpClientFactory clients, ILogger<AuthController> logger) : ControllerBase
{
    [AllowAnonymous, HttpPost("auth/register")]
    public async Task<IActionResult> Register(RegisterRequest request)
    {
        try
        {
            var user = await service.Register(request.FullName, request.Email, request.Password, request.Role, request.AdminInvitationCode);
            try
            {
                await clients.CreateClient("Notify").PostAsJsonAsync("/api/notifications/email", new
                {
                    to = user.Email,
                    subject = "Pharmacy Management System registration",
                    body = $"Hello {user.FullName}, your {user.Role} account has been registered successfully."
                });
            }
            catch (Exception ex) { logger.LogWarning(ex, "Registration notification could not be sent."); }
            return StatusCode(201, new { success = true, message = "User registered successfully", data = new { user.UserId, user.FullName, user.Email, user.Role } });
        }
        catch (UnauthorizedAccessException ex) { return Unauthorized(new { success = false, message = ex.Message }); }
        catch (DuplicateEmailException ex) { return Conflict(new { success = false, message = ex.Message }); }
        catch (ArgumentException ex) { return BadRequest(new { success = false, message = ex.Message }); }
    }
    [AllowAnonymous, HttpPost("auth/login")]
    public async Task<IActionResult> Login(LoginRequest request)
    {
        try
        {
            var (user, token) = await service.Login(request.Email, request.Password);
            return Ok(new { success = true, message = "Login successful", data = new { user.UserId, user.Email, user.Role, token, expiresIn = 3600 } });
        }
        catch (UnauthorizedAccessException ex) { return Unauthorized(new { success = false, message = ex.Message }); }
    }
    [Authorize(Roles = "Admin"), HttpGet("users")]
    public async Task<IActionResult> Users() => Ok(await db.Users.Select(u => new { u.UserId, u.FullName, u.Email, u.Role, u.IsActive }).ToListAsync());
    [Authorize, HttpGet("users/{id:int}")]
    public async Task<IActionResult> GetUser(int id)
    {
        var user = await db.Users.FindAsync(id);
        if (user is null) return NotFound();
        var callerId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
        if (!User.IsInRole("Admin") && callerId != id.ToString()) return Forbid();
        return Ok(new { user.UserId, user.FullName, user.Email, user.Role, user.IsActive });
    }
    [Authorize(Roles = "Admin"), HttpPut("users/{id:int}")]
    public async Task<IActionResult> Update(int id, UpdateUserRequest request)
    {
        var user = await db.Users.FindAsync(id);
        if (user is null) return NotFound();
        if (string.IsNullOrWhiteSpace(request.FullName)) return BadRequest(new { message = "Full name is required." });
        user.FullName = request.FullName.Trim(); user.IsActive = request.IsActive;
        await db.SaveChangesAsync(); return NoContent();
    }
}
public record RegisterRequest(string FullName, string Email, string Password, string Role = "Doctor", string? AdminInvitationCode = null);
public record LoginRequest(string Email, string Password);
public record UpdateUserRequest(string FullName, bool IsActive);
