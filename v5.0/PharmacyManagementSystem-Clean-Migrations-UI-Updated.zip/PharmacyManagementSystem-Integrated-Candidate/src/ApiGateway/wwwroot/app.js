const $ = (selector) => document.querySelector(selector);
let token = localStorage.getItem('pharmaToken') || '';
let me = JSON.parse(localStorage.getItem('pharmaUser') || 'null');
let tab = '';
let catalogCache = new Map();
let quantitySelection = null;

const api = async (path, options = {}) => {
    const headers = { ...(options.headers || {}) };
    if (token) headers.Authorization = `Bearer ${token}`;
    if (options.body) headers['Content-Type'] = 'application/json';
    const response = await fetch(path, { ...options, headers });
    const text = await response.text();
    let data;
    try { data = text ? JSON.parse(text) : null; } catch { data = text; }
    if (!response.ok) throw new Error(data?.message || data?.title || `Request failed (${response.status})`);
    return data;
};

const esc = (value) => String(value ?? '').replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
}[c]));
const money = value => `₹${Number(value || 0).toFixed(2)}`;
const cartKey = () => `pharmaCart_${me?.userId || 'guest'}`;
const getCart = () => JSON.parse(localStorage.getItem(cartKey()) || '[]');
const saveCart = items => localStorage.setItem(cartKey(), JSON.stringify(items));

function msg(text, error = false, where = '#appMessage') {
    const element = $(where);
    if (!element) return;
    element.textContent = text || '';
    element.classList.toggle('error', !!error);
}
function authMode(mode) {
    $('#loginForm').classList.toggle('hidden', mode !== 'login');
    $('#registerForm').classList.toggle('hidden', mode !== 'register');
    document.querySelectorAll('.tab').forEach(x => x.classList.toggle('active', x.dataset.auth === mode));
    msg('', false, '#authMessage');
}
document.querySelectorAll('.tab').forEach(x => x.onclick = () => authMode(x.dataset.auth));
$('#regRole').onchange = e => $('#adminCodeWrap').classList.toggle('hidden', e.target.value !== 'Admin');

$('#loginForm').onsubmit = async e => {
    e.preventDefault();
    const form = new FormData(e.target);
    try {
        const result = await api('/api/auth/login', { method: 'POST', body: JSON.stringify(Object.fromEntries(form)) });
        const user = result.data;
        token = user.token;
        me = { userId: user.userId, email: user.email, role: user.role };
        localStorage.setItem('pharmaToken', token);
        localStorage.setItem('pharmaUser', JSON.stringify(me));
        showApp();
    } catch (error) { msg(error.message, true, '#authMessage'); }
};
$('#registerForm').onsubmit = async e => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.target));
    try {
        await api('/api/auth/register', { method: 'POST', body: JSON.stringify(data) });
        msg('Account created. Please sign in.', false, '#authMessage');
        authMode('login');
        $('#loginForm [name=email]').value = data.email;
    } catch (error) { msg(error.message, true, '#authMessage'); }
};

function logout() {
    token = ''; me = null;
    localStorage.removeItem('pharmaToken');
    localStorage.removeItem('pharmaUser');
    $('#auth').classList.remove('hidden');
    $('#app').classList.add('hidden');
    $('#userbar').classList.add('hidden');
}
window.logout = logout;

function showApp() {
    if (!token || !me) return;
    $('#auth').classList.add('hidden');
    $('#app').classList.remove('hidden');
    $('#userbar').classList.remove('hidden');
    $('#who').textContent = `${me.email} · ${me.role}`;
    $('#roleLabel').textContent = `${me.role.toUpperCase()} WORKSPACE`;
    $('#welcomeTitle').textContent = me.role === 'Admin' ? 'Pharmacy overview' : 'Medicine store';
    $('#welcomeText').textContent = me.role === 'Admin'
        ? 'Manage suppliers, medicines, stock, orders, invoices and reports.'
        : 'Browse medicines, manage your cart, place orders and view invoices.';

    const items = me.role === 'Admin'
        ? ['Overview', 'Suppliers', 'Medicines', 'Inventory', 'Orders', 'Invoices', 'Reports', 'Users']
        : ['Medicines', 'Cart', 'My Orders', 'Invoices'];
    $('#nav').innerHTML = items.map((name, index) =>
        `<button class="${index === 0 ? 'active' : ''}" data-tab="${name}">${name}${name === 'Cart' && getCart().length ? ` (${getCart().length})` : ''}</button>`
    ).join('');
    $('#nav').querySelectorAll('button').forEach(button => button.onclick = () => {
        document.querySelectorAll('#nav button').forEach(x => x.classList.toggle('active', x === button));
        render(button.dataset.tab);
    });
    render(items[0]);
}

function table(headers, rows) {
    if (!rows?.length) return '<div class="empty">No records found yet.</div>';
    return `<div class="table-wrap"><table><thead><tr>${headers.map(x => `<th>${x}</th>`).join('')}</tr></thead><tbody>${rows.map(row =>
        `<tr>${row.map(value => `<td>${value ?? ''}</td>`).join('')}</tr>`
    ).join('')}</tbody></table></div>`;
}
function form(title, fields, label = 'Save') {
    return `<div class="card form-card"><h3>${title}</h3><form id="workForm"><div class="form-grid">${fields.map(field => `
        <label class="${field.wide ? 'wide' : ''}">${field.label}
        ${field.type === 'select'
            ? `<select name="${field.name}" ${field.required ? 'required' : ''}>${field.options.map(option => `<option value="${option.value}">${esc(option.label)}</option>`).join('')}</select>`
            : `<input name="${field.name}" type="${field.type || 'text'}" ${field.required ? 'required' : ''} ${field.step ? `step="${field.step}"` : ''} ${field.min !== undefined ? `min="${field.min}"` : ''} placeholder="${field.placeholder || ''}">`}
        </label>`).join('')}</div><button class="primary">${label}</button></form></div>`;
}

async function render(view) {
    tab = view;
    msg('');
    const content = $('#content');
    content.innerHTML = '<div class="empty">Loading…</div>';
    try {
        if (view === 'Overview') {
            const [suppliers, drugs, orders] = await Promise.all([api('/api/suppliers'), api('/api/drugs'), api('/api/orders')]);
            const paid = orders.filter(x => ['Paid', 'PickedUp'].includes(x.orderStatus));
            content.innerHTML = `<div class="grid">
                <div class="card"><span class="muted">Suppliers</span><div class="metric">${suppliers.length}</div></div>
                <div class="card"><span class="muted">Medicines</span><div class="metric">${drugs.length}</div></div>
                <div class="card"><span class="muted">Orders</span><div class="metric">${orders.length}</div></div>
                <div class="card"><span class="muted">Paid / picked-up orders</span><div class="metric">${paid.length}</div></div>
            </div><div class="card"><h3>Daily workflow</h3><p class="muted">Register suppliers, add medicines and opening stock. Doctors add medicines to a cart and check out. Orders reserve stock and wait for Admin verification. Verified orders can be paid, then finalized at pickup.</p></div>`;
        }
        else if (view === 'Suppliers') {
            const suppliers = await api('/api/suppliers');
            content.innerHTML = form('Add supplier', [
                { name: 'supplierName', label: 'Supplier name', required: true },
                { name: 'email', label: 'Email', type: 'email' },
                { name: 'phone', label: 'Phone' },
                { name: 'address', label: 'Address', wide: true }
            ]) + `<h3>Registered suppliers</h3>${table(['ID', 'Name', 'Email', 'Phone', 'Address'], suppliers.map(x =>
                [x.supplierId, esc(x.supplierName), esc(x.email), esc(x.phone), esc(x.address)]))}`;
            wireForm('supplier');
        }
        else if (view === 'Medicines') {
            const [drugs, suppliers, stock] = await Promise.all([api('/api/drugs'), api('/api/suppliers'), api('/api/inventory')]);
            catalogCache = new Map(drugs.map(drug => [drug.drugId, { ...drug, availableQuantity: stock.find(row => row.drugId === drug.drugId)?.availableQuantity ?? 0 }]));
            const stockByDrug = new Map(stock.map(x => [x.drugId, x]));
            const addForm = me.role === 'Admin' ? form('Add medicine', [
                { name: 'drugName', label: 'Medicine name', required: true },
                { name: 'manufacturer', label: 'Manufacturer', required: true },
                { name: 'price', label: 'Price (₹)', type: 'number', step: '0.01', min: 0.01, required: true },
                { name: 'expiryDate', label: 'Expiry date', type: 'date', required: true },
                { name: 'supplierId', label: 'Supplier', type: 'select', required: true, options: suppliers.map(x => ({ value: x.supplierId, label: `${x.supplierName} (#${x.supplierId})` })) },
                { name: 'initialQuantity', label: 'Opening stock', type: 'number', min: 0, required: true }
            ]) : '';
            content.innerHTML = addForm + `<h3>Medicine catalogue</h3>${table(
                ['ID', 'Medicine', 'Manufacturer', 'Price', 'Expiry', 'Available', 'Actions'],
                drugs.map(x => {
                    const stockRow = stockByDrug.get(x.drugId);
                    const actions = me.role === 'Doctor'
                        ? `<button class="action" onclick="addToCart(${x.drugId})">Add to Cart</button><button class="action" onclick="orderNow(${x.drugId})">Order Now</button>`
                        : '';
                    return [x.drugId, esc(x.drugName), esc(x.manufacturer), money(x.price), esc(x.expiryDate).slice(0, 10), stockRow?.availableQuantity ?? 0, actions];
                })
            )}`;
            if (me.role === 'Admin') wireForm('drug');
        }
        else if (view === 'Inventory') {
            const rows = await api('/api/inventory');
            content.innerHTML = `<h3>Current stock</h3><p class="muted">Processed quantity is calculated from successfully paid orders. It is a report value, not an additional database column.</p>${table(
                ['Drug ID', 'Medicine', 'Available', 'Reserved', 'Processed (paid)'],
                rows.map(x => [x.drugId, esc(x.drugName), x.availableQuantity, x.reservedQuantity, x.processedQuantity ?? 0])
            )}`;
        }
        else if (view === 'Cart') {
            await renderCart(content);
        }
        else if (view === 'Orders' || view === 'My Orders') {
            const orders = await api(me.role === 'Doctor' ? '/api/orders/my-orders' : '/api/orders');
            content.innerHTML = `<h3>${me.role === 'Doctor' ? 'Your orders' : 'All pharmacy orders'}</h3>${table(
                ['Order', 'Date', 'User ID', 'Total', 'Status', 'Items / Actions'],
                orders.map(order => {
                    const itemText = (order.items || []).map(item => `Drug ${item.drugId} × ${item.quantity}`).join(', ');
                    let actions = '';
                    if (me.role === 'Admin' && order.orderStatus === 'PendingVerification')
                        actions += `<button class="action" onclick="orderAction(${order.orderId},'verify')">Verify</button><button class="action" onclick="orderAction(${order.orderId},'reject')">Reject</button>`;
                    if (me.role === 'Doctor' && order.orderStatus === 'Verified') actions += `<button class="action" onclick="pay(${order.orderId})">Pay</button>`;
                    if (me.role === 'Admin' && order.orderStatus === 'Paid') actions += `<button class="action" onclick="pickup(${order.orderId})">Finalize pickup</button>`;
                    if (['Paid', 'PickedUp'].includes(order.orderStatus)) actions += `<button class="action" onclick="invoice(${order.orderId})">Invoice PDF</button>`;
                    return [order.orderId, esc(order.orderDate).replace('T', ' ').slice(0, 16), order.userId, money(order.totalAmount), esc(order.orderStatus), `${esc(itemText)}<br>${actions}`];
                })
            )}`;
        }
        else if (view === 'Invoices') {
            const orders = await api(me.role === 'Doctor' ? '/api/orders/my-orders' : '/api/orders');
            const paidOrders = orders.filter(x => ['Paid', 'PickedUp'].includes(x.orderStatus));
            content.innerHTML = `<h3>${me.role === 'Admin' ? 'Pharmacy invoices' : 'Your invoices'}</h3><p class="muted">Invoices become available after a successful payment.</p>${table(
                ['Invoice', 'Order date', 'Order ID', 'Total', 'Order status', 'Download'],
                paidOrders.map(x => [`INV-${String(x.orderId).padStart(5, '0')}`, esc(x.orderDate).replace('T', ' ').slice(0, 16), x.orderId, money(x.totalAmount), esc(x.orderStatus), `<button class="action" onclick="invoice(${x.orderId})">Download PDF</button>`])
            )}`;
        }
        else if (view === 'Reports') {
            content.innerHTML = `<div class="card"><h3>Sales reports</h3><div class="form-grid">
                <label>Report period<select id="reportPeriod"><option value="daily">Daily</option><option value="monthly">Monthly</option><option value="yearly">Annual</option></select></label>
                <label id="reportDateWrap">Date<input id="reportDate" type="date" value="${new Date().toISOString().slice(0, 10)}"></label>
                <label id="reportMonthWrap" class="hidden">Month<input id="reportMonth" type="month" value="${new Date().toISOString().slice(0, 7)}"></label>
                <label id="reportYearWrap" class="hidden">Year<input id="reportYear" type="number" min="2000" max="2100" value="${new Date().getFullYear()}"></label>
            </div><button class="primary" onclick="loadReport()">Generate report</button></div><div id="reportData"></div>`;
            $('#reportPeriod').onchange = updateReportFields;
            await loadReport();
        }
        else if (view === 'Users') {
            const users = await api('/api/users');
            content.innerHTML = `<h3>Registered users</h3>${table(['ID', 'Name', 'Email', 'Role', 'Active'], users.map(x =>
                [x.userId, esc(x.fullName), esc(x.email), esc(x.role), x.isActive ? 'Yes' : 'No']))}`;
        }
    } catch (error) {
        content.innerHTML = `<div class="empty">${esc(error.message)}<br><small>Check that services are running and your account has permission.</small></div>`;
    }
}

async function renderCart(content) {
    const cart = getCart();
    if (!cart.length) {
        content.innerHTML = '<div class="empty">Your cart is empty. Open Medicines and add some items.</div>';
        return;
    }
    const [drugs, stock] = await Promise.all([api('/api/drugs'), api('/api/inventory')]);
    const drugMap = new Map(drugs.map(x => [x.drugId, x]));
    const stockMap = new Map(stock.map(x => [x.drugId, x]));
    const validItems = cart.filter(x => drugMap.has(x.drugId));
    saveCart(validItems);
    const total = validItems.reduce((sum, item) => sum + (drugMap.get(item.drugId)?.price || 0) * item.quantity, 0);
    content.innerHTML = `<div class="card"><h3>Shopping cart</h3><p class="muted">Stock is reserved only when you check out and submit the order.</p>${table(
        ['Medicine', 'Unit price', 'Available now', 'Quantity', 'Subtotal', 'Action'],
        validItems.map(item => {
            const drug = drugMap.get(item.drugId), quantity = item.quantity;
            return [esc(drug.drugName), money(drug.price), stockMap.get(item.drugId)?.availableQuantity ?? 0,
                `<input aria-label="Quantity" type="number" min="1" max="999" value="${quantity}" onchange="changeCartQuantity(${item.drugId},this.value)" style="width:85px">`,
                money(drug.price * quantity), `<button class="action" onclick="removeFromCart(${item.drugId})">Remove</button>`];
        })
    )}<div class="row" style="justify-content:flex-end;margin-top:18px"><strong>Estimated total: ${money(total)}</strong><button class="primary" onclick="checkoutCart()">Proceed to checkout</button></div></div>`;
}

function wireForm(kind) {
    const formElement = $('#workForm');
    if (!formElement) return;
    formElement.onsubmit = async event => {
        event.preventDefault();
        const data = Object.fromEntries(new FormData(formElement));
        try {
            if (kind === 'supplier') {
                await api('/api/suppliers', { method: 'POST', body: JSON.stringify(data) });
            } else {
                data.price = Number(data.price);
                data.supplierId = Number(data.supplierId);
                data.initialQuantity = Number(data.initialQuantity);
                await api('/api/drugs', { method: 'POST', body: JSON.stringify(data) });
            }
            msg('Saved successfully.');
            render(tab);
        } catch (error) { msg(error.message, true); }
    };
}

window.addToCart = drugId => openQuantityDialog(drugId, 'cart');
window.orderNow = drugId => openQuantityDialog(drugId, 'order');

function openQuantityDialog(drugId, action) {
    const drug = catalogCache.get(drugId);
    if (!drug) {
        msg('Medicine details are not available. Refresh the catalogue and try again.', true);
        return;
    }

    const alreadyInCart = getCart().find(item => item.drugId === drugId)?.quantity || 0;
    const remaining = Math.max(0, Number(drug.availableQuantity) - (action === 'cart' ? alreadyInCart : 0));
    quantitySelection = { drugId, action, drug, remaining };
    $('#quantityMedicine').textContent = drug.drugName;
    $('#quantityPrice').textContent = money(drug.price);
    $('#quantityStock').textContent = `${drug.availableQuantity} units`;
    $('#quantityInput').value = '1';
    $('#quantityInput').max = Math.max(1, remaining);
    $('#quantityHint').textContent = action === 'cart' && alreadyInCart
        ? `${alreadyInCart} already in your cart · ${remaining} more available`
        : 'Choose the number of units you need.';
    $('#quantityConfirm').textContent = action === 'cart' ? 'Add to cart' : 'Continue to order';
    $('#quantityError').textContent = remaining < 1 ? 'No additional stock is available for this medicine.' : '';
    $('#quantityConfirm').disabled = remaining < 1;
    updateQuantitySubtotal();
    $('#quantityDialog').classList.remove('hidden');
    document.body.classList.add('dialog-open');
    window.setTimeout(() => $('#quantityInput').focus(), 30);
}

window.closeQuantityDialog = () => {
    $('#quantityDialog').classList.add('hidden');
    document.body.classList.remove('dialog-open');
    quantitySelection = null;
};

window.adjustQuantity = delta => {
    const input = $('#quantityInput');
    const max = Number(input.max || 999);
    input.value = String(Math.min(max, Math.max(1, Number(input.value || 1) + delta)));
    updateQuantitySubtotal();
};

function updateQuantitySubtotal() {
    if (!quantitySelection) return;
    const quantity = Number($('#quantityInput').value || 0);
    $('#quantitySubtotal').textContent = money(quantitySelection.drug.price * Math.max(0, quantity));
    const valid = Number.isInteger(quantity) && quantity >= 1 && quantity <= quantitySelection.remaining;
    $('#quantityError').textContent = valid ? '' : `Enter a whole number between 1 and ${quantitySelection.remaining}.`;
    $('#quantityConfirm').disabled = !valid;
}
$('#quantityInput').addEventListener('input', updateQuantitySubtotal);

window.confirmQuantitySelection = async () => {
    if (!quantitySelection) return;
    const { drugId, action, remaining } = quantitySelection;
    const quantity = Number($('#quantityInput').value);
    if (!Number.isInteger(quantity) || quantity < 1 || quantity > remaining) {
        updateQuantitySubtotal();
        return;
    }

    closeQuantityDialog();
    if (action === 'order') {
        await submitOrder([{ drugId, quantity }], false);
        return;
    }

    const cart = getCart();
    const existing = cart.find(item => item.drugId === drugId);
    if (existing) existing.quantity += quantity;
    else cart.push({ drugId, quantity });
    saveCart(cart);
    msg(`${quantity} × ${catalogCache.get(drugId)?.drugName || 'Medicine'} added to your cart.`);
    showCartCount();
};

window.changeCartQuantity = (drugId, value) => {
    const quantity = Number(value);
    if (!Number.isInteger(quantity) || quantity < 1) return render('Cart');
    const cart = getCart();
    const item = cart.find(x => x.drugId === drugId);
    if (item) item.quantity = quantity;
    saveCart(cart);
    render('Cart');
};
window.removeFromCart = drugId => {
    saveCart(getCart().filter(x => x.drugId !== drugId));
    showCartCount();
    render('Cart');
};
window.checkoutCart = async () => {
    const cart = getCart();
    if (!cart.length) return msg('Your cart is empty.', true);
    await submitOrder(cart, true);
};
async function submitOrder(items, clearCart = false) {
    try {
        const result = await api('/api/orders', { method: 'POST', body: JSON.stringify({ items }) });
        if (clearCart) saveCart([]);
        showCartCount();
        msg(`Order ${result.data?.orderId ?? ''} placed. It is waiting for Admin verification.`);
        render('My Orders');
    } catch (error) { msg(error.message, true); }
}
function showCartCount() {
    const button = [...document.querySelectorAll('#nav button')].find(x => x.dataset.tab === 'Cart');
    if (button) button.textContent = `Cart${getCart().length ? ` (${getCart().length})` : ''}`;
}
window.orderAction = async (id, action) => {
    try {
        await api(`/api/orders/${id}/${action}`, { method: 'PUT' });
        msg(`Order ${action === 'verify' ? 'verified' : 'rejected'} successfully.`);
        render(tab);
    } catch (error) { msg(error.message, true); }
};
window.pickup = async id => {
    if (!confirm(`Finalize pickup for order ${id}? This will deduct its reserved quantity from physical stock.`)) return;
    try {
        await api(`/api/orders/${id}/finalize-pickup`, { method: 'POST' });
        msg('Pickup finalized. Stock has been processed.');
        render(tab);
    } catch (error) { msg(error.message, true); }
};
window.pay = async id => {
    if (!confirm(`Proceed with simulated payment for order ${id}?`)) return;
    try {
        const result = await api('/api/payments', { method: 'POST', body: JSON.stringify({
            orderId: id, paymentMethod: 'Simulated', idempotencyKey: crypto.randomUUID(), simulateFailure: false
        }) });
        msg(result.message || 'Payment processed.');
        render('My Orders');
    } catch (error) { msg(error.message, true); }
};
window.invoice = async id => {
    try {
        const response = await fetch(`/api/invoices/${id}`, { headers: { Authorization: `Bearer ${token}` } });
        if (!response.ok) {
            const body = await response.json().catch(() => ({}));
            throw new Error(body.message || 'Invoice unavailable.');
        }
        const blob = await response.blob();
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url; link.download = `Invoice-${id}.pdf`; link.click();
        URL.revokeObjectURL(url);
    } catch (error) { msg(error.message, true); }
};

function updateReportFields() {
    const period = $('#reportPeriod').value;
    $('#reportDateWrap').classList.toggle('hidden', period !== 'daily');
    $('#reportMonthWrap').classList.toggle('hidden', period !== 'monthly');
    $('#reportYearWrap').classList.toggle('hidden', period !== 'yearly');
}
window.loadReport = async () => {
    try {
        const period = $('#reportPeriod').value;
        let result;
        if (period === 'daily') {
            const date = $('#reportDate').value;
            const response = await api(`/api/reports/generate/daily?date=${encodeURIComponent(date)}`, { method: 'POST' });
            result = response.data;
            result.period = date;
        } else if (period === 'monthly') {
            const [year, month] = $('#reportMonth').value.split('-');
            result = await api(`/api/reports/monthly-summary?year=${year}&month=${Number(month)}`);
            result.period = `${year}-${month}`;
        } else {
            const year = $('#reportYear').value;
            result = await api(`/api/reports/yearly?year=${year}`);
            result.period = year;
        }
        $('#reportData').innerHTML = `<div class="grid">
            <div class="card"><span class="muted">Report period</span><div class="metric" style="font-size:22px">${esc(result.period)}</div></div>
            <div class="card"><span class="muted">Total orders</span><div class="metric">${result.totalOrders}</div></div>
            <div class="card"><span class="muted">Total sales</span><div class="metric">${money(result.totalSales)}</div></div>
        </div><p class="muted">Sales include orders with successful payment status. The report period is based on the order date because the approved schema does not store payment timestamps.</p>`;
    } catch (error) {
        $('#reportData').innerHTML = `<div class="empty">${esc(error.message)}</div>`;
    }
};

document.addEventListener('keydown', event => { if (event.key === 'Escape' && quantitySelection) closeQuantityDialog(); });

if (token && me) showApp();
