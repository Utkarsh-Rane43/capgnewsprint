using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using Pharmacy.Orders;

namespace Pharmacy.Orders.Data;

public sealed class OrderDbFactory : IDesignTimeDbContextFactory<OrderDb>
{
    public OrderDb CreateDbContext(string[] args)
    {
        var configuration = new ConfigurationBuilder()
            .SetBasePath(AppContext.BaseDirectory)
            .AddJsonFile("appsettings.json", optional: false)
            .AddEnvironmentVariables()
            .Build();

        var connectionString = configuration.GetConnectionString("Default")
            ?? throw new InvalidOperationException("Connection string 'Default' is missing.");

        var options = new DbContextOptionsBuilder<OrderDb>()
            .UseSqlServer(connectionString)
            .Options;

        return new OrderDb(options);
    }
}
