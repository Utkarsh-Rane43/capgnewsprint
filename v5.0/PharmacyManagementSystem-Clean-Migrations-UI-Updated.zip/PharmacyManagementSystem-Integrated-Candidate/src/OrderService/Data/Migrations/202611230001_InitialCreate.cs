using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.EntityFrameworkCore;
using Pharmacy.Orders;
using Pharmacy.Orders.Data;

namespace Pharmacy.Orders.Data.Migrations;

[DbContext(typeof(OrderDb))]
[Migration("202611230001_InitialCreate")]
public sealed class InitialCreate : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.Sql(@"CREATE TABLE [Orders] (
 [OrderId] INT IDENTITY(1,1) NOT NULL CONSTRAINT [PK_Orders] PRIMARY KEY,
 [UserId] INT NOT NULL,
 [OrderDate] DATETIME NOT NULL,
 [TotalAmount] DECIMAL(10,2) NOT NULL,
 [OrderStatus] NVARCHAR(20) NOT NULL
);
CREATE TABLE [OrderItems] (
 [OrderItemId] INT IDENTITY(1,1) NOT NULL CONSTRAINT [PK_OrderItems] PRIMARY KEY,
 [OrderId] INT NOT NULL,
 [DrugId] INT NOT NULL,
 [Quantity] INT NOT NULL,
 [UnitPrice] DECIMAL(10,2) NOT NULL,
 [SubTotal] DECIMAL(10,2) NOT NULL,
 CONSTRAINT [FK_OrderItems_Orders_OrderId] FOREIGN KEY ([OrderId]) REFERENCES [Orders]([OrderId]) ON DELETE CASCADE
);
CREATE INDEX [IX_OrderItems_OrderId] ON [OrderItems]([OrderId]);");
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.Sql(@"DROP TABLE [OrderItems]; DROP TABLE [Orders];");
    }
}
