using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.EntityFrameworkCore.Metadata;
using Pharmacy.Orders;

namespace Pharmacy.Orders.Data.Migrations;

[DbContext(typeof(OrderDb))]
partial class OrderDbModelSnapshot : ModelSnapshot
{
    protected override void BuildModel(ModelBuilder modelBuilder)
    {
        modelBuilder.HasAnnotation("ProductVersion", "10.0.15")
            .HasAnnotation("Relational:MaxIdentifierLength", 128);
        Microsoft.EntityFrameworkCore.SqlServerModelBuilderExtensions.UseIdentityColumns(modelBuilder);
        modelBuilder.Entity<Pharmacy.Orders.Order>(b =>
{
    b.Property<int>("OrderId").ValueGeneratedOnAdd().HasColumnType("int");
    Microsoft.EntityFrameworkCore.SqlServerPropertyBuilderExtensions.UseIdentityColumn(b.Property<int>("OrderId"));
    b.Property<int>("UserId").HasColumnType("int");
    b.Property<DateTime>("OrderDate").HasColumnType("datetime");
    b.Property<decimal>("TotalAmount").HasPrecision(10,2).HasColumnType("decimal(10,2)");
    b.Property<string>("OrderStatus").IsRequired().HasMaxLength(20).HasColumnType("nvarchar(20)");
    b.HasKey("OrderId"); b.ToTable("Orders");
});
modelBuilder.Entity<Pharmacy.Orders.OrderItem>(b =>
{
    b.Property<int>("OrderItemId").ValueGeneratedOnAdd().HasColumnType("int");
    Microsoft.EntityFrameworkCore.SqlServerPropertyBuilderExtensions.UseIdentityColumn(b.Property<int>("OrderItemId"));
    b.Property<int>("OrderId").HasColumnType("int");
    b.Property<int>("DrugId").HasColumnType("int");
    b.Property<int>("Quantity").HasColumnType("int");
    b.Property<decimal>("UnitPrice").HasPrecision(10,2).HasColumnType("decimal(10,2)");
    b.Property<decimal>("SubTotal").HasPrecision(10,2).HasColumnType("decimal(10,2)");
    b.HasKey("OrderItemId"); b.HasIndex("OrderId"); b.ToTable("OrderItems");
});
modelBuilder.Entity<Pharmacy.Orders.OrderItem>().HasOne<Pharmacy.Orders.Order>().WithMany("Items").HasForeignKey("OrderId").OnDelete(DeleteBehavior.Cascade).IsRequired();
    }
}
