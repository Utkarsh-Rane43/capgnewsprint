using System.Net;
using System.Net.Mail;
namespace Pharmacy.Notify;
public class EmailSender(IConfiguration config)
{
    public async Task Send(string to, string subject, string body, string? attachmentFileName = null, string? attachmentBase64 = null)
    {
        var host = config["Smtp:Host"];
        var from = config["Smtp:From"];
        if (string.IsNullOrWhiteSpace(host) || string.IsNullOrWhiteSpace(from)) throw new InvalidOperationException("SMTP is not configured. Set Smtp:Host and Smtp:From.");
        using var message = new MailMessage(from, to, subject, body);
        MemoryStream? attachmentStream = null;
        if (!string.IsNullOrWhiteSpace(attachmentFileName) && !string.IsNullOrWhiteSpace(attachmentBase64))
        {
            attachmentStream = new MemoryStream(Convert.FromBase64String(attachmentBase64));
            message.Attachments.Add(new Attachment(attachmentStream, Path.GetFileName(attachmentFileName), "application/pdf"));
        }
        using var client = new SmtpClient(host, int.TryParse(config["Smtp:Port"], out var port) ? port : 587)
        {
            EnableSsl = bool.TryParse(config["Smtp:EnableSsl"], out var ssl) ? ssl : true,
            Credentials = new NetworkCredential(config["Smtp:Username"], config["Smtp:Password"])
        };
        try { await client.SendMailAsync(message); }
        finally { attachmentStream?.Dispose(); }
    }
}
