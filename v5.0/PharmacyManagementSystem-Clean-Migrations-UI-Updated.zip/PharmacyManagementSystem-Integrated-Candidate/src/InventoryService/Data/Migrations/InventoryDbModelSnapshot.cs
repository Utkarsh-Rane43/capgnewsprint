using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.EntityFrameworkCore.Metadata;
using Pharmacy.Inventory;

namespace Pharmacy.Inventory.Data.Migrations;

[DbContext(typeof(InventoryDb))]
partial class InventoryDbModelSnapshot : ModelSnapshot
{
    protected override void BuildModel(ModelBuilder modelBuilder)
    {
        modelBuilder.HasAnnotation("ProductVersion", "10.0.15")
            .HasAnnotation("Relational:MaxIdentifierLength", 128);
        Microsoft.EntityFrameworkCore.SqlServerModelBuilderExtensions.UseIdentityColumns(modelBuilder);
        modelBuilder.Entity<Pharmacy.Inventory.Supplier>(b =>
{
    b.Property<int>("SupplierId").ValueGeneratedOnAdd().HasColumnType("int");
    Microsoft.EntityFrameworkCore.SqlServerPropertyBuilderExtensions.UseIdentityColumn(b.Property<int>("SupplierId"));
    b.Property<string>("SupplierName").IsRequired().HasMaxLength(100).HasColumnType("nvarchar(100)");
    b.Property<string>("Email").IsRequired().HasMaxLength(150).HasColumnType("nvarchar(150)");
    b.Property<string>("Phone").IsRequired().HasMaxLength(20).HasColumnType("nvarchar(20)");
    b.Property<string>("Address").IsRequired().HasMaxLength(255).HasColumnType("nvarchar(255)");
    b.HasKey("SupplierId"); b.ToTable("Suppliers");
});
modelBuilder.Entity<Pharmacy.Inventory.Drug>(b =>
{
    b.Property<int>("DrugId").ValueGeneratedOnAdd().HasColumnType("int");
    Microsoft.EntityFrameworkCore.SqlServerPropertyBuilderExtensions.UseIdentityColumn(b.Property<int>("DrugId"));
    b.Property<string>("DrugName").IsRequired().HasMaxLength(100).HasColumnType("nvarchar(100)");
    b.Property<string>("Manufacturer").IsRequired().HasMaxLength(100).HasColumnType("nvarchar(100)");
    b.Property<decimal>("Price").HasPrecision(10,2).HasColumnType("decimal(10,2)");
    b.Property<DateTime>("ExpiryDate").HasColumnType("date");
    b.Property<int>("SupplierId").HasColumnType("int");
    b.HasKey("DrugId"); b.HasIndex("SupplierId"); b.ToTable("Drugs");
});
modelBuilder.Entity<Pharmacy.Inventory.Stock>(b =>
{
    b.Property<int>("InventoryId").ValueGeneratedOnAdd().HasColumnType("int");
    Microsoft.EntityFrameworkCore.SqlServerPropertyBuilderExtensions.UseIdentityColumn(b.Property<int>("InventoryId"));
    b.Property<int>("DrugId").HasColumnType("int");
    b.Property<int>("AvailableQuantity").HasColumnType("int");
    b.Property<int>("ReservedQuantity").HasColumnType("int");
    b.HasKey("InventoryId"); b.HasIndex("DrugId").IsUnique(); b.ToTable("Inventory");
});
modelBuilder.Entity<Pharmacy.Inventory.Drug>().HasOne<Pharmacy.Inventory.Supplier>().WithMany().HasForeignKey("SupplierId").OnDelete(DeleteBehavior.Restrict).IsRequired();
modelBuilder.Entity<Pharmacy.Inventory.Stock>().HasOne<Pharmacy.Inventory.Drug>().WithMany().HasForeignKey("DrugId").OnDelete(DeleteBehavior.Restrict).IsRequired();
    }
}
