using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.EntityFrameworkCore;
using Pharmacy.Inventory;
using Pharmacy.Inventory.Data;

namespace Pharmacy.Inventory.Data.Migrations;

[DbContext(typeof(InventoryDb))]
[Migration("202611230001_InitialCreate")]
public sealed class InitialCreate : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.Sql(@"CREATE TABLE [Suppliers] (
 [SupplierId] INT IDENTITY(1,1) NOT NULL CONSTRAINT [PK_Suppliers] PRIMARY KEY,
 [SupplierName] NVARCHAR(100) NOT NULL,
 [Email] NVARCHAR(150) NOT NULL,
 [Phone] NVARCHAR(20) NOT NULL,
 [Address] NVARCHAR(255) NOT NULL
);
CREATE TABLE [Drugs] (
 [DrugId] INT IDENTITY(1,1) NOT NULL CONSTRAINT [PK_Drugs] PRIMARY KEY,
 [DrugName] NVARCHAR(100) NOT NULL,
 [Manufacturer] NVARCHAR(100) NOT NULL,
 [Price] DECIMAL(10,2) NOT NULL,
 [ExpiryDate] DATE NOT NULL,
 [SupplierId] INT NOT NULL,
 CONSTRAINT [FK_Drugs_Suppliers_SupplierId] FOREIGN KEY ([SupplierId]) REFERENCES [Suppliers]([SupplierId]) ON DELETE NO ACTION
);
CREATE INDEX [IX_Drugs_SupplierId] ON [Drugs]([SupplierId]);
CREATE TABLE [Inventory] (
 [InventoryId] INT IDENTITY(1,1) NOT NULL CONSTRAINT [PK_Inventory] PRIMARY KEY,
 [DrugId] INT NOT NULL,
 [AvailableQuantity] INT NOT NULL,
 [ReservedQuantity] INT NOT NULL,
 CONSTRAINT [FK_Inventory_Drugs_DrugId] FOREIGN KEY ([DrugId]) REFERENCES [Drugs]([DrugId]) ON DELETE NO ACTION
);
CREATE UNIQUE INDEX [IX_Inventory_DrugId] ON [Inventory]([DrugId]);");
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.Sql(@"DROP TABLE [Inventory]; DROP TABLE [Drugs]; DROP TABLE [Suppliers];");
    }
}
