using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using Pharmacy.Inventory;

namespace Pharmacy.Inventory.Data;

public sealed class InventoryDbFactory : IDesignTimeDbContextFactory<InventoryDb>
{
    public InventoryDb CreateDbContext(string[] args)
    {
        var configuration = new ConfigurationBuilder()
            .SetBasePath(AppContext.BaseDirectory)
            .AddJsonFile("appsettings.json", optional: false)
            .AddEnvironmentVariables()
            .Build();

        var connectionString = configuration.GetConnectionString("Default")
            ?? throw new InvalidOperationException("Connection string 'Default' is missing.");

        var options = new DbContextOptionsBuilder<InventoryDb>()
            .UseSqlServer(connectionString)
            .Options;

        return new InventoryDb(options);
    }
}
