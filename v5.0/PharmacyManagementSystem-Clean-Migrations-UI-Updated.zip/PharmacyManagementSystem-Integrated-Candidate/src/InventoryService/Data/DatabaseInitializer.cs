using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace Pharmacy.Inventory.Data;

public static class DatabaseInitializer
{
    public static async Task InitializeAsync<TContext>(IServiceProvider services, IConfiguration configuration)
        where TContext : DbContext
    {
        var connectionString = configuration.GetConnectionString("Default")
            ?? throw new InvalidOperationException("Connection string 'Default' is missing.");

        var builder = new SqlConnectionStringBuilder(connectionString);
        var databaseName = builder.InitialCatalog;
        if (string.IsNullOrWhiteSpace(databaseName))
            throw new InvalidOperationException("The SQL Server connection string must specify a database name.");

        // Create the empty database first, then let EF Core apply its versioned migrations.
        var masterBuilder = new SqlConnectionStringBuilder(connectionString) { InitialCatalog = "master" };
        await using (var connection = new SqlConnection(masterBuilder.ConnectionString))
        {
            await connection.OpenAsync();
            var safeName = "[" + databaseName.Replace("]", "]]") + "]";
            var escapedName = databaseName.Replace("'", "''");
            await using var command = connection.CreateCommand();
            command.CommandText = $"IF DB_ID(N'{escapedName}') IS NULL CREATE DATABASE {safeName};";
            await command.ExecuteNonQueryAsync();
        }

        await using var scope = services.CreateAsyncScope();
        var db = scope.ServiceProvider.GetRequiredService<TContext>();
        await db.Database.MigrateAsync();
    }
}
