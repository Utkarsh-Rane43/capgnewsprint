using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.EntityFrameworkCore.Metadata;
using Pharmacy.Reports;

namespace Pharmacy.Reports.Data.Migrations;

[DbContext(typeof(ReportDb))]
partial class ReportDbModelSnapshot : ModelSnapshot
{
    protected override void BuildModel(ModelBuilder modelBuilder)
    {
        modelBuilder.HasAnnotation("ProductVersion", "10.0.15")
            .HasAnnotation("Relational:MaxIdentifierLength", 128);
        Microsoft.EntityFrameworkCore.SqlServerModelBuilderExtensions.UseIdentityColumns(modelBuilder);
        modelBuilder.Entity<Pharmacy.Reports.SalesReport>(b =>
{
    b.Property<int>("ReportId").ValueGeneratedOnAdd().HasColumnType("int");
    Microsoft.EntityFrameworkCore.SqlServerPropertyBuilderExtensions.UseIdentityColumn(b.Property<int>("ReportId"));
    b.Property<DateTime>("ReportDate").HasColumnType("date");
    b.Property<int>("TotalOrders").HasColumnType("int");
    b.Property<decimal>("TotalSales").HasPrecision(10,2).HasColumnType("decimal(10,2)");
    b.HasKey("ReportId"); b.ToTable("SalesReports");
});
    }
}
