using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.EntityFrameworkCore;
using Pharmacy.Reports;
using Pharmacy.Reports.Data;

namespace Pharmacy.Reports.Data.Migrations;

[DbContext(typeof(ReportDb))]
[Migration("202611230001_InitialCreate")]
public sealed class InitialCreate : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.Sql(@"CREATE TABLE [SalesReports] (
 [ReportId] INT IDENTITY(1,1) NOT NULL CONSTRAINT [PK_SalesReports] PRIMARY KEY,
 [ReportDate] DATE NOT NULL,
 [TotalOrders] INT NOT NULL,
 [TotalSales] DECIMAL(10,2) NOT NULL
);");
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.Sql(@"DROP TABLE [SalesReports];");
    }
}
