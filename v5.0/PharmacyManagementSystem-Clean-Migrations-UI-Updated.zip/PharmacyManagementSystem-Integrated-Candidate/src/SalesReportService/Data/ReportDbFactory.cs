using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using Pharmacy.Reports;

namespace Pharmacy.Reports.Data;

public sealed class ReportDbFactory : IDesignTimeDbContextFactory<ReportDb>
{
    public ReportDb CreateDbContext(string[] args)
    {
        var configuration = new ConfigurationBuilder()
            .SetBasePath(AppContext.BaseDirectory)
            .AddJsonFile("appsettings.json", optional: false)
            .AddEnvironmentVariables()
            .Build();

        var connectionString = configuration.GetConnectionString("Default")
            ?? throw new InvalidOperationException("Connection string 'Default' is missing.");

        var options = new DbContextOptionsBuilder<ReportDb>()
            .UseSqlServer(connectionString)
            .Options;

        return new ReportDb(options);
    }
}
