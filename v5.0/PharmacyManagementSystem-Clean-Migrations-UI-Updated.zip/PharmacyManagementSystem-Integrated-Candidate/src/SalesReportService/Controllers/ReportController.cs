using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using System.Net.Http.Json;
namespace Pharmacy.Reports;
[ApiController, Route("api/reports"), Authorize(Roles = "Admin")]
public class ReportController(ReportDb db, IHttpClientFactory clients, IConfiguration config) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> All() => Ok(await db.SalesReports.OrderByDescending(x => x.ReportDate).ToListAsync());
    [HttpGet("daily")]
    public async Task<IActionResult> Daily([FromQuery] DateTime? date)
    {
        var day = (date ?? DateTime.Today).Date;
        return Ok(await db.SalesReports.SingleOrDefaultAsync(x => x.ReportDate == day));
    }
    [HttpGet("monthly")]
    public async Task<IActionResult> Monthly([FromQuery] int? year, [FromQuery] int? month)
    {
        var y = year ?? DateTime.Today.Year; var m = month ?? DateTime.Today.Month;
        if (m is < 1 or > 12) return BadRequest(new { message = "Month must be between 1 and 12." });
        var start = new DateTime(y, m, 1); var end = start.AddMonths(1);
        var rows = await db.SalesReports.Where(x => x.ReportDate >= start && x.ReportDate < end).ToListAsync();
        return Ok(new { year = y, month = m, totalOrders = rows.Sum(x => x.TotalOrders), totalSales = rows.Sum(x => x.TotalSales), days = rows });
    }
    [HttpPost("generate/daily")]
    public async Task<IActionResult> GenerateDaily([FromQuery] DateTime? date)
    {
        var day = (date ?? DateTime.Today).Date;
        var client = clients.CreateClient("Orders");
        using var request = new HttpRequestMessage(HttpMethod.Get, $"/internal/orders/sales-summary?from={day:yyyy-MM-dd}&to={day:yyyy-MM-dd}");
        request.Headers.Add("X-Internal-Key", config["Internal:ServiceKey"] ?? "");
        var response = await client.SendAsync(request);
        if (!response.IsSuccessStatusCode) return StatusCode(502, new { message = "Could not retrieve sales totals from Order Service." });
        var totals = await response.Content.ReadFromJsonAsync<SalesSummaryDto>();
        if (totals is null) return StatusCode(502, new { message = "Order Service returned an invalid sales summary." });
        var row = await db.SalesReports.SingleOrDefaultAsync(x => x.ReportDate == day);
        if (row is null) { row = new SalesReport { ReportDate = day }; db.SalesReports.Add(row); }
        row.TotalOrders = totals.TotalOrders; row.TotalSales = totals.TotalSales;
        await db.SaveChangesAsync();
        return Ok(new { success = true, message = "Daily sales report generated", data = row });
    }
    [HttpGet("yearly")]
    public async Task<IActionResult> Yearly([FromQuery] int? year)
    {
        var y = year ?? DateTime.Today.Year;
        if (y < 2000 || y > 2100) return BadRequest(new { message = "Provide a valid year." });
        var summary = await ReadOrderSummaryAsync(new DateTime(y, 1, 1), new DateTime(y + 1, 1, 1).AddDays(-1));
        if (summary is null) return StatusCode(502, new { message = "Could not retrieve annual totals from Order Service." });
        return Ok(new { year = y, totalOrders = summary.TotalOrders, totalSales = summary.TotalSales });
    }

    [HttpGet("monthly-summary")]
    public async Task<IActionResult> MonthlySummary([FromQuery] int? year, [FromQuery] int? month)
    {
        var y = year ?? DateTime.Today.Year; var m = month ?? DateTime.Today.Month;
        if (m is < 1 or > 12 || y < 2000 || y > 2100) return BadRequest(new { message = "Provide a valid year and month." });
        var start = new DateTime(y, m, 1);
        var summary = await ReadOrderSummaryAsync(start, start.AddMonths(1).AddDays(-1));
        if (summary is null) return StatusCode(502, new { message = "Could not retrieve monthly totals from Order Service." });
        return Ok(new { year = y, month = m, totalOrders = summary.TotalOrders, totalSales = summary.TotalSales });
    }

    private async Task<SalesSummaryDto?> ReadOrderSummaryAsync(DateTime from, DateTime to)
    {
        var client = clients.CreateClient("Orders");
        using var request = new HttpRequestMessage(HttpMethod.Get,
            $"/internal/orders/sales-summary?from={from:yyyy-MM-dd}&to={to:yyyy-MM-dd}");
        request.Headers.Add("X-Internal-Key", config["Internal:ServiceKey"] ?? "");
        var response = await client.SendAsync(request);
        if (!response.IsSuccessStatusCode) return null;
        return await response.Content.ReadFromJsonAsync<SalesSummaryDto>();
    }

    [HttpPost]
    public async Task<IActionResult> SaveDailyReport(ReportIngest request)
    {
        if (request.TotalOrders < 0 || request.TotalSales < 0) return BadRequest(new { message = "Report totals cannot be negative." });
        var date = request.ReportDate.Date;
        var row = await db.SalesReports.SingleOrDefaultAsync(x => x.ReportDate == date);
        if (row is null) { row = new SalesReport { ReportDate = date }; db.SalesReports.Add(row); }
        row.TotalOrders = request.TotalOrders; row.TotalSales = request.TotalSales;
        await db.SaveChangesAsync();
        return Ok(new { success = true, message = "Sales report saved", data = row });
    }
}
public record ReportIngest(DateTime ReportDate, int TotalOrders, decimal TotalSales);
public record SalesSummaryDto(int TotalOrders, decimal TotalSales);
