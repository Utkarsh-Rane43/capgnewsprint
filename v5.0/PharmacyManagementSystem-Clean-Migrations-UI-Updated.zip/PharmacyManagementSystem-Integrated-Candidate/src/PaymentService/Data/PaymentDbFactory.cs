using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using Pharmacy.Payments;

namespace Pharmacy.Payments.Data;

public sealed class PaymentDbFactory : IDesignTimeDbContextFactory<PaymentDb>
{
    public PaymentDb CreateDbContext(string[] args)
    {
        var configuration = new ConfigurationBuilder()
            .SetBasePath(AppContext.BaseDirectory)
            .AddJsonFile("appsettings.json", optional: false)
            .AddEnvironmentVariables()
            .Build();

        var connectionString = configuration.GetConnectionString("Default")
            ?? throw new InvalidOperationException("Connection string 'Default' is missing.");

        var options = new DbContextOptionsBuilder<PaymentDb>()
            .UseSqlServer(connectionString)
            .Options;

        return new PaymentDb(options);
    }
}
