using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.EntityFrameworkCore.Metadata;
using Pharmacy.Payments;

namespace Pharmacy.Payments.Data.Migrations;

[DbContext(typeof(PaymentDb))]
partial class PaymentDbModelSnapshot : ModelSnapshot
{
    protected override void BuildModel(ModelBuilder modelBuilder)
    {
        modelBuilder.HasAnnotation("ProductVersion", "10.0.15")
            .HasAnnotation("Relational:MaxIdentifierLength", 128);
        Microsoft.EntityFrameworkCore.SqlServerModelBuilderExtensions.UseIdentityColumns(modelBuilder);
        modelBuilder.Entity<Pharmacy.Payments.Payment>(b =>
{
    b.Property<int>("PaymentId").ValueGeneratedOnAdd().HasColumnType("int");
    Microsoft.EntityFrameworkCore.SqlServerPropertyBuilderExtensions.UseIdentityColumn(b.Property<int>("PaymentId"));
    b.Property<int>("OrderId").HasColumnType("int");
    b.Property<decimal>("Amount").HasPrecision(10,2).HasColumnType("decimal(10,2)");
    b.Property<string>("PaymentStatus").IsRequired().HasMaxLength(20).HasColumnType("nvarchar(20)");
    b.Property<string>("TransactionReference").IsRequired().HasMaxLength(100).HasColumnType("nvarchar(100)");
    b.HasKey("PaymentId"); b.HasIndex("TransactionReference").IsUnique(); b.ToTable("Payments");
});
    }
}
