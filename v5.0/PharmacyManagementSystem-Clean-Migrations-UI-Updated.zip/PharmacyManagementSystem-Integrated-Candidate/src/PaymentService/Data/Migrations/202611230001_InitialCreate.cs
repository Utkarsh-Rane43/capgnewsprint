using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.EntityFrameworkCore;
using Pharmacy.Payments;
using Pharmacy.Payments.Data;

namespace Pharmacy.Payments.Data.Migrations;

[DbContext(typeof(PaymentDb))]
[Migration("202611230001_InitialCreate")]
public sealed class InitialCreate : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.Sql(@"CREATE TABLE [Payments] (
 [PaymentId] INT IDENTITY(1,1) NOT NULL CONSTRAINT [PK_Payments] PRIMARY KEY,
 [OrderId] INT NOT NULL,
 [Amount] DECIMAL(10,2) NOT NULL,
 [PaymentStatus] NVARCHAR(20) NOT NULL,
 [TransactionReference] NVARCHAR(100) NOT NULL
);
CREATE UNIQUE INDEX [IX_Payments_TransactionReference] ON [Payments]([TransactionReference]);");
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.Sql(@"DROP TABLE [Payments];");
    }
}
