$ErrorActionPreference = 'Stop'
Set-Location (Split-Path -Parent $PSScriptRoot)
dotnet tool restore
if ($LASTEXITCODE -ne 0) { throw 'Could not restore the local dotnet-ef tool.' }

$services = @('AuthService','InventoryService','OrderService','PaymentService','SalesReportService')
foreach ($service in $services) {
    $project = "src/$service/$service.csproj"
    Write-Host "`n=== $service ===" -ForegroundColor Cyan
    dotnet ef migrations list --project $project --startup-project $project
    if ($LASTEXITCODE -ne 0) { throw "Could not list migrations for $service." }
}
