param(
    [Parameter(Mandatory = $true)]
    [ValidateSet('AuthService','InventoryService','OrderService','PaymentService','SalesReportService')]
    [string]$Service,

    [Parameter(Mandatory = $true)]
    [ValidatePattern('^[A-Za-z][A-Za-z0-9]*$')]
    [string]$Name
)

$ErrorActionPreference = 'Stop'
Set-Location (Split-Path -Parent $PSScriptRoot)
dotnet tool restore
if ($LASTEXITCODE -ne 0) { throw 'Could not restore the local dotnet-ef tool.' }

$project = "src/$Service/$Service.csproj"
dotnet ef migrations add $Name --project $project --startup-project $project --output-dir Data/Migrations
if ($LASTEXITCODE -ne 0) { throw "Could not create migration '$Name' for $Service." }
Write-Host "Migration '$Name' created for $Service." -ForegroundColor Green
