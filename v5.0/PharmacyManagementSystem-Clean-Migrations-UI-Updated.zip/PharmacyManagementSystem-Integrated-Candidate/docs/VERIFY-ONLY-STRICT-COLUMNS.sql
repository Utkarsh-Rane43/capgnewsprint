-- Run after services have started and EF EnsureCreated has created the tables.
-- This is a read-only verification query; it does not create, alter or drop anything.
SELECT DB_NAME() AS CurrentDatabase;
SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH, NUMERIC_PRECISION, NUMERIC_SCALE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME IN ('Users','Suppliers','Drugs','Inventory','Orders','OrderItems','Payments','SalesReports')
ORDER BY TABLE_NAME, ORDINAL_POSITION;
