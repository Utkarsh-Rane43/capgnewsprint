# Authoritative database schema

The supplied user database diagram is the only authority for persisted columns. There are exactly five databases and eight tables. SQL is used only to create the five databases. Each service creates its tables from its EF Core model on first startup (`EnsureCreated`). Application CRUD and queries use EF Core/LINQ.

## UserDB — Auth Service
`Users(UserId INT PK, FullName VARCHAR(100), Email VARCHAR(150), PasswordHash VARCHAR(255), Role VARCHAR(20), IsActive BIT)`

## InventoryDB — Inventory Service
- `Suppliers(SupplierId INT PK, SupplierName VARCHAR(100), Email VARCHAR(150), Phone VARCHAR(20), Address VARCHAR(255))`
- `Drugs(DrugId INT PK, DrugName VARCHAR(100), Manufacturer VARCHAR(100), Price DECIMAL(10,2), ExpiryDate DATE, SupplierId INT)`
- `Inventory(InventoryId INT PK, DrugId INT, AvailableQuantity INT, ReservedQuantity INT)`

## OrderDB — Order Service
- `Orders(OrderId INT PK, UserId INT, OrderDate DATETIME, TotalAmount DECIMAL(10,2), OrderStatus VARCHAR(20))`
- `OrderItems(OrderItemId INT PK, OrderId INT, DrugId INT, Quantity INT, UnitPrice DECIMAL(10,2), SubTotal DECIMAL(10,2))`

## PaymentDB — Payment Service
`Payments(PaymentId INT PK, OrderId INT, Amount DECIMAL(10,2), PaymentStatus VARCHAR(20), TransactionReference VARCHAR(100))`

## ReportDB — Sales Report Service
`SalesReports(ReportId INT PK, ReportDate DATE, TotalOrders INT, TotalSales DECIMAL(10,2))`

There are no cross-database SQL foreign keys. IDs crossing service boundaries are logical references validated through service APIs. No additional persisted properties are permitted. PaymentMethod and IdempotencyKey are request-only values; a deterministic reference is stored in TransactionReference.
