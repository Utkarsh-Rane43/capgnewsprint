# Admin and Doctor registration

Both roles use `POST /api/auth/register`. Doctor registration is open. Admin registration requires `AdminInvitationCode` matching `Registration:AdminInvitationCode` in Auth Service configuration. The invitation code is not stored in the database.

Development invitation code currently configured at the user's request: `8446573592`. Rotate it before real deployment and do not expose it in a public client.

Doctor example:
```json
{ "fullName":"Test Doctor", "email":"doctor@example.com", "password":"ChangeMe123!", "role":"Doctor" }
```

Admin example:
```json
{ "fullName":"System Administrator", "email":"admin@pharmacy.local", "password":"ChangeMe123!", "role":"Admin", "adminInvitationCode":"8446573592" }
```
