# SMTP configuration

Configure Notification Service `appsettings.json` or user secrets/environment variables with `Smtp:Host`, `Smtp:Port`, `Smtp:EnableSsl`, `Smtp:Username`, `Smtp:Password`, and `Smtp:From`. Do not commit real SMTP credentials. The Notification Service exposes `POST /api/notifications/email`. Use a provider app password where required. Test delivery using a mailbox you control.

Note: SMTP configuration and basic email notification are included. Verify the invoice-attachment workflow separately; do not assume that a successful payment email proves a PDF attachment was delivered.
