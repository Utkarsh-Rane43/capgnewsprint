# Pharmacy Management System — agreed requirements baseline

## Architecture
- .NET 10 / C# ASP.NET Core Web API, six services: Auth, Inventory, Order, Payment, Sales Report, Notification.
- YARP API Gateway, JWT, role-based authorization, REST/JSON, Swagger, NUnit.
- SQL Server LocalDB on Windows; no Docker/cloud deployment.
- EF Core for persistence and schema creation; LINQ for application queries. SQL scripts are for creating the five empty databases only.

## Strict database diagram (exactly eight core tables)
- UserDB.Users: UserId INT PK, FullName VARCHAR(100), Email VARCHAR(150), PasswordHash VARCHAR(255), Role VARCHAR(20), IsActive BOOLEAN/BIT. No Phone.
- InventoryDB.Suppliers: SupplierId INT PK, SupplierName VARCHAR(100), Email VARCHAR(150), Phone VARCHAR(20), Address VARCHAR(255).
- InventoryDB.Drugs: DrugId INT PK, DrugName VARCHAR(100), Manufacturer VARCHAR(100), Price DECIMAL(10,2), ExpiryDate DATE, SupplierId INT.
- InventoryDB.Inventory: InventoryId INT PK, DrugId INT, AvailableQuantity INT, ReservedQuantity INT.
- OrderDB.Orders: OrderId INT PK, UserId INT, OrderDate DATETIME, TotalAmount DECIMAL(10,2), OrderStatus VARCHAR(20).
- OrderDB.OrderItems: OrderItemId INT PK, OrderId INT, DrugId INT, Quantity INT, UnitPrice DECIMAL(10,2), SubTotal DECIMAL(10,2).
- PaymentDB.Payments: PaymentId INT PK, OrderId INT, Amount DECIMAL(10,2), PaymentStatus VARCHAR(20), TransactionReference VARCHAR(100).
- ReportDB.SalesReports: ReportId INT PK, ReportDate DATE, TotalOrders INT, TotalSales DECIMAL(10,2).
- Cross-service IDs are logical/API references; do not create cross-database foreign keys.

## Registration and security
- One POST /api/auth/register for Doctor and Admin. Doctor public registration; Admin requires configured invitation code. Never store invitation code in UserDB. Do not permit arbitrary role escalation.
- Admin invitation code currently appears in local development configuration as agreed; treat as development-only and rotate before deployment.
- Passwords hashed; JWT contains user ID, email and role.

## Business flow
1. Admin registers suppliers.
2. Admin adds drugs linked to existing SupplierId and initial inventory record.
3. Doctor browses drugs and available inventory, creates order.
4. Order Service validates medicine/price and reserves stock; order PendingVerification.
5. Admin verifies or rejects. Rejection releases reserved stock.
6. Doctor pays only after verification. Payment is simulated; method/idempotency key are request-only. Persist deterministic transaction reference in Payments.TransactionReference.
7. Successful payment changes order to Paid; invoice is generated from order/payment data (no invoice table).
8. Admin finalizes pickup; reserved stock is deducted and order becomes PickedUp.
9. SMTP notifications for registration, order placed, verify/reject, payment success/failure and pickup; PDF invoice attached to successful-payment email.
10. Admin generates daily/monthly sales reports.

## Scope note
The previous source archives are references, not proof of a fully verified implementation. This package preserves the existing backend source and adds an integrated UI shell. Build, runtime, SMTP, invoice-email attachment, and full end-to-end workflows must be verified on a Windows machine with .NET 10 and SQL Server LocalDB before calling it production-ready or submission-ready.
