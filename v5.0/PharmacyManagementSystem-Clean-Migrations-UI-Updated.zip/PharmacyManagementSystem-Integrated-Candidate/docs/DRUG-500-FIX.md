# Fix included for POST /api/drugs

The earlier AddDrug action opened a manual EF Core transaction while SQL Server retry support (`EnableRetryOnFailure`) was enabled. EF Core rejects that combination unless the transaction is run through `Database.CreateExecutionStrategy()`.

The AddDrug action now runs the two related inserts inside the EF Core execution strategy:

1. Insert the Drug row.
2. Use the generated DrugId to insert its Inventory row.
3. Commit both changes together.

The request still accepts `InitialQuantity`; the API creates the initial Inventory row with that available quantity and a reserved quantity of zero. The database schema is unchanged.

## Retest on Windows

1. Stop the running services.
2. Extract this ZIP into a new folder (do not overwrite files while the old services are running).
3. Run `Build-Check.ps1` from PowerShell.
4. Run `Run-Local.bat`.
5. Log in again and use a fresh Admin token in Swagger.
6. Create a supplier first, then call `POST /api/drugs` with that supplier's real `SupplierId` and an `InitialQuantity` of zero or more.
7. Confirm the new medicine with `GET /api/drugs` and its stock with `GET /api/inventory`.

If the build succeeds but the API still returns an error, save the new Swagger response and Inventory Service terminal output. Do not delete or recreate the databases as a first troubleshooting step.

## Verification limitation

This patch was source-inspected and packaged, but could not be compiled or run in the file-generation environment because the .NET SDK is not installed there. Run `Build-Check.ps1` and the steps above on the Windows development machine before treating it as verified.
