# EF Core migrations and automatic database creation

## What changed

- Replaced `Database.EnsureCreated()` with `Database.MigrateAsync()`.
- Added an initial migration for each database-owning service.
- Added a model snapshot for each DbContext so later migrations can be scaffolded.
- Added a startup initializer that creates the configured database from `master` when it is absent.
- Each service owns its migration history and applies only its own migrations.

## Databases

| Service | Database | Tables in initial migration |
|---|---|---|
| Auth | UserDB | Users |
| Inventory | InventoryDB | Suppliers, Drugs, Inventory |
| Order | OrderDB | Orders, OrderItems |
| Payment | PaymentDB | Payments |
| Sales Report | ReportDB | SalesReports |

No cross-service foreign keys are created. Inventory's local relationships (Supplier → Drug and Drug → Inventory) and Order → OrderItems remain within their owning databases. The User table does not contain a phone-number column.

## First run

Run `dotnet tool restore`, then `Run-Local.bat`. The service processes create their databases and apply the included initial migrations automatically. The SQL Server account must be able to create databases. No separate SSMS script is needed.

## Existing database warning

EF Core cannot safely infer migration history for a database previously created with `EnsureCreated()`. Do not blindly start this migration-enabled version against valuable existing data: `__EFMigrationsHistory` will be absent even though tables may already exist, and the initial migration will attempt to create those tables again.

For an existing database:
1. Back up the database.
2. Confirm its schema matches the relevant initial migration.
3. Have a database administrator baseline the initial migration in `__EFMigrationsHistory`, or migrate the data into a clean migration-managed database.
4. Only then start the service.

The project does not automatically drop, reset or overwrite existing databases.

## Add a migration

```powershell
dotnet tool restore

dotnet ef migrations add AddYourChange `
  --project src/InventoryService/InventoryService.csproj `
  --startup-project src/InventoryService/InventoryService.csproj `
  --output-dir Data/Migrations
```

Use the matching project for Auth, Order, Payment or Sales Report. Startup applies new migrations automatically; `dotnet ef database update` can also be used for a manual development update.
