# Final feature upgrade notes

This upgrade is based on the previously working Pharmacy Management System project. It keeps the existing six services, YARP gateway, local SQL Server setup, JWT roles and the existing database tables/columns.

## Added and updated behaviour

- Doctor medicine catalogue now has separate **Add to Cart** and **Order Now** actions.
- The cart is kept in browser local storage per signed-in user. Doctors can change quantities and remove items before checkout.
- Adding an item to the cart does not reserve stock. The Order Service checks current stock and reserves it only when checkout submits the order.
- Admin can verify or reject pending orders. Rejection releases reserved stock.
- Doctor can pay only after verification. The payment is simulated and a failed attempt can be retried with a new idempotency key.
- Admin can finalize pickup for a paid order. This moves quantity out of reserved stock; available stock was already reduced when the order was reserved.
- Inventory includes a **Processed (paid)** display value. It is calculated from paid/picked-up OrderItems in OrderDB and is not a new InventoryDB column.
- Admin and Doctors have an Invoices page. Admin can download invoices for all paid/picked-up orders; Doctors can download their own.
- Invoice PDF now has a formatted heading, invoice number, order details, medicine rows, totals, payment status and transaction reference. It uses text and vector layout only; no images are embedded.
- Sales report screen supports daily, monthly and annual summaries.

## Database schema preservation

No database column or table was added. The five databases and eight core tables remain unchanged.

### Payment timestamp limitation

The approved `Payments` table does not contain a payment date/time column. Therefore, a true historical payment timestamp cannot be recovered or reliably shown on the invoice without changing the schema. The invoice explicitly says that the payment date/time is not recorded, and separately displays invoice generation time. It does not present the invoice generation time as if it were the payment time.

### Report date basis

Sales summaries use `Orders.OrderDate` and include orders in `Paid` or `PickedUp` status. Since the schema does not record payment time, reports cannot group by the exact time payment was captured.

## Processed stock meaning

`Processed (paid)` is the cumulative quantity on orders whose status is `Paid` or `PickedUp`. It is a reporting value derived from OrderDB, not an additional stock balance. `AvailableQuantity` and `ReservedQuantity` remain the only persisted stock quantities in InventoryDB.

## Run and test

1. Extract the ZIP to a new folder.
2. Keep the existing local databases; do not drop or recreate them.
3. Run `Build-Check.ps1` in PowerShell.
4. Run `Run-Local.bat`.
5. Sign in as Admin and verify that Inventory shows Available, Reserved and Processed (paid).
6. Sign in as Doctor, add two medicines to Cart, adjust a quantity, remove an item, and checkout.
7. Sign in as Admin, verify the order. Sign in as Doctor and pay.
8. Download the invoice as Doctor and as Admin.
9. Sign in as Admin and finalize pickup. Confirm reserved quantity is reduced.
10. Generate daily, monthly and annual reports.

## Verification status

The source package and ZIP structure were inspected and JavaScript syntax was checked in the build environment. The .NET SDK is not installed in the build environment, so a .NET compile, LocalDB integration run and end-to-end browser test could not be performed here. Run `Build-Check.ps1` on the Windows machine with the project's .NET 10 SDK before treating the package as verified.
