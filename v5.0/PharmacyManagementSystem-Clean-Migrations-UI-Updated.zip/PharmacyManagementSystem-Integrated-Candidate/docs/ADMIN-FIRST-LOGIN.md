# First Admin account (secure local provisioning)

The public `/api/auth/register` endpoint must create Doctors only. Do not register an Admin by changing a Doctor role manually, and never insert a plain-text password.

1. Create the five databases and tables with `docs/Strict-LLD-Schema.sql` on a fresh LocalDB instance.
2. Open PowerShell in the solution root.
3. Run: `powershell -ExecutionPolicy Bypass -File .\scripts\New-AdminSeed.ps1`
4. Enter a strong password when prompted. The script generates a PBKDF2-SHA256 hash using the same 120,000-iteration format as the included AuthService password verifier, and writes a one-time SQL seed file.
5. Open the generated `Create-FirstAdmin.sql` in SSMS connected to the same SQL Server instance and execute it against `UserDB`.
6. Delete the generated SQL file. Keep the password in your organization's approved password manager.
7. Login using `admin@pharmacy.local` and the password you selected.

This is a local first-run provisioning procedure. It should be run once by the project operator. The generated SQL contains a password hash, not the plaintext password.

**Compatibility warning:** this script matches the existing AuthService PBKDF2 format, but the current archive's EF model and startup initialization have not yet been refactored to the strict schema. Do not treat this procedure as evidence that the full application is already aligned or build-verified.
