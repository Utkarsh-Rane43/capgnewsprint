-- Connect SSMS to (localdb)\\MSSQLLocalDB before running this script.
-- This script creates database containers only. Each service creates its own tables
-- from its EF Core entity model on first startup using EnsureCreated().
IF DB_ID(N'UserDB') IS NULL CREATE DATABASE [UserDB];
GO
IF DB_ID(N'InventoryDB') IS NULL CREATE DATABASE [InventoryDB];
GO
IF DB_ID(N'OrderDB') IS NULL CREATE DATABASE [OrderDB];
GO
IF DB_ID(N'PaymentDB') IS NULL CREATE DATABASE [PaymentDB];
GO
IF DB_ID(N'ReportDB') IS NULL CREATE DATABASE [ReportDB];
GO
