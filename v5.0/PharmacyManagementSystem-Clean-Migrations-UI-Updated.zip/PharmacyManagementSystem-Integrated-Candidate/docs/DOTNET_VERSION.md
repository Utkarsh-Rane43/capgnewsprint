# .NET target framework

This solution targets **.NET 10 (`net10.0`)**. The .NET SDK resolver is configured in `global.json` for SDK `10.0.100` with `latestFeature` roll-forward. Install the .NET 10 SDK before restoring/building.

Entity Framework Core SQL Server, ASP.NET Core JWT Bearer, and Microsoft.Extensions.Http package references are aligned to **10.0.15**. EF Core 10 requires the .NET 10 SDK/runtime.

Check the installed SDK with:

```bash
dotnet --list-sdks
dotnet --version
```

Then run:

```bash
dotnet restore PharmacyManagementSystem.sln
dotnet build PharmacyManagementSystem.sln
dotnet test PharmacyManagementSystem.sln
```

.NET 10 is an LTS release. Use the latest available .NET 10 servicing update when building and deploying.
