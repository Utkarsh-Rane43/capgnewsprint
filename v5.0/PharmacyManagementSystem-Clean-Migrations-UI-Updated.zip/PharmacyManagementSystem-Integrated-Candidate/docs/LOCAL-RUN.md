# Local run instructions

1. Install .NET 10 SDK and SQL Server LocalDB.
2. Open PowerShell in the solution directory.
3. Run `dotnet tool restore`.
4. Run `.\Build-Check.ps1`.
5. Run `.\Run-Local.bat`.
6. Open `http://localhost:5000/` and `http://localhost:5000/swagger`.

## Automatic database setup

You do **not** need to open SSMS or execute a SQL script to create databases. On startup, Auth, Inventory, Order, Payment and Sales Report services:

1. Read their configured `ConnectionStrings:Default`.
2. Connect to the SQL Server `master` catalog.
3. Create the configured database only if it does not exist.
4. Call EF Core `Database.MigrateAsync()` to apply pending migrations.

The Notification Service does not own a database. Database initialization errors are fatal and are shown in the service console; the service does not silently continue with a missing schema.

The SQL Server login must have permission to create databases on first run. If the five databases already exist from an older version using `EnsureCreated()`, read `MIGRATIONS-AND-DATABASE-SETUP.md` before starting this version.
