@echo off
setlocal
cd /d "%~dp0"
echo =====================================================
echo Pharmacy Management System - .NET 10 local launcher
echo =====================================================
where dotnet >nul 2>nul
if errorlevel 1 (
  echo .NET SDK was not found. Install the .NET 10 SDK first.
  pause
  exit /b 1
)
sqllocaldb start MSSQLLocalDB >nul 2>nul
echo Starting six services...
start "Auth Service - 5001" cmd /k "dotnet run --project src\AuthService"
start "Inventory Service - 5002" cmd /k "dotnet run --project src\InventoryService"
start "Order Service - 5003" cmd /k "dotnet run --project src\OrderService"
start "Payment Service - 5004" cmd /k "dotnet run --project src\PaymentService"
start "Sales Report Service - 5005" cmd /k "dotnet run --project src\SalesReportService"
start "Notification Service - 5006" cmd /k "dotnet run --project src/NotificationService"
echo Waiting for backend services to initialize...
timeout /t 8 /nobreak >nul
start "YARP API Gateway - 5000" cmd /k "dotnet run --project src\ApiGateway"
echo.
echo Gateway Swagger: http://localhost:5000/swagger
echo All client requests must use port 5000. Service ports 5001-5006 are internal.
echo Stop services with Ctrl+C in each service window.
