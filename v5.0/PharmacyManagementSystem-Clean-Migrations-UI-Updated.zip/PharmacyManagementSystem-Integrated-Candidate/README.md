# Pharmacy Management System

A local full-stack pharmacy application built with .NET 10, C#, ASP.NET Core Web API, EF Core, LINQ, SQL Server LocalDB, YARP and a responsive browser UI.

## Project layout

```text
PharmacyManagementSystem.sln
├── src/
│   ├── ApiGateway/                 # YARP gateway and browser UI (wwwroot)
│   ├── AuthService/
│   │   ├── Controllers/
│   │   ├── Data/                   # DbContext, initializer and migrations
│   │   ├── Services/
│   │   └── Common/
│   ├── InventoryService/
│   │   ├── Controllers/
│   │   ├── Data/
│   │   └── Common/
│   ├── OrderService/
│   │   ├── Controllers/
│   │   ├── Data/
│   │   └── Common/
│   ├── PaymentService/
│   ├── SalesReportService/
│   └── NotificationService/
├── tests/                          # NUnit tests
├── docs/                           # setup, schema and workflow notes
├── scripts/                        # local developer scripts
└── .config/dotnet-tools.json       # pinned dotnet-ef tool
```

## Quick start (Windows)

1. Install the **.NET 10 SDK** and **SQL Server LocalDB**.
2. Open PowerShell in this folder and run `dotnet tool restore`.
3. Run `.\Build-Check.ps1`.
4. Run `.\Run-Local.bat`.
5. Open **http://localhost:5000/** for the application or **http://localhost:5000/swagger** for Swagger UI.

**No manual database creation is required.** When each data-owning service starts, it connects to the SQL Server `master` database, creates its configured database if it does not exist, then applies that service's EF Core migrations. The five databases are `UserDB`, `InventoryDB`, `OrderDB`, `PaymentDB`, and `ReportDB`.

The migration history is stored in each database's `__EFMigrationsHistory` table. Existing databases are not dropped or recreated. If a database already contains tables created with the old `EnsureCreated()` flow, back it up and follow `docs/MIGRATIONS-AND-DATABASE-SETUP.md` before switching to migrations.

## EF Core migrations

Initial migrations are included per service under `src/<Service>/Data/Migrations`. To add a future migration, use the pinned EF tool and the matching service project. Example:

```powershell
dotnet ef migrations add AddYourChange `
  --project src/AuthService/AuthService.csproj `
  --startup-project src/AuthService/AuthService.csproj `
  --output-dir Data/Migrations

dotnet ef database update `
  --project src/AuthService/AuthService.csproj `
  --startup-project src/AuthService/AuthService.csproj
```

Repeat with the relevant service. Runtime startup applies pending migrations automatically.

## Doctor quantity experience

The old browser `prompt()` quantity request has been replaced with an accessible quantity dialog. It displays the selected medicine, unit price, currently available stock, plus/minus controls, quantity validation and a live subtotal. The same dialog is used for Add to Cart and Order Now.

## Verification status

The ZIP and source edits can be inspected, but this environment does not have the .NET SDK or SQL Server LocalDB. Run `Build-Check.ps1` and complete the local workflow on Windows before treating this revision as build/runtime verified. Do not use production secrets in local appsettings files.
